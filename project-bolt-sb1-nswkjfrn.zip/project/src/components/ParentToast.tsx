import React, { useEffect, useState } from 'react';
import { Eye, X } from 'lucide-react';

interface ParentToastProps {
  message: string;
  questId?: string;
  childName?: string;
  isVisible: boolean;
  onClose: () => void;
  onViewQuest?: () => void;
}

const ParentToast: React.FC<ParentToastProps> = ({ 
  message, 
  questId,
  childName,
  isVisible, 
  onClose,
  onViewQuest
}) => {
  const [shouldRender, setShouldRender] = useState(isVisible);

  useEffect(() => {
    if (isVisible) {
      setShouldRender(true);
      const timer = setTimeout(() => {
        onClose();
      }, 6000); // Longer duration for parent notifications
      return () => clearTimeout(timer);
    } else {
      const timer = setTimeout(() => {
        setShouldRender(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!shouldRender) return null;

  return (
    <div className={`fixed bottom-24 left-4 right-4 z-50 transition-all duration-300 ${
      isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
    }`}>
      <div className={`
        flex items-center p-4 rounded-card shadow-card
        bg-info-blue/10 border border-info-blue/20
      `}>
        <div className="flex-shrink-0 mr-3">
          <div className="w-10 h-10 bg-info-blue rounded-full flex items-center justify-center">
            <Eye size={20} className="text-white" />
          </div>
        </div>
        
        <div className="flex-1">
          <p className="text-text-navy font-medium text-sm">
            {message}
          </p>
          {childName && (
            <p className="text-text-gray text-xs mt-1">
              {childName}'s quest activity
            </p>
          )}
        </div>
        
        <div className="flex items-center gap-2 ml-3">
          {onViewQuest && (
            <button
              onClick={onViewQuest}
              className="px-3 py-1.5 bg-info-blue text-white rounded-full text-xs font-medium hover:bg-blue-600 transition-colors"
            >
              View
            </button>
          )}
          
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/80 hover:bg-white transition-colors"
          >
            <X size={16} className="text-text-gray" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ParentToast;