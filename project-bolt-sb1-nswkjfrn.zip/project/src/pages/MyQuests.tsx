import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Clock, 
  CheckCircle, 
  Star, 
  Zap, 
  Play,
  RotateCcw,
  Search,
  TreePine,
  Leaf,
  Award
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useResponsive } from '../hooks/useResponsive';
import { Quest } from '../types';
import LoadingScreen from '../components/LoadingScreen';

const MyQuests: React.FC = () => {
  const navigate = useNavigate();
  const { 
    quests, 
    completedQuests, 
    user,
  } = useApp();
  
  const { isPhone, isTablet } = useResponsive();
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1600);
    return () => clearTimeout(timer);
  }, []);

  const handleQuestRestart = (questId: string) => {
    navigate(`/quest/${questId}`);
  };

  // Filter quests based on current tab and filters
  const getFilteredQuests = () => {
    // Only show completed quests
    let filtered = quests.filter(quest => completedQuests.includes(quest.id));

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(quest => 
        quest.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        quest.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        quest.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    return filtered;
  };

  const filteredQuests = getFilteredQuests();

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100 border-green-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'hard': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getTypeConfig = (type: string) => {
    switch (type) {
      case 'chat': return { 
        icon: '💬', 
        color: 'text-blue-600 bg-blue-100 border-blue-200',
        name: 'Prompt Potion',
        gradient: 'from-orange-500 to-orange-600'
      };
      case 'image': return { 
        icon: '🎨', 
        color: 'text-purple-600 bg-purple-100 border-purple-200',
        name: 'Snap Trail',
        gradient: 'from-blue-500 to-blue-600'
      };
      case 'search': return { 
        icon: '🔍', 
        color: 'text-green-600 bg-green-100 border-green-200',
        name: 'Logic Dash',
        gradient: 'from-green-500 to-green-600'
      };
      case '20q': return { 
        icon: '🧠', 
        color: 'text-purple-600 bg-purple-100 border-purple-200',
        name: '20 Questions',
        gradient: 'from-purple-500 to-purple-600'
      };
      default: return { 
        icon: '✨', 
        color: 'text-gray-600 bg-gray-100 border-gray-200',
        name: 'Heart Connect',
        gradient: 'from-pink-500 to-pink-600'
      };
    }
  };

  // Calculate quest statistics
  const totalXpEarned = completedQuests.reduce((total, questId) => {
    const quest = quests.find(q => q.id === questId);
    return total + (quest?.xpValue || 0);
  }, 0);

  const averageCompletionTime = Math.round(
    completedQuests.reduce((total, questId) => {
      const quest = quests.find(q => q.id === questId);
      return total + (quest?.duration || 0);
    }, 0) / Math.max(completedQuests.length, 1)
  );

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative overflow-hidden pb-20">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500">🌿</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-green-800">🌲</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-green-700">🌲</div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-yellow-500 animate-bounce">🌸</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🦋</div>
      </div>

      <div className={`pt-6 space-y-6 ${isPhone ? 'px-4' : 'px-8'}`}>
        <div className="pt-6 space-y-6 px-4 pb-6">
          {/* Quest Statistics */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 p-6">
            <h2 className="font-semibold text-green-800 text-lg mb-4">
              📊 Your Forest Adventure Stats
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center bg-green-50 rounded-xl border border-green-200 p-4">
                <CheckCircle size={24} className="text-green-600 mx-auto mb-2" />
                <div className="font-bold text-green-800 text-xl">
                  {completedQuests.length}
                </div>
                <div className="text-green-600 text-sm">Completed</div>
              </div>
              
              <div className="text-center bg-yellow-50 rounded-xl border border-yellow-200 p-4">
                <Leaf size={24} className="text-yellow-600 mx-auto mb-2" />
                <div className="font-bold text-green-800 text-xl">
                  {totalXpEarned}
                </div>
                <div className="text-green-600 text-sm">Leaves</div>
              </div>
              
              <div className="text-center bg-blue-50 rounded-xl border border-blue-200 p-4">
                <Clock size={24} className="text-blue-600 mx-auto mb-2" />
                <div className="font-bold text-green-800 text-xl">
                  {averageCompletionTime}m
                </div>
                <div className="text-green-600 text-sm">Avg Time</div>
              </div>
              
              <div className="text-center bg-purple-50 rounded-xl border border-purple-200 p-4">
                <Award size={24} className="text-purple-600 mx-auto mb-2" />
                <div className="font-bold text-green-800 text-xl">
                  {Math.round(totalXpEarned / Math.max(completedQuests.length, 1))}
                </div>
                <div className="text-green-600 text-sm">Avg XP</div>
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 p-1">
            <Search size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-green-400" />
            <input
              type="text"
              placeholder="Search completed adventures..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-4 border-0 bg-transparent focus:outline-none rounded-2xl text-green-800 placeholder-green-400 text-base"
            />
          </div>

          {/* Page Title */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 text-center p-6">
            <h2 className="font-bold text-green-800 text-xl mb-2">
              🏆 Completed Forest Adventures
            </h2>
            <p className="text-green-600 text-base">
              Replay your favorite forest quests anytime!
            </p>
          </div>

          {/* Quest List */}
          <div className="space-y-4">
            {filteredQuests.length === 0 ? (
              <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 text-center p-8">
                <div className="text-6xl mb-4">🌳</div>
                <h3 className="font-semibold text-green-800 text-lg mb-2">
                  No completed adventures found
                </h3>
                <p className="text-green-600 text-base">
                  {searchQuery
                    ? 'Try adjusting your search'
                    : 'Start exploring forest adventures to build your journey!'
                  }
                </p>
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                    }}
                    className="mt-4 px-4 py-2 bg-green-600 text-white rounded-xl font-medium hover:bg-green-700 transition-colors shadow-lg"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredQuests.map((quest) => {
                const isCompleted = completedQuests.includes(quest.id);
                const typeConfig = getTypeConfig(quest.type);
                
                return (
                  <div key={quest.id} className="relative bg-white/95 backdrop-blur-sm rounded-2xl overflow-hidden shadow-sm border border-green-200 hover:shadow-md transition-all duration-200">
                    {/* Forest Clearing Background */}
                    <div className="absolute -inset-6 bg-green-100/30 rounded-full blur-lg opacity-40"></div>
                    
                    {/* Main Tile Circle - matching home page style */}
                    <div className="relative p-4">
                      <div className={`
                        w-24 h-24 mx-auto rounded-full border-3 flex flex-col items-center justify-center relative mb-4
                        ${isCompleted 
                          ? 'bg-green-200 border-green-500 shadow-lg' 
                          : `bg-gradient-to-br ${typeConfig.gradient} border-white shadow-xl`
                        }
                      `}>
                        
                        {/* Game Type Icon (top-left) */}
                        <div className={`absolute -top-1 -left-1 w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center border ${
                          isCompleted ? 'border-green-500' : 'border-gray-200'
                        }`}>
                          <span className="text-xs">{typeConfig.icon}</span>
                        </div>
                        
                        {/* Level Badge (top-right) */}
                        <div className={`absolute -top-1 -right-1 w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center border ${
                          isCompleted ? 'border-green-500' : 'border-yellow-400'
                        }`}>
                          <span className={`text-xs font-bold ${
                            isCompleted ? 'text-green-600' : 'text-yellow-600'
                          }`}>
                            {Math.floor(Math.random() * 3) + 1}
                          </span>
                        </div>
                        
                        {/* Completion Check */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                              <CheckCircle size={16} className="text-white" />
                            </div>
                          </div>
                        </div>
                        
                        {/* Completion Badge */}
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-green-500 shadow-md flex items-center justify-center border border-white">
                          <span className="text-white text-xs font-bold">✓</span>
                        </div>
                      </div>
                      
                      {/* Quest Info Card */}
                      <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-green-200 p-3">
                        <h3 className="font-semibold text-green-800 text-center text-sm mb-2 leading-tight">
                          {quest.title}
                        </h3>
                        
                        <p className="text-green-600 text-center text-xs mb-3 line-clamp-2 leading-relaxed">
                          {quest.description}
                        </p>
                        
                        {/* Stats Row */}
                        <div className="flex items-center justify-center space-x-4 mb-3 text-xs">
                          <div className="flex items-center text-green-600">
                            <Clock size={12} className="mr-1" />
                            {quest.duration}m
                          </div>
                          <div className="flex items-center text-green-700 font-medium">
                            <Leaf size={12} className="mr-1" />
                            {quest.xpValue}
                          </div>
                        </div>
                        
                        {/* Action Button */}
                        <div className="text-center">
                          <button
                            onClick={() => handleQuestRestart(quest.id)}
                            className="flex items-center justify-center bg-green-50 text-green-600 rounded-full font-medium hover:bg-green-100 transition-colors border border-green-200 mx-auto px-4 py-2 text-xs"
                          >
                            <RotateCcw size={12} className="mr-1" />
                            Replay Adventure
                          </button>
                        </div>
                      </div>
                      
                      {/* Forest Elements around tiles */}
                      <div className="absolute -top-3 -left-3 text-sm opacity-40 pointer-events-none">🌸</div>
                      <div className="absolute -bottom-1 -right-3 text-xs opacity-50 pointer-events-none">🦋</div>
                    </div>
                  </div>
                );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyQuests;