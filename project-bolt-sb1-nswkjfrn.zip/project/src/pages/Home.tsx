import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, MessageCircle, FlaskRound as Flask, Cog, Heart, Shuffle, Coins, Sparkles, Zap, TreePine, Leaf } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useResponsive } from '../hooks/useResponsive';
import { QuestTile } from '../types';
import LoadingScreen from '../components/LoadingScreen';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const { 
    user, 
    questTiles,
    shuffleTokens,
    activeProfile,
    completeTile,
    shuffleTheme
  } = useApp();
  
  const { isPhone } = useResponsive();
  const [isLoading, setIsLoading] = useState(true);
  const [showShuffleModal, setShowShuffleModal] = useState(false);
  const [selectedTile, setSelectedTile] = useState<QuestTile | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [completingTileId, setCompletingTileId] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!activeProfile) {
      navigate('/profiles');
      return;
    }
  }, [activeProfile, navigate]);

  const handleTileClick = (tile: QuestTile) => {
    if (!tile.isUnlocked || tile.isCompleted) return;
    
    console.log('Tile clicked:', tile.id, tile.gameType); // Debug log
    
    // Navigate to specific quest game based on tile
    if (tile.id === 'tile-1') {
      navigate('/snap-trail');
    } else if (tile.id === 'tile-2') {
      navigate('/20q');
    } else {
      // For other tiles, simulate completion for now
      setCompletingTileId(tile.id);
      setIsAnimating(true);
      
      setTimeout(() => {
        completeTile(tile.id);
        setIsAnimating(false);
        setCompletingTileId(null);
      }, 1500);
    }
  };

  const handleTileLongPress = (tile: QuestTile) => {
    if (!tile.isUnlocked || tile.isCompleted || shuffleTokens.count <= 0) return;
    
    setSelectedTile(tile);
    setShowShuffleModal(true);
  };

  const handleShuffleConfirm = () => {
    if (selectedTile) {
      shuffleTheme(selectedTile.id);
      setShowShuffleModal(false);
      setSelectedTile(null);
    }
  };

  const getGameTypeIcon = (gameType: string) => {
    switch (gameType) {
      case 'snap-trail': return Camera;
      case '20q': return MessageCircle;
      case 'prompt-potion': return Flask;
      case 'logic-dash': return Cog;
      case 'heart-connect': return Heart;
      default: return Camera;
    }
  };

  const getGameTypeColor = (gameType: string) => {
    switch (gameType) {
      case 'snap-trail': return 'from-blue-500 to-blue-600';
      case '20q': return 'from-purple-500 to-purple-600';
      case 'prompt-potion': return 'from-orange-500 to-orange-600';
      case 'logic-dash': return 'from-green-500 to-green-600';
      case 'heart-connect': return 'from-pink-500 to-pink-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getGameTypeName = (gameType: string) => {
    switch (gameType) {
      case 'snap-trail': return 'Snap Trail';
      case '20q': return '20 Questions';
      case 'prompt-potion': return 'Prompt Potion';
      case 'logic-dash': return 'Logic Dash';
      case 'heart-connect': return 'Heart Connect';
      default: return gameType;
    }
  };

  // Show all tiles but ensure proper visibility
  const playableTiles = questTiles;
  
  // Always show 4 tiles: completed + unlocked tiles up to 4 total
  const completedTiles = questTiles.filter(tile => tile.isCompleted);
  const unlockedTiles = questTiles.filter(tile => tile.isUnlocked && !tile.isCompleted);
  const totalAvailable = completedTiles.length + unlockedTiles.length;
  
  // Ensure we always have 4 tiles visible (completed + unlocked + locked up to 4)
  const targetTileCount = 4;
  const visibleTiles = questTiles.slice(0, Math.max(targetTileCount, totalAvailable));

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (!activeProfile) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Background Trees */}
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500">🌿</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-green-800">🌲</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-green-700">🌲</div>
        
        {/* Floating Leaves */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-yellow-500 animate-bounce">🍃</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🍂</div>
      </div>

      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-green-200 shadow-sm px-4 py-4">
        <div className="flex items-center justify-between max-w-sm mx-auto">
          <div className="flex items-center space-x-4">
            <div className="text-center">
              <div className="text-lg font-bold text-green-700">
                {user.xp.toLocaleString()}
              </div>
              <div className="text-xs text-green-600">🍃 Leaves</div>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-bold text-green-700">
                {user.level}
              </div>
              <div className="text-xs text-green-600">🌳 Level</div>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-bold text-orange-600">
                {user.streak}
              </div>
              <div className="text-xs text-green-600">🔥 Streak</div>
            </div>
          </div>
          
          <div className="flex items-center bg-yellow-100 rounded-full px-3 py-2 border border-yellow-200">
            <Coins size={20} className="text-yellow-600 mr-2" />
            <span className="font-bold text-yellow-700">{shuffleTokens.count}</span>
            <span className="text-yellow-600 ml-1 text-xs">Shuffle</span>
          </div>
        </div>
      </div>

      {/* Forest Trail Adventure Ladder */}
      <div className="relative px-4 py-6 max-w-sm mx-auto pb-24" style={{ minHeight: `${Math.max(visibleTiles.length * 160, 800)}px` }}>
        <div className="relative">
          {/* Trail Path SVG */}
          <svg 
            className="absolute inset-0 w-full h-full pointer-events-none z-10" 
            style={{ height: `${visibleTiles.length * 160}px` }}
          >
            <defs>
              <pattern id="forestTrail" patternUnits="userSpaceOnUse" width="20" height="20">
                <rect width="20" height="20" fill="#8B5A2B" opacity="0.3"/>
                <circle cx="5" cy="5" r="1" fill="#654321" opacity="0.5"/>
                <circle cx="15" cy="15" r="1" fill="#654321" opacity="0.5"/>
              </pattern>
            </defs>
            
            {visibleTiles.map((tile, index) => {
              if (index === visibleTiles.length - 1) return null;
              
              const isLeft = index % 2 === 0;
              const nextIsLeft = (index + 1) % 2 === 0;
              
              const startX = isLeft ? 80 : 320;
              const startY = index * 160 + 80;
              const endX = nextIsLeft ? 80 : 320;
              const endY = (index + 1) * 160 + 80;
              
              const midX = (startX + endX) / 2;
              const midY = (startY + endY) / 2;
              
              return (
                <g key={`path-${index}`}>
                  {/* Forest Trail Path */}
                  <path
                    d={`M ${startX} ${startY} Q ${midX + (isLeft ? 50 : -50)} ${midY} ${endX} ${endY}`}
                    stroke="url(#forestTrail)"
                    strokeWidth="12"
                    fill="none"
                    opacity={tile.isCompleted ? "0.8" : tile.isUnlocked ? "0.6" : "0.3"}
                  />
                  
                  {/* Trail Decorations */}
                  <circle cx={midX} cy={midY} r="3" fill="#8B5A2B" opacity="0.4"/>
                  <text x={midX - 10} y={midY - 10} fontSize="16" opacity="0.6">🌿</text>
                  <text x={midX + 10} y={midY + 20} fontSize="14" opacity="0.5">🍄</text>
                </g>
              );
            })}
          </svg>

          {/* Quest Tiles in Zig-Zag Pattern - Top to Bottom */}
          <div className="relative z-20">
            {visibleTiles.slice().reverse().map((tile, originalIndex) => {
              const index = visibleTiles.length - 1 - originalIndex;
              const GameIcon = getGameTypeIcon(tile.gameType);
              const isLeft = index % 2 === 0;
              const isCompleting = completingTileId === tile.id;
              
              return (
                <div 
                  key={tile.id}
                  className={`absolute transition-all duration-300 ${
                    isLeft ? 'left-4' : 'right-4'
                  }`}
                  style={{ 
                    top: `${index * 160}px`,
                    transform: isCompleting ? 'scale(1.1)' : 'scale(1)'
                  }}
                >
                  {/* Forest Clearing Background */}
                  <div className="absolute -inset-6 bg-green-100/30 rounded-full blur-lg"></div>
                  
                  {/* Quest Tile */}
                  <div 
                    className={`relative w-28 h-28 transition-all duration-300 ${
                      tile.isUnlocked && !tile.isCompleted 
                        ? 'cursor-pointer hover:scale-105 active:scale-95' 
                        : ''
                    } ${
                      isCompleting ? 'animate-pulse' : ''
                    }`}
                    onClick={() => handleTileClick(tile)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      handleTileLongPress(tile);
                    }}
                    onTouchStart={(e) => {
                      const timer = setTimeout(() => handleTileLongPress(tile), 500);
                      e.currentTarget.addEventListener('touchend', () => clearTimeout(timer), { once: true });
                    }}
                  >
                    {/* Main Tile Circle */}
                    <div className={`
                      w-full h-full rounded-full border-3 flex flex-col items-center justify-center relative
                      ${tile.isCompleted 
                        ? 'bg-green-200 border-green-500 shadow-lg' 
                        : tile.isUnlocked 
                          ? `bg-gradient-to-br ${getGameTypeColor(tile.gameType)} border-white shadow-xl`
                          : 'bg-gray-200 border-gray-400 opacity-60'
                      }
                    `}>
                      
                      {/* Game Type Icon (top-left) */}
                      <div className={`absolute -top-2 -left-2 w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center border-2 ${
                        tile.isCompleted ? 'border-green-500' :
                        tile.isUnlocked ? 'border-gray-200' : 'border-gray-300'
                      }`}>
                        <GameIcon size={16} className={
                          tile.isCompleted ? 'text-green-600' :
                          tile.isUnlocked ? 'text-gray-700' : 'text-gray-400'
                        } />
                      </div>
                      
                      {/* Level Badge (top-right) */}
                      <div className={`absolute -top-2 -right-2 w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center border-2 ${
                        tile.isCompleted ? 'border-green-500' :
                        tile.isUnlocked ? 'border-yellow-400' : 'border-gray-300'
                      }`}>
                        <span className={`text-sm font-bold ${
                          tile.isCompleted ? 'text-green-600' :
                          tile.isUnlocked ? 'text-yellow-600' : 'text-gray-400'
                        }`}>
                          {tile.level}
                        </span>
                      </div>
                      
                      {/* Completion Check */}
                      {tile.isCompleted && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                            <span className="text-white text-xl">✓</span>
                          </div>
                        </div>
                      )}
                      
                      {/* Theme and Game Type (center) */}
                      {!tile.isCompleted && (
                        <div className="text-center px-2">
                          <div className="font-semibold text-white text-xs leading-tight mb-1">
                            {getGameTypeName(tile.gameType)}
                          </div>
                          <div className="font-medium text-white/90 text-xs leading-tight">
                            {tile.theme}
                          </div>
                        </div>
                      )}
                      
                      {/* Shuffle Indicator */}
                      {tile.isUnlocked && !tile.isCompleted && shuffleTokens.count > 0 && (
                        <div className="absolute bottom-1 right-1 bg-yellow-400 rounded-full p-1">
                          <Shuffle size={12} className="text-yellow-800" />
                        </div>
                      )}
                      
                      {/* Glow Effect for Unlocked */}
                      {tile.isUnlocked && !tile.isCompleted && (
                        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-200/40 to-green-200/40 animate-pulse" />
                      )}
                    </div>
                  </div>
                  
                  {/* Tile Info Card */}
                  <div className="mt-3 bg-white/90 backdrop-blur-sm rounded-xl p-3 shadow-sm border border-green-200 max-w-xs">
                    <div className="text-center">
                      <p className="font-medium text-gray-800 text-xs mb-2 leading-tight">
                        {tile.description}
                      </p>
                      {tile.isUnlocked && !tile.isCompleted && (
                        <div className="flex items-center justify-center space-x-3 text-xs">
                          <span className="text-green-600 font-semibold">
                            +{tile.xpReward} 🍃
                          </span>
                          <span className="text-yellow-600 font-semibold">
                            +1 🪙
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Forest Elements around tiles */}
                  <div className="absolute -top-6 -left-6 text-lg opacity-40 pointer-events-none">🌸</div>
                  <div className="absolute -bottom-4 -right-6 text-sm opacity-50 pointer-events-none">🦋</div>
                  {index % 3 === 0 && (
                    <div className="absolute top-1/2 -translate-y-1/2 -left-8 text-xl opacity-30 pointer-events-none">🌺</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Shuffle Modal */}
      {showShuffleModal && selectedTile && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl border border-green-200">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                <Shuffle size={32} className="text-white" />
              </div>
              
              <h3 className="font-bold text-lg text-gray-900 mb-2">
                🌿 Shuffle Forest Theme?
              </h3>
              
              <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                Spend 1 Shuffle Token to discover a new theme for this {getGameTypeName(selectedTile.gameType)} adventure?
              </p>
              
              <div className="flex items-center justify-center mb-4">
                <div className="bg-yellow-100 rounded-full px-3 py-2 flex items-center border border-yellow-300">
                  <Coins size={20} className="text-yellow-600 mr-2" />
                  <span className="font-bold text-yellow-700">{shuffleTokens.count}</span>
                  <span className="text-yellow-600 ml-1 text-sm">tokens</span>
                </div>
              </div>
              
              <div className="flex space-x-3 mt-6">
                <button
                  onClick={() => setShowShuffleModal(false)}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors border border-gray-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleShuffleConfirm}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-white bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 transition-colors shadow-md"
                >
                  🌟 Shuffle
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Completion Confetti Effect */}
      {isAnimating && (
        <div className="fixed inset-0 pointer-events-none z-30">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className={`absolute animate-bounce text-xl ${
                i % 4 === 0 ? 'text-green-400' : 
                i % 4 === 1 ? 'text-yellow-400' : 
                i % 4 === 2 ? 'text-orange-400' : 'text-pink-400'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 0.5}s`
              }}
            >
              {i % 4 === 0 ? '🍃' : i % 4 === 1 ? '🌟' : i % 4 === 2 ? '🎉' : '✨'}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;