import React from 'react';
import { Flame } from 'lucide-react';
import { useResponsive } from '../hooks/useResponsive';

interface StreakMeterProps {
  currentStreak: number;
  maxStreak?: number;
}

const StreakMeter: React.FC<StreakMeterProps> = ({ currentStreak, maxStreak = 30 }) => {
  const percentage = Math.min((currentStreak / maxStreak) * 100, 100);

  return (
    <div className="p-4 rounded-2xl bg-white shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className="p-2 rounded-full bg-gradient-to-r from-orange-500 to-red-500">
            <Flame size={20} className="text-white" />
          </div>
          <div className="ml-3">
            <h3 className="font-semibold text-base text-gray-900">
              Daily Streak
            </h3>
            <p className="text-xs text-gray-600">
              Keep it up!
            </p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-orange-600">
            {currentStreak}
          </div>
          <div className="text-xs text-gray-600">
            days
          </div>
        </div>
      </div>
      
      <div className="relative">
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-orange-500 to-red-500 rounded-full"
            style={{ width: `${percentage}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>0</span>
          <span>{maxStreak}</span>
        </div>
      </div>
      
      {currentStreak >= 7 && (
        <div className="mt-4 text-center">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
            🔥 Streak Master!
          </span>
        </div>
      )}
    </div>
  );
};

export default StreakMeter;