import React, { useState, useEffect } from 'react';
import { ArrowLeft, Volume2, VolumeX, Search, BookOpen, Zap, Clock, Award, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AnimalFact {
  question: string;
  answer: string;
  funFact: string;
  category: string;
}

const AnimalFactsDetective: React.FC = () => {
  const navigate = useNavigate();
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [currentQuery, setCurrentQuery] = useState('');
  const [discoveredFacts, setDiscoveredFacts] = useState<AnimalFact[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [questProgress, setQuestProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(180); // 3 minutes
  const [xp, setXp] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleQuestComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleBack = () => {
    navigate('/');
  };

  const handleTTSToggle = () => {
    setIsTTSEnabled(!isTTSEnabled);
  };

  const handleSearch = async () => {
    if (!currentQuery.trim() || isSearching) return;

    setIsSearching(true);
    
    // Simulate research
    setTimeout(() => {
      const mockFacts: AnimalFact[] = [
        {
          question: currentQuery,
          answer: "Elephants are amazing creatures with incredible memories and strong family bonds.",
          funFact: "Did you know elephants can recognize themselves in mirrors? They're one of the few animals that can do this!",
          category: "mammals"
        },
        {
          question: currentQuery,
          answer: "Dolphins are highly intelligent marine mammals that use echolocation to navigate.",
          funFact: "Dolphins have names for each other! They use unique whistle signatures to identify themselves.",
          category: "marine"
        }
      ];
      
      const randomFact = mockFacts[Math.floor(Math.random() * mockFacts.length)];
      setDiscoveredFacts(prev => [...prev, randomFact]);
      setQuestProgress(prev => Math.min(prev + 33, 100));
      setXp(prev => prev + 40);
      setIsSearching(false);
      setCurrentQuery('');
      
      if (questProgress >= 66) {
        setTimeout(() => handleQuestComplete(), 1000);
      }
    }, 2000);
  };

  const handleQuestComplete = () => {
    setIsCompleted(true);
    setXp(prev => prev + 120);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const animalSuggestions = [
    "How do elephants communicate?",
    "What makes dolphins so smart?",
    "Why do tigers have stripes?",
    "How do birds fly?",
    "What do pandas eat?",
    "How fast can cheetahs run?"
  ];

  const categories = [
    { key: 'all', label: 'All Animals', icon: '🌍' },
    { key: 'mammals', label: 'Mammals', icon: '🐘' },
    { key: 'birds', label: 'Birds', icon: '🦅' },
    { key: 'marine', label: 'Marine Life', icon: '🐋' },
    { key: 'reptiles', label: 'Reptiles', icon: '🦎' }
  ];

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-600 via-blue-600 to-teal-700 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-4">
                  <Award className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Detective Mission Complete!</h1>
              <p className="text-xl text-gray-600">You've discovered amazing animal facts!</p>
              
              <div className="flex justify-center gap-6 mt-6">
                <div className="text-center">
                  <div className="bg-blue-100 rounded-full p-3 mb-2">
                    <Zap className="w-6 h-6 text-blue-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600">{xp}</div>
                  <div className="text-sm text-gray-600">XP Earned</div>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 rounded-full p-3 mb-2">
                    <BookOpen className="w-6 h-6 text-green-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-green-600">{discoveredFacts.length}</div>
                  <div className="text-sm text-gray-600">Facts Discovered</div>
                </div>
                <div className="text-center">
                  <div className="bg-purple-100 rounded-full p-3 mb-2">
                    <Search className="w-6 h-6 text-purple-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600">100%</div>
                  <div className="text-sm text-gray-600">Research Score</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Animal Fact Collection</h2>
            
            <div className="space-y-6 mb-8">
              {discoveredFacts.map((fact, index) => (
                <div key={index} className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
                  <h3 className="font-semibold text-lg text-gray-800 mb-3">🔍 {fact.question}</h3>
                  <p className="text-gray-700 mb-3">{fact.answer}</p>
                  <div className="bg-yellow-100 rounded-lg p-3 border-l-4 border-yellow-400">
                    <p className="text-sm text-gray-700"><strong>Fun Fact:</strong> {fact.funFact}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={() => navigate('/')}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg"
              >
                Back to Quests
              </button>
              <button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-blue-600 transition-all duration-200 shadow-lg">
                Discover More Facts
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-teal-900 to-blue-900 flex flex-col">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm sticky top-0 z-40 px-4 py-4 border-b border-white/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors mr-3"
            >
              <ArrowLeft size={20} className="text-white" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                <Search size={20} className="text-white mr-2" />
                <h1 className="font-quicksand font-semibold text-lg text-white truncate">
                  Animal Facts Detective
                </h1>
              </div>
              <div className="flex items-center text-sm text-white/70">
                <Clock size={14} className="mr-1" />
                <span>{formatTime(timeRemaining)}</span>
                <Zap size={14} className="ml-3 mr-1" />
                <span>{xp} XP</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={handleTTSToggle}
            className={`p-3 rounded-full transition-colors ml-2 ${
              isTTSEnabled 
                ? 'bg-green-500 text-white' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
          >
            {isTTSEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-white/70 mb-2">
            <span>Research Progress</span>
            <span>{questProgress}%</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-green-400 to-blue-400"
              style={{ width: `${questProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4">
        {/* Research Panel */}
        <div className="bg-white/10 backdrop-blur-sm rounded-card p-6 mb-6">
          <h2 className="font-quicksand font-semibold text-xl text-white mb-4 flex items-center">
            <BookOpen size={24} className="mr-2" />
            Animal Research Lab
          </h2>
          <p className="text-white/80 mb-6">
            Ask questions about animals and discover amazing facts about the natural world!
          </p>
          
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 mb-4">
            {categories.map((category) => (
              <button
                key={category.key}
                onClick={() => setSelectedCategory(category.key)}
                className={`px-3 py-1 rounded-full text-sm transition-colors ${
                  selectedCategory === category.key
                    ? 'bg-white/30 text-white'
                    : 'bg-white/10 text-white/70 hover:bg-white/20'
                }`}
              >
                {category.icon} {category.label}
              </button>
            ))}
          </div>
          
          <input
            type="text"
            value={currentQuery}
            onChange={(e) => setCurrentQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Ask about any animal... (e.g., 'How do elephants communicate?')"
            className="w-full px-4 py-3 rounded-xl border border-white/20 bg-white/10 backdrop-blur-sm text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-400 mb-4"
          />
          
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="text-white/70 text-sm">Quick questions:</span>
            {animalSuggestions.slice(0, 3).map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setCurrentQuery(suggestion)}
                className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white/80 text-xs transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
          
          <button
            onClick={handleSearch}
            disabled={!currentQuery.trim() || isSearching}
            className={`w-full py-4 px-6 rounded-xl font-semibold transition-all duration-200 transform active:scale-95 ${
              !currentQuery.trim() || isSearching
                ? 'bg-white/20 text-white/50 cursor-not-allowed'
                : 'bg-gradient-to-r from-green-500 to-blue-500 text-white hover:from-green-600 hover:to-blue-600 shadow-lg'
            }`}
          >
            {isSearching ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Researching...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <Search size={20} className="mr-2" />
                Start Research
              </div>
            )}
          </button>
        </div>

        {/* Discovered Facts */}
        {discoveredFacts.length > 0 && (
          <div className="bg-white/10 backdrop-blur-sm rounded-card p-6">
            <h3 className="font-quicksand font-semibold text-lg text-white mb-4 flex items-center">
              <Eye size={20} className="mr-2" />
              Your Discoveries
            </h3>
            
            <div className="space-y-4">
              {discoveredFacts.map((fact, index) => (
                <div key={index} className="bg-white/10 rounded-xl p-4">
                  <h4 className="font-semibold text-white mb-2">🔍 {fact.question}</h4>
                  <p className="text-white/80 mb-3">{fact.answer}</p>
                  <div className="bg-yellow-400/20 rounded-lg p-3 border-l-4 border-yellow-400">
                    <p className="text-sm text-white/90"><strong>Fun Fact:</strong> {fact.funFact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnimalFactsDetective;