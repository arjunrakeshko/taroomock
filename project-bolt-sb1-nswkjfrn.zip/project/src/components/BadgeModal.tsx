import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { Badge } from '../types';

interface BadgeModalProps {
  badge: Badge;
  isOpen: boolean;
  onClose: () => void;
}

const BadgeModal: React.FC<BadgeModalProps> = ({ badge, isOpen, onClose }) => {
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setShowConfetti(true);
      const timer = setTimeout(() => {
        setShowConfetti(false);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const rarityColors = {
    common: 'from-gray-400 to-gray-600',
    rare: 'from-blue-400 to-blue-600',
    epic: 'from-purple-400 to-purple-600',
    legendary: 'from-yellow-400 to-yellow-600'
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className={`absolute animate-confetti text-2xl ${
                i % 4 === 0 ? 'text-accent-yellow' : 
                i % 4 === 1 ? 'text-primary-green' : 
                i % 4 === 2 ? 'text-primary-blue' : 'text-purple-500'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 0.5}s`
              }}
            >
              ✨
            </div>
          ))}
        </div>
      )}
      
      <div className="bg-white rounded-card p-6 max-w-sm w-full shadow-2xl animate-bounce-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-surface-gray hover:bg-border-gray transition-colors"
        >
          <X size={20} />
        </button>
        
        <div className="text-center">
          <div className="mb-6">
            <div className={`w-24 h-24 mx-auto rounded-full bg-gradient-to-br ${rarityColors[badge.rarity]} flex items-center justify-center mb-4 shadow-lg`}>
              <span className="text-4xl">{badge.icon}</span>
            </div>
            <span className="inline-block px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wide bg-surface-gray text-text-gray">
              {badge.rarity}
            </span>
          </div>
          
          <h2 className="text-2xl font-quicksand font-bold text-text-navy mb-2">
            {badge.name}
          </h2>
          
          <p className="text-text-gray mb-6">
            {badge.description}
          </p>
          
          <div className="text-6xl mb-4 animate-pulse-gentle">
            🎉
          </div>
          
          <button
            onClick={onClose}
            className="w-full py-3 px-6 rounded-full font-semibold transition-all duration-200 transform active:scale-95 bg-primary-green text-white hover:bg-green-600 shadow-button"
          >
            Awesome!
          </button>
        </div>
      </div>
    </div>
  );
};

export default BadgeModal;