import { QuestExchange, ParentAlert } from '../types';

export const mockQuestExchanges: QuestExchange[] = [
  {
    id: 'exchange-1',
    questId: '1',
    childId: 'kid1',
    completedAt: '2024-01-20T14:30:00Z',
    duration: 8,
    xpEarned: 150,
    messages: [
      {
        id: 'msg-1',
        type: 'ai',
        content: 'Welcome to "Creative Story Builder"! Let\'s create an amazing story about a magical forest adventure. What kind of character would you like to be the hero of your story?',
        timestamp: 1705756200000
      },
      {
        id: 'msg-2',
        type: 'user',
        content: 'I want to be a brave knight who protects animals!',
        timestamp: 1705756230000
      },
      {
        id: 'msg-3',
        type: 'ai',
        content: 'What a wonderful choice! A brave knight who protects animals is a fantastic hero. What\'s your knight\'s name, and what special power do they have to help animals?',
        timestamp: 1705756235000
      },
      {
        id: 'msg-4',
        type: 'user',
        content: 'His name is Sir Fluffy and he can talk to all animals and understand what they need!',
        timestamp: 1705756280000
      },
      {
        id: 'msg-5',
        type: 'ai',
        content: 'Sir Fluffy is an amazing name! I love that he can communicate with animals. Now, what kind of adventure should Sir Fluffy go on in the magical forest?',
        timestamp: 1705756285000
      },
      {
        id: 'msg-6',
        type: 'user',
        content: 'He needs to save a family of rabbits from a mean dragon who took their home!',
        timestamp: 1705756320000
      }
    ],
    aiAnalysis: {
      overallSentiment: 'positive',
      safetyScore: 98,
      positiveSignals: [
        'Shows empathy and care for animals',
        'Creative storytelling abilities',
        'Positive hero archetype selection',
        'Problem-solving mindset',
        'Appropriate language throughout'
      ],
      concerns: [],
      recommendations: [
        'Encourage more creative writing activities',
        'Consider animal care or veterinary-themed quests',
        'Build on storytelling skills with character development exercises'
      ],
      flaggedContent: []
    }
  },
  {
    id: 'exchange-2',
    questId: '4',
    childId: 'kid1',
    completedAt: '2024-01-19T16:45:00Z',
    duration: 12,
    xpEarned: 180,
    messages: [
      {
        id: 'msg-7',
        type: 'ai',
        content: 'Welcome to "Robot Friend Designer"! Let\'s create your perfect robot companion. What would you want your robot friend to look like?',
        timestamp: 1705675500000
      },
      {
        id: 'msg-8',
        type: 'user',
        content: 'I want a robot that looks like a big teddy bear but with cool lights!',
        timestamp: 1705675530000
      },
      {
        id: 'msg-9',
        type: 'ai',
        content: 'A teddy bear robot with lights sounds adorable and amazing! What color would the lights be, and what special things could your robot friend do?',
        timestamp: 1705675535000
      },
      {
        id: 'msg-10',
        type: 'user',
        content: 'Blue and green lights! And it could help me with homework and play games and maybe cook pancakes!',
        timestamp: 1705675580000
      },
      {
        id: 'msg-11',
        type: 'ai',
        content: 'Those are wonderful ideas! A helpful robot friend who can assist with learning and make delicious pancakes. What would you name your robot friend?',
        timestamp: 1705675585000
      },
      {
        id: 'msg-12',
        type: 'user',
        content: 'Pancake Bot! And maybe it could also help other kids who don\'t have friends.',
        timestamp: 1705675620000
      }
    ],
    aiAnalysis: {
      overallSentiment: 'positive',
      safetyScore: 95,
      positiveSignals: [
        'Shows desire to help others',
        'Creative and practical thinking',
        'Positive social awareness',
        'Healthy relationship with technology',
        'Empathetic consideration for lonely children'
      ],
      concerns: [
        'Possible indication of social isolation (wanting robot to help kids without friends)'
      ],
      recommendations: [
        'Monitor social interactions and friendships',
        'Encourage group activities and social quests',
        'Consider discussing friendship and social skills'
      ],
      flaggedContent: []
    }
  },
  {
    id: 'exchange-3',
    questId: '2',
    childId: 'kid2',
    completedAt: '2024-01-18T10:15:00Z',
    duration: 6,
    xpEarned: 200,
    messages: [
      {
        id: 'msg-13',
        type: 'ai',
        content: 'Welcome to "Space Explorer Art"! Let\'s create amazing space scenes together. What would you like to explore in space?',
        timestamp: 1705566900000
      },
      {
        id: 'msg-14',
        type: 'user',
        content: 'I want to see a planet where everything is made of candy!',
        timestamp: 1705566930000
      },
      {
        id: 'msg-15',
        type: 'ai',
        content: 'A candy planet sounds absolutely delicious and fun! What kinds of candy would you find there? Mountains of chocolate? Rivers of caramel?',
        timestamp: 1705566935000
      },
      {
        id: 'msg-16',
        type: 'user',
        content: 'Yes! And gummy bear trees and cotton candy clouds! But I\'m worried the astronauts might get sick from eating too much.',
        timestamp: 1705566980000
      },
      {
        id: 'msg-17',
        type: 'ai',
        content: 'That\'s very thoughtful of you to worry about the astronauts\' health! What could the astronauts do to explore safely without getting sick?',
        timestamp: 1705566985000
      },
      {
        id: 'msg-18',
        type: 'user',
        content: 'Maybe they could just take small samples to study and share with scientists on Earth!',
        timestamp: 1705567020000
      }
    ],
    aiAnalysis: {
      overallSentiment: 'positive',
      safetyScore: 100,
      positiveSignals: [
        'Excellent creative imagination',
        'Shows concern for others\' wellbeing',
        'Scientific thinking and problem-solving',
        'Responsible decision-making',
        'Balance between fun and safety'
      ],
      concerns: [],
      recommendations: [
        'Encourage more science-based creative activities',
        'Consider nutrition and health education quests',
        'Build on scientific curiosity with space exploration content'
      ],
      flaggedContent: []
    }
  }
];

export const mockParentAlerts: ParentAlert[] = [
  {
    id: 'alert-1',
    childId: 'kid1',
    questId: '4',
    type: 'emotional',
    severity: 'low',
    title: 'Social Awareness Noted',
    description: 'Alex mentioned wanting their robot to help kids who don\'t have friends. This could indicate awareness of social isolation or personal experience.',
    timestamp: '2024-01-19T16:50:00Z',
    isRead: false,
    actionRequired: false
  },
  {
    id: 'alert-2',
    childId: 'kid2',
    questId: '2',
    type: 'positive',
    severity: 'low',
    title: 'Excellent Problem-Solving',
    description: 'Emma showed great critical thinking by considering astronaut safety on the candy planet and proposing a scientific solution.',
    timestamp: '2024-01-18T10:20:00Z',
    isRead: true,
    actionRequired: false
  },
  {
    id: 'alert-3',
    childId: 'kid1',
    questId: '1',
    type: 'positive',
    severity: 'low',
    title: 'Strong Empathy Development',
    description: 'Alex consistently shows care for animals and others, demonstrating healthy emotional development and empathy.',
    timestamp: '2024-01-20T14:35:00Z',
    isRead: false,
    actionRequired: false
  }
];