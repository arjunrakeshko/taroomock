import React, { useEffect, useState } from 'react';
import { useApp } from '../contexts/AppContext';

const WeeklyProgressModal: React.FC = () => {
  const { 
    weeklyProgressCard, 
    dismissWeeklyProgressCard, 
    getUserTier,
    shouldShowConfetti,
    resetConfettiFlag
  } = useApp();
  
  const [showConfetti, setShowConfetti] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (weeklyProgressCard && !weeklyProgressCard.hasShown) {
      setIsVisible(true);
      
      if (weeklyProgressCard.isNewTier && shouldShowConfetti()) {
        setShowConfetti(true);
        resetConfettiFlag();
        
        setTimeout(() => {
          setShowConfetti(false);
        }, 1000);
      }
    }
  }, [weeklyProgressCard, shouldShowConfetti, resetConfettiFlag]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => {
      dismissWeeklyProgressCard();
    }, 300);
  };

  if (!weeklyProgressCard || !isVisible) return null;

  const currentTier = getUserTier(weeklyProgressCard.xpProgress);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className={`absolute animate-confetti text-2xl ${
                i % 3 === 0 ? 'text-accent-yellow' : 
                i % 3 === 1 ? 'text-primary-green' : 'text-primary-blue'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 0.5}s`
              }}
            >
              ✨
            </div>
          ))}
        </div>
      )}
      
      <div className={`bg-white rounded-card p-6 max-w-sm w-full shadow-2xl transition-all duration-300 ${
        isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
      }`}>
        <div className="text-center">
          {/* Tier Icon */}
          <div className={`w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br ${currentTier.color} flex items-center justify-center shadow-lg`}>
            <span className="text-3xl">{currentTier.icon}</span>
          </div>
          
          {/* Message */}
          <h2 className="font-quicksand font-bold text-xl text-text-navy mb-2">
            {weeklyProgressCard.isNewTier 
              ? `You reached ${currentTier.name} Tier!` 
              : `Great progress, ${currentTier.name}!`
            }
          </h2>
          
          <p className="text-text-gray mb-6">
            {weeklyProgressCard.nextTier 
              ? `Just ${weeklyProgressCard.xpToNext} XP to ${weeklyProgressCard.nextTier}.`
              : 'You\'re at the highest tier! Keep exploring!'
            }
          </p>
          
          {/* Progress Visualization */}
          {weeklyProgressCard.nextTier && (
            <div className="mb-6">
              <div className="flex justify-between text-sm text-text-gray mb-2">
                <span>{currentTier.name}</span>
                <span>{weeklyProgressCard.nextTier}</span>
              </div>
              <div className="h-3 bg-surface-gray rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${currentTier.color} transition-all duration-1000 ease-out`}
                  style={{ 
                    width: `${Math.min((weeklyProgressCard.xpProgress / (weeklyProgressCard.xpProgress + weeklyProgressCard.xpToNext)) * 100, 100)}%` 
                  }}
                />
              </div>
            </div>
          )}
          
          {/* Encouragement */}
          <div className="text-4xl mb-4">
            {weeklyProgressCard.isNewTier ? '🎉' : '⭐'}
          </div>
          
          <button
            onClick={handleClose}
            className="w-full py-3 px-6 rounded-full font-semibold transition-all duration-200 transform active:scale-95 bg-primary-green text-white hover:bg-green-600 shadow-duolingo"
          >
            Great!
          </button>
        </div>
      </div>
    </div>
  );
};

export default WeeklyProgressModal;