import React, { useState, useEffect } from 'react';
import { Trophy, Star, TrendingUp, Calendar } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const WeeklyLeague: React.FC = () => {
  const { user, leaderboard } = useApp();
  const [showLeague, setShowLeague] = useState(false);
  const [isNewWeek, setIsNewWeek] = useState(false);

  useEffect(() => {
    // Check if it's Monday 9 AM local time
    const now = new Date();
    const isMonday = now.getDay() === 1;
    const isNineAM = now.getHours() === 9;
    
    if (isMonday && isNineAM) {
      setIsNewWeek(true);
      setShowLeague(true);
    }
  }, []);

  const handleClose = () => {
    setShowLeague(false);
    setIsNewWeek(false);
  };

  if (!showLeague) return null;

  const topThree = leaderboard.slice(0, 3);
  const userRank = leaderboard.find(entry => entry.id === user.id);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="w-full max-w-md bg-white rounded-card shadow-card animate-slide-up">
        {/* Header */}
        <div className="bg-gradient-to-r from-accent-yellow to-primary-green p-6 rounded-t-card">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-white/20 rounded-full flex items-center justify-center">
              <Trophy size={32} className="text-white" />
            </div>
            <h2 className="font-quicksand font-bold text-xl text-white mb-2">
              {isNewWeek ? 'New Week!' : 'Weekly League'}
            </h2>
            <p className="text-white/90 text-sm">
              See how you rank this week!
            </p>
          </div>
        </div>

        {/* League Content */}
        <div className="p-6">
          {/* Top 3 */}
          <div className="mb-6">
            <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4 text-center">
              🏆 Top Explorers
            </h3>
            
            <div className="space-y-3">
              {topThree.map((entry, index) => (
                <div key={entry.id} className={`
                  flex items-center p-3 rounded-tile
                  ${index === 0 ? 'bg-accent-yellow/20' : 
                    index === 1 ? 'bg-gray-100' : 'bg-orange-100'}
                `}>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-primary-green to-primary-blue flex items-center justify-center mr-3">
                    <span className="text-white font-bold text-sm">{index + 1}</span>
                  </div>
                  
                  <img
                    src={entry.avatar}
                    alt={entry.name}
                    className="w-10 h-10 rounded-full mr-3"
                  />
                  
                  <div className="flex-1">
                    <p className="font-medium text-text-navy">{entry.name}</p>
                    <p className="text-sm text-text-gray">{entry.xp.toLocaleString()} XP</p>
                  </div>
                  
                  {index === 0 && <Trophy size={20} className="text-accent-yellow" />}
                  {index === 1 && <Star size={20} className="text-gray-500" />}
                  {index === 2 && <TrendingUp size={20} className="text-orange-500" />}
                </div>
              ))}
            </div>
          </div>

          {/* User Rank */}
          {userRank && userRank.rank > 3 && (
            <div className="mb-6">
              <h4 className="font-medium text-text-navy mb-2">Your Rank</h4>
              <div className="flex items-center p-3 rounded-tile bg-primary-green/10 border border-primary-green/20">
                <div className="w-8 h-8 rounded-full bg-primary-green flex items-center justify-center mr-3">
                  <span className="text-white font-bold text-sm">{userRank.rank}</span>
                </div>
                
                <img
                  src={userRank.avatar}
                  alt={userRank.name}
                  className="w-10 h-10 rounded-full mr-3"
                />
                
                <div className="flex-1">
                  <p className="font-medium text-text-navy">{userRank.name} (You)</p>
                  <p className="text-sm text-text-gray">{userRank.xp.toLocaleString()} XP</p>
                </div>
              </div>
            </div>
          )}

          {/* Weekly Challenge */}
          <div className="mb-6 p-4 bg-gradient-to-r from-primary-blue/10 to-primary-green/10 rounded-tile border border-primary-blue/20">
            <div className="flex items-center mb-2">
              <Calendar size={16} className="text-primary-blue mr-2" />
              <span className="font-medium text-text-navy text-sm">This Week's Challenge</span>
            </div>
            <p className="text-sm text-text-gray">
              Complete 5 quests to earn bonus XP and climb the rankings!
            </p>
          </div>

          {/* Close Button */}
          <button
            onClick={handleClose}
            className="w-full py-3 px-6 rounded-card font-semibold transition-all duration-200 transform active:scale-95 bg-primary-green text-white hover:bg-dark-green shadow-duolingo active:shadow-duolingo-pressed active:translate-y-1"
          >
            Let's Go!
          </button>
        </div>
      </div>
    </div>
  );
};

export default WeeklyLeague;