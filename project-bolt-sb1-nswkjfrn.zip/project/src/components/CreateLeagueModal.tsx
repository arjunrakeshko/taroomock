import React, { useState } from 'react';
import { X, Users } from 'lucide-react';

interface CreateLeagueModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateLeague: (inviteCode: string) => void;
}

const CreateLeagueModal: React.FC<CreateLeagueModalProps> = ({ isOpen, onClose, onCreateLeague }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCreate = async () => {
    setIsCreating(true);
    
    // Generate a simple invite code
    setTimeout(() => {
      const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      setGeneratedCode(inviteCode);
      onCreateLeague(inviteCode);
      setIsCreating(false);
    }, 1000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClose = () => {
    setGeneratedCode('');
    setCopied(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl border border-green-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-semibold text-xl text-green-800">
            Create Forest Group
          </h2>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {!generatedCode ? (
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
              <Users size={32} className="text-green-600" />
            </div>
            
            <h3 className="font-semibold text-lg text-green-800 mb-2">
              Start Your Group
            </h3>
            
            <p className="text-green-600 text-sm mb-6 leading-relaxed">
              Create a new group and get an invite code to share with friends!
            </p>
            
            <button
              onClick={handleCreate}
              disabled={isCreating}
              className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 transform active:scale-95 ${
                isCreating
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-green-600 text-white hover:bg-green-700 shadow-md'
              }`}
            >
              {isCreating ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-gray-400 border-t-gray-600 rounded-full animate-spin mr-2"></div>
                  Creating...
                </div>
              ) : (
                'Create Group'
              )}
            </button>
          </div>
        ) : (
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white text-2xl">✓</span>
            </div>
            
            <h3 className="font-semibold text-lg text-green-800 mb-2">
              Group Created!
            </h3>
            
            <p className="text-green-600 text-sm mb-4">
              Share this code with friends to join your forest group:
            </p>
            
            <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4">
              <div className="font-mono text-2xl font-bold text-green-800 mb-2">
                {generatedCode}
              </div>
              <button
                onClick={handleCopyCode}
                className="text-sm text-green-600 hover:text-green-700 font-medium"
              >
                {copied ? '✓ Copied!' : '📋 Copy Code'}
              </button>
            </div>
            
            <button
              onClick={handleClose}
              className="w-full py-3 px-6 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors shadow-md"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CreateLeagueModal;