import React, { useState, useEffect } from 'react';
import { Users, Plus, UserPlus, TreePine, Trophy, X, Crown, Coins } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useResponsive } from '../hooks/useResponsive';
import CreateLeagueModal from '../components/CreateLeagueModal';
import LoadingScreen from '../components/LoadingScreen';

const Leaderboard: React.FC = () => {
  const { 
    user, 
    activeProfile, 
    getFriendsLeagues,
    leaderboard,
    getUserTier
  } = useApp();
  const { isPhone } = useResponsive();
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateLeague, setShowCreateLeague] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selectedLeague, setSelectedLeague] = useState(null);
  const [showFullLeaderboard, setShowFullLeaderboard] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1800);
    return () => clearTimeout(timer);
  }, []);


  const friendsLeagues = activeProfile ? getFriendsLeagues(activeProfile.id) : [];

  const handleCreateLeague = (inviteCode: string) => {
    console.log('Created forest group with code:', inviteCode);
    setShowCreateLeague(false);
  };

  const handleJoinWithCode = () => {
    if (inviteCode.trim()) {
      console.log('Joining forest group with code:', inviteCode);
      setInviteCode('');
      setShowInviteModal(false);
    }
  };

  const handleCopyInviteCode = () => {
    const sampleCode = 'FOREST2024';
    navigator.clipboard.writeText(sampleCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleViewFullLeaderboard = (league: any) => {
    setSelectedLeague(league);
    setShowFullLeaderboard(true);
  };

  const getTotalUsers = (leagueType: string) => {
    switch (leagueType) {
      case 'age_group': return '100k+';
      case 'school': return '500+';
      case 'neighborhood': return '200+';
      default: return '100+';
    }
  };

  const generateFullLeaderboard = (league: any) => {
    const baseMembers = [...league.members];
    const totalCount = league.type === 'age_group' ? 50 : 25;
    const additionalMembers = [];
    
    for (let i = baseMembers.length; i < totalCount; i++) {
      const names = ['Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Ethan', 'Sophia', 'Mason', 'Isabella', 'William'];
      const avatars = ['🦊', '🐰', '🐺', '🦌', '🐻', '🦝', '🐨', '🦁', '🐯', '🐸'];
      
      additionalMembers.push({
        id: `generated-${i}`,
        name: names[i % names.length] + (i > 9 ? Math.floor(i/10) : ''),
        avatar: avatars[i % avatars.length],
        xp: Math.max(100, 3000 - (i * 50) + Math.random() * 100),
        rank: i + 1,
        previousRank: i + 1,
        level: Math.max(1, Math.floor((3000 - (i * 50)) / 200)),
        streak: Math.floor(Math.random() * 15)
      });
    }
    
    return [...baseMembers, ...additionalMembers].sort((a, b) => b.xp - a.xp).map((member, index) => ({
      ...member,
      rank: index + 1
    }));
  };
  
  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative overflow-hidden pb-20">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500">🌿</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-green-800">🌲</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-green-700">🌲</div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-yellow-500 animate-bounce">🌸</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🦋</div>
      </div>

      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-green-200 shadow-sm px-4 py-6 safe-area-pt">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg">
            <Users size={32} className="text-white" />
          </div>
          <h1 className="font-bold text-green-800 text-2xl mb-2">
            🏕️ Forest Friends
          </h1>
          <p className="text-green-600 text-base">
            Connect with fellow forest explorers!
          </p>
        </div>
      </div>

      {/* Simple Leaderboard Cards */}
      <div className="px-4 py-6">
        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <button
            onClick={() => setShowCreateLeague(true)}
            className="flex-1 bg-green-600 text-white py-3 px-4 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center"
          >
            <Plus size={20} className="mr-2" />
            Create Forest Group
          </button>
          <button
            onClick={() => setShowInviteModal(true)}
            className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center justify-center"
          >
            <UserPlus size={20} className="mr-2" />
            Join with Code
          </button>
        </div>

        <h2 className="font-semibold text-xl text-green-800 mb-6">
          🌲 Your Groups
        </h2>
        
        {friendsLeagues.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-300 p-8 text-center">
            <div className="text-6xl mb-4">🌳</div>
            <h3 className="font-semibold text-lg text-green-800 mb-2">
              No Groups Yet
            </h3>
            <p className="text-green-600 text-sm mb-6">
              Complete your profile to join local groups!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {friendsLeagues.map((league) => {
              const currentUser = league.members.find(member => member.id === league.childId);
              const isUserInTop3 = currentUser && currentUser.rank <= 3;
              
              return (
                <div key={league.id} className="bg-white rounded-lg border border-gray-300 p-4">
                  {/* Header */}
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold text-gray-900 text-base">
                        {league.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {league.location || league.ageRange || 'Forest Group'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm text-gray-600">
                        {getTotalUsers(league.type)} users
                      </span>
                    </div>
                  </div>

                  {/* Rankings */}
                  <div className="space-y-1 mb-4">
                    {/* Top 3 */}
                    {league.members.slice(0, 3).map((member, index) => (
                      <div key={member.id} className={`text-sm ${member.id === league.childId ? 'font-semibold text-green-700' : 'text-gray-700'}`}>
                        {index + 1} {member.name} {member.id === league.childId ? '(you) ' : ''}{member.xp.toLocaleString()}
                      </div>
                    ))}
                    
                    {/* Show dots and user rank if not in top 3 */}
                    {currentUser && currentUser.rank > 3 && (
                      <>
                        <div className="text-sm text-gray-400">
                          ....
                        </div>
                        <div className="text-sm font-semibold text-green-700">
                          {currentUser.rank} {currentUser.name} (you) {currentUser.xp.toLocaleString()}
                        </div>
                      </>
                    )}
                  </div>

                  {/* View More Button */}
                  <div className="text-center">
                    <button 
                      onClick={() => handleViewFullLeaderboard(league)}
                      className="text-sm text-gray-600 hover:text-gray-800 hover:underline"
                    >
                      View more
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateLeagueModal
        isOpen={showCreateLeague}
        onClose={() => setShowCreateLeague(false)}
        onCreateLeague={handleCreateLeague}
      />

      {/* Join with Code Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl border border-green-200">
            <h3 className="font-semibold text-lg text-green-800 mb-4">
              🌲 Join with Code
            </h3>
            
            <p className="text-green-600 text-sm mb-4 leading-relaxed">
              Enter the code shared by your friend or group leader.
            </p>
            
            <input
              type="text"
              placeholder="Enter group code..."
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
              className="w-full p-3 border border-green-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-500 mb-4 font-mono text-center text-base bg-green-50"
              maxLength={10}
            />
            
            <div className="flex space-x-3">
              <button
                onClick={() => setShowInviteModal(false)}
                className="flex-1 py-3 px-4 border border-green-200 rounded-xl font-medium text-green-600 hover:bg-green-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleJoinWithCode}
                disabled={!inviteCode.trim()}
                className="flex-1 py-3 px-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-medium hover:from-green-600 hover:to-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
              >
                Join Group
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Leaderboard Modal */}
      {showFullLeaderboard && selectedLeague && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full mx-4 shadow-xl border border-green-200 max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b border-green-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg text-green-800">
                  {selectedLeague.name}
                </h3>
                <button
                  onClick={() => setShowFullLeaderboard(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X size={20} className="text-gray-500" />
                </button>
              </div>
            </div>
            
            <div className="overflow-y-auto max-h-[60vh]">
              {generateFullLeaderboard(selectedLeague).map((member, index) => (
                <div key={member.id} className={`flex items-center justify-between p-3 border-b border-gray-100 ${
                  member.id === selectedLeague.childId ? 'bg-green-100' : ''
                }`}>
                  <div className="flex items-center">
                    <span className="text-sm mr-3 w-6 text-center font-medium">
                      {index + 1}
                    </span>
                    <div className="w-8 h-8 rounded-full mr-3 bg-white border border-green-200 flex items-center justify-center">
                      <span className="text-sm">{member.avatar}</span>
                    </div>
                    <span className={`text-sm ${member.id === selectedLeague.childId ? 'font-semibold text-green-700' : 'text-green-800'}`}>
                      {member.name}
                      {member.id === selectedLeague.childId && ' (you)'}
                    </span>
                  </div>
                  <span className="text-xs text-green-600">
                    {member.xp.toLocaleString()}
                  </span>
                </div>
              ))}
              
              {/* Show more indicator */}
              <div className="text-center py-4 text-gray-500 text-sm">
                🏕️ Friends
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Leaderboard;