import React, { useState } from 'react';
import { Clock, Star, Zap, Users, Crown, Play } from 'lucide-react';
import { Quest } from '../types';
import { useApp } from '../contexts/AppContext';
import { useResponsive } from '../hooks/useResponsive';

interface QuestCardProps {
  quest: Quest;
  onStart: (questId: string) => void;
  onSwipeRight?: (questId: string) => void;
}

const QuestCard: React.FC<QuestCardProps> = ({ quest, onStart, onSwipeRight }) => {
  const { favoriteQuests, completedQuests, toggleFavorite } = useApp();
  const { isPhone } = useResponsive();
  const [isLoading, setIsLoading] = useState(false);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);

  const isFavorite = favoriteQuests.includes(quest.id);
  const isCompleted = completedQuests.includes(quest.id);

  const handleStart = () => {
    setIsLoading(true);
    setTimeout(() => {
      onStart(quest.id);
      setIsLoading(false);
    }, 500);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isRightSwipe = distance < -50;
    
    if (isRightSwipe && onSwipeRight) {
      toggleFavorite(quest.id);
      onSwipeRight(quest.id);
    }
  };

  const difficultyConfig = {
    easy: { 
      color: 'text-success-green bg-success-green/10', 
      dot: '🟢'
    },
    medium: { 
      color: 'text-primary-blue bg-primary-blue/10', 
      dot: '🟡'
    },
    hard: { 
      color: 'text-accent-purple bg-accent-purple/10', 
      dot: '🔴'
    }
  };

  const typeConfig = {
    chat: { 
      icon: '💬', 
      gradient: 'from-info-blue to-primary-blue',
      bg: 'bg-info-blue/10',
      text: 'text-info-blue'
    },
    image: { 
      icon: '🎨', 
      gradient: 'from-accent-purple to-accent-pink',
      bg: 'bg-accent-purple/10',
      text: 'text-accent-purple'
    },
    search: { 
      icon: '🔍', 
      gradient: 'from-success-green to-primary-green',
      bg: 'bg-success-green/10',
      text: 'text-success-green'
    }
  };

  const difficulty = difficultyConfig[quest.difficulty];
  const type = typeConfig[quest.type];

  // Mobile card styling
    return (
      <div className={`relative w-full bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 active:scale-95 transition-transform duration-200 ${
        isCompleted ? 'ring-2 ring-green-200' : ''
      }`}>
        {/* Image Section */}
        <div className={`relative overflow-hidden ${isPhone ? 'h-36' : 'h-48'}`}>
          <img
            src={quest.thumbnail}
            alt={quest.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
          
          <button
            onClick={() => toggleFavorite(quest.id)}
            className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200 ${
              isFavorite 
                ? 'bg-red-500 text-white' 
                : 'bg-white/90 text-gray-600 hover:bg-white'
            }`}
            style={{ minWidth: '32px', minHeight: '32px' }}
          >
            <Star size={14} className={isFavorite ? 'fill-current' : ''} />
          </button>
          
          <div className={`absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold flex items-center`}>
            <span className="mr-2">{type.icon}</span>
            <span className="text-gray-700">
              {quest.type === 'chat' ? 'Chat' : quest.type === 'image' ? 'Create' : 'Explore'}
            </span>
          </div>
          
          {isCompleted && (
            <div className="absolute bottom-3 right-3 bg-green-500 text-white p-2 rounded-full">
              <Zap size={12} className="fill-current" />
            </div>
          )}
        </div>
        
        {/* Content Section */}
        <div className={isPhone ? 'p-4' : 'p-6'}>
          <div className="flex items-start justify-between mb-3">
            <h3 className={`font-semibold text-gray-900 leading-tight flex-1 mr-2 ${
              isPhone ? 'text-base' : 'text-lg'
            }`}>
              {quest.title}
            </h3>
            <span className={`inline-block px-2 py-1 rounded-full font-medium uppercase tracking-wide bg-gray-100 text-gray-600 whitespace-nowrap ${
              isPhone ? 'text-xs' : 'text-sm'
            }`}>
              {quest.difficulty}
            </span>
          </div>
          
          <p className={`text-gray-600 mb-4 line-clamp-2 ${isPhone ? 'text-sm' : 'text-base'}`}>
            {quest.description}
          </p>
          
          <div className={`grid grid-cols-3 mb-4 ${isPhone ? 'gap-3' : 'gap-4'}`}>
            <div className={`flex flex-col items-center bg-gray-50 rounded-xl ${isPhone ? 'p-3' : 'p-4'}`}>
              <Clock size={isPhone ? 14 : 16} className="text-blue-600 mb-1" />
              <span className={`font-semibold text-gray-900 ${isPhone ? 'text-xs' : 'text-sm'}`}>{quest.duration}m</span>
              <span className={`text-gray-500 ${isPhone ? 'text-xs' : 'text-sm'}`}>Duration</span>
            </div>
            <div className={`flex flex-col items-center bg-gray-50 rounded-xl ${isPhone ? 'p-3' : 'p-4'}`}>
              <Users size={isPhone ? 14 : 16} className="text-purple-600 mb-1" />
              <span className={`font-semibold text-gray-900 ${isPhone ? 'text-xs' : 'text-sm'}`}>{Math.floor(quest.completedBy / 1000)}k</span>
              <span className={`text-gray-500 ${isPhone ? 'text-xs' : 'text-sm'}`}>Completed</span>
            </div>
            <div className={`flex flex-col items-center bg-gray-50 rounded-xl ${isPhone ? 'p-3' : 'p-4'}`}>
              <Zap size={isPhone ? 14 : 16} className="text-green-600 mb-1" />
              <span className={`font-bold text-green-600 ${isPhone ? 'text-xs' : 'text-sm'}`}>
                {quest.xpValue}
              </span>
              <span className={`text-gray-500 ${isPhone ? 'text-xs' : 'text-sm'}`}>XP</span>
            </div>
          </div>
          
          <button
            onClick={handleStart}
            disabled={isLoading}
            className={`w-full rounded-xl font-semibold transition-all duration-200 transform active:scale-95 flex items-center justify-center ${
              isPhone ? 'py-3 text-sm' : 'py-4 text-base'
            } ${
              isCompleted
                ? 'bg-green-100 text-green-600 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
            style={{ minHeight: isPhone ? '44px' : '52px' }}
          >
            {isLoading ? (
              <div className="flex items-center">
                <div className={`border-2 border-white/30 border-t-white rounded-full animate-spin mr-2 ${
                  isPhone ? 'w-4 h-4' : 'w-5 h-5'
                }`} />
                Starting...
              </div>
            ) : isCompleted ? (
              <div className="flex items-center">
                <Zap size={isPhone ? 16 : 18} className="mr-2 fill-current" />
                Completed
              </div>
            ) : (
              <div className="flex items-center">
                <Play size={isPhone ? 16 : 18} className="mr-2 fill-current" />
                Start Quest
              </div>
            )}
          </button>
        </div>
      </div>
    );
};

export default QuestCard;