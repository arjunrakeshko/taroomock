import React, { useState } from 'react';
import { Share2, Download, Eye, Heart, MessageCircle, Copy, Check } from 'lucide-react';
import { ShareableCreation } from '../types';

interface ShareableCreationCardProps {
  creation: ShareableCreation;
  childName: string;
  onShare?: (creation: ShareableCreation) => void;
}

const ShareableCreationCard: React.FC<ShareableCreationCardProps> = ({ 
  creation, 
  childName, 
  onShare 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    const shareText = `Check out ${childName}'s amazing creation: "${creation.title}"!\n\n${creation.description}\n\nCreated on Taroo 🌳`;
    
    if (navigator.share) {
      navigator.share({
        title: creation.title,
        text: shareText,
        url: window.location.origin
      });
    } else {
      navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
    
    onShare?.(creation);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const content = `${creation.title}\nBy ${childName}\n\n${creation.description}\n\n${creation.content}\n\nCreated on Plaiground`;
    const file = new Blob([content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${creation.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'story': return '📚';
      case 'artwork': return '🎨';
      case 'research': return '🔬';
      default: return '✨';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'story': return 'bg-purple-100 text-purple-700';
      case 'artwork': return 'bg-pink-100 text-pink-700';
      case 'research': return 'bg-blue-100 text-blue-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="bg-white rounded-card overflow-hidden shadow-card hover:shadow-lg transition-all duration-200">
      {/* Header */}
      <div className="relative">
        {creation.thumbnail && (
          <img
            src={creation.thumbnail}
            alt={creation.title}
            className="w-full h-32 object-cover"
          />
        )}
        
        <div className="absolute top-3 left-3">
          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(creation.type)}`}>
            <span className="mr-1">{getTypeIcon(creation.type)}</span>
            {creation.type.charAt(0).toUpperCase() + creation.type.slice(1)}
          </span>
        </div>
        
        <div className="absolute top-3 right-3 flex space-x-2">
          <button
            onClick={handleShare}
            className="p-2 bg-white/90 hover:bg-white rounded-full shadow-md transition-colors"
            style={{ minWidth: '36px', minHeight: '36px' }}
          >
            {copied ? <Check size={16} className="text-success-green" /> : <Share2 size={16} className="text-text-gray" />}
          </button>
          
          <button
            onClick={handleDownload}
            className="p-2 bg-white/90 hover:bg-white rounded-full shadow-md transition-colors"
            style={{ minWidth: '36px', minHeight: '36px' }}
          >
            <Download size={16} className="text-text-gray" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-quicksand font-semibold text-lg text-text-navy leading-tight flex-1">
            {creation.title}
          </h3>
        </div>
        
        <p className="text-text-gray text-sm mb-3 line-clamp-2">
          {creation.description}
        </p>
        
        {/* Preview Content */}
        <div className="mb-4">
          <p className={`text-text-navy text-sm leading-relaxed ${isExpanded ? '' : 'line-clamp-3'}`}>
            {creation.content}
          </p>
          
          {creation.content.length > 150 && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-primary-blue text-sm font-medium mt-2 hover:underline"
            >
              {isExpanded ? 'Show less' : 'Read more'}
            </button>
          )}
        </div>
        
        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-border-gray">
          <div className="flex items-center text-xs text-text-gray">
            <span>By {childName}</span>
            <span className="mx-2">•</span>
            <span>{new Date(creation.createdAt).toLocaleDateString()}</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <button className="flex items-center text-text-gray hover:text-error-red transition-colors">
              <Heart size={14} className="mr-1" />
              <span className="text-xs">12</span>
            </button>
            
            <button className="flex items-center text-text-gray hover:text-primary-blue transition-colors">
              <MessageCircle size={14} className="mr-1" />
              <span className="text-xs">3</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareableCreationCard;