import React, { useState } from 'react';
import { Star, Award, Calendar, Zap, TrendingUp, CheckCircle, TreePine, Leaf } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useResponsive } from '../hooks/useResponsive';
import BadgeModal from '../components/BadgeModal';
import TierProgressBar from '../components/TierProgressBar';
import LoadingScreen from '../components/LoadingScreen';

const Profile: React.FC = () => {
  const { 
    user, 
    badges, 
    userBadges, 
    completedQuests, 
    favoriteQuests, 
    getUserTier,
    streak
  } = useApp();
  
  const { isPhone } = useResponsive();
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBadge, setSelectedBadge] = useState(null);
  const [showBadgeModal, setShowBadgeModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'stats' | 'badges' | 'achievements'>('stats');

  React.useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const earnedBadges = badges.filter(badge => userBadges.includes(badge.id));
  const totalQuests = completedQuests.length;
  const joinDate = new Date(user.joinDate).toLocaleDateString();

  const handleBadgeClick = (badge) => {
    setSelectedBadge(badge);
    setShowBadgeModal(true);
  };

  const stats = [
    { label: 'Adventures Completed', value: totalQuests, icon: Award, color: 'text-green-600' },
    { label: 'Forest Streak', value: `${streak} days`, icon: Calendar, color: 'text-orange-600' },
    { label: 'Forest Leaves Earned', value: user.xp.toLocaleString(), icon: Leaf, color: 'text-green-600' },
    { label: 'Tree Level', value: user.level, icon: TreePine, color: 'text-green-700' }
  ];

  const achievements = [
    { title: 'Forest Pioneer', description: 'Joined in the first month!', completed: true, icon: '🌟' },
    { title: 'Trail Master', description: 'Maintain a 30-day streak', completed: streak >= 30, icon: '🔥' },
    { title: 'Adventure Collector', description: 'Complete 50 adventures', completed: totalQuests >= 50, icon: '🎯' },
    { title: 'Badge Hunter', description: 'Earn 10 forest badges', completed: earnedBadges.length >= 10, icon: '🏆' },
    { title: 'Creative Spirit', description: 'Complete 20 creative adventures', completed: false, icon: '🎨' },
    { title: 'Forest Researcher', description: 'Complete 15 research adventures', completed: false, icon: '🔍' }
  ];

  const tabs = [
    { key: 'stats', label: 'Overview', icon: TrendingUp },
    { key: 'badges', label: 'Badges', icon: Award },
    { key: 'achievements', label: 'Goals', icon: Star }
  ];

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative overflow-hidden pb-20">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500">🌿</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-green-800">🌲</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-green-700">🌲</div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-yellow-500 animate-bounce">🌸</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🦋</div>
      </div>

      {/* Header */}
      <div className="bg-white/95 backdrop-blur-md border-b border-green-200 shadow-sm px-4 py-6 safe-area-pt">
        <div className="text-center mb-6">
          {/* Animated Growing Tree */}
          <div className="relative mb-6">
            <div className="mx-auto relative w-32 h-40">
              {/* Tree Base/Trunk */}
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4 h-5 bg-amber-700 rounded-t-sm">
              </div>
              
              {/* Tree Canopy - grows with level */}
              <div className="absolute bottom-5 left-1/2 transform -translate-x-1/2 transition-all duration-1000 ease-out"
                   style={{ 
                     width: `${Math.min(20 + (user.level * 6), 100)}px`,
                     height: `${Math.min(20 + (user.level * 5), 80)}px`
                   }}>
                <div className="w-full h-full bg-gradient-to-t from-green-600 to-green-400 rounded-full relative overflow-hidden">
                  {/* Tree texture/details */}
                  <div className="absolute inset-0 opacity-30">
                    {[...Array(Math.min(user.level, 10))].map((_, i) => (
                      <div key={i} 
                           className="absolute w-2 h-2 bg-green-300 rounded-full animate-pulse"
                           style={{
                             left: `${20 + (i * 15) % 60}%`,
                             top: `${30 + (i * 20) % 40}%`,
                             animationDelay: `${i * 0.5}s`
                           }}>
                      </div>
                    ))}
                  </div>
                  
                  {/* Leaves floating around tree */}
                  <div className="absolute -inset-3 pointer-events-none">
                    {[...Array(Math.min(Math.floor(user.level / 2), 6))].map((_, i) => (
                      <div key={i} 
                           className="absolute text-sm animate-bounce opacity-60"
                           style={{
                             left: `${10 + (i * 25) % 80}%`,
                             top: `${10 + (i * 30) % 70}%`,
                             animationDelay: `${i * 0.8}s`,
                             animationDuration: '3s'
                           }}>
                        {i % 3 === 0 ? '🍃' : i % 3 === 1 ? '🌿' : '🍂'}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Level badge on tree */}
              <div className="absolute top-0 right-0 w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center border-3 border-white shadow-lg">
                <span className="text-white font-bold text-sm">{user.level}</span>
              </div>
              
              {/* Growth sparkles */}
              {user.level > 5 && (
                <div className="absolute -inset-1 pointer-events-none">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} 
                         className="absolute text-yellow-400 animate-pulse text-sm"
                         style={{
                           left: `${20 + (i * 30) % 60}%`,
                           top: `${20 + (i * 25) % 60}%`,
                           animationDelay: `${i * 0.7}s`
                         }}>
                      ✨
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          {/* Player Info */}
          <div className="text-center mb-4">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center border-3 border-green-200 bg-white shadow-lg">
              <span className="text-4xl">{user.avatar}</span>
            </div>
            <h1 className="font-bold text-green-800 text-2xl">
              {user.name}
            </h1>
            <p className="text-green-600 text-base">
              🌳 {user.level} {getUserTier(user.xp).name}
            </p>
          </div>
          
          {/* Tree Growth Message */}
          <div className="bg-green-50 rounded-xl border border-green-200 p-4 mb-4">
            <p className="text-green-800 font-medium text-sm leading-relaxed">
              🌱 Your forest tree grows with every adventure! 
              {user.level < 10 ? ` Complete more quests to grow it even bigger!` : ` Your tree is magnificent!`}
            </p>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-xl border border-green-200">
            <div className="font-bold text-green-700 text-2xl">
              {user.xp.toLocaleString()}
            </div>
            <div className="text-green-600 text-sm">🍃 Leaves</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-xl border border-green-200">
            <div className="font-bold text-green-700 text-2xl">
              Level {user.level}
            </div>
            <div className="text-green-600 text-sm">🌳 Level</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-xl border border-green-200">
            <div className="font-bold text-green-700 text-2xl">
              {earnedBadges.length}
            </div>
            <div className="text-green-600 text-sm">🏆 Badges</div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="px-4 py-4">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 p-1">
          <div className="grid grid-cols-3">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`py-3 px-4 rounded-xl font-semibold text-sm transition-all duration-200 flex items-center justify-center ${
                  activeTab === tab.key
                    ? 'bg-green-600 text-white shadow-md'
                    : 'text-green-600 hover:bg-green-50'
                }`}
              >
                <tab.icon size={16} className="mr-2" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-4 pb-6">
        {activeTab === 'stats' && (
          <div className="space-y-6">
            {/* Tier Progress */}
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-sm border border-green-200 p-6">
              <h3 className="font-semibold text-green-800 text-lg mb-4">
                🌳 Growth Progress
              </h3>
              
              <TierProgressBar size="lg" />
              
              <div className="mt-4 bg-green-50 rounded-xl border border-green-200 p-4">
                <div className="flex items-center justify-center">
                  <span className="mr-3 text-2xl">
                    {getUserTier(user.xp).icon}
                  </span>
                  <div className="text-center">
                    <p className="font-semibold text-green-800 text-base">
                      {getUserTier(user.xp).name}
                    </p>
                    <p className="text-green-600 text-sm">
                      Keep exploring to grow your forest!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Adventure Completion */}

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-sm border border-green-200">
                  <div className="flex items-center justify-between mb-2">
                    <stat.icon size={20} className={stat.color} />
                    <div className="text-base font-bold text-green-600">
                      {stat.value}
                    </div>
                  </div>
                  <p className="text-sm text-green-600">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Join Date */}
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-sm border border-green-200">
              <div className="flex items-center">
                <Calendar size={20} className="text-green-600 mr-3" />
                <div>
                  <p className="font-medium text-green-800">Forest Explorer since</p>
                  <p className="text-sm text-green-600">{joinDate}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'badges' && (
          <div className="space-y-6">
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200">
              <h3 className="font-semibold text-lg text-green-800 mb-4">
                🏆 Your Badges ({earnedBadges.length})
              </h3>
              
              {earnedBadges.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-4xl mb-4">🌳</div>
                  <p className="text-green-600">Complete adventures to earn your first badge!</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-4">
                  {earnedBadges.map((badge) => (
                    <button
                      key={badge.id}
                      onClick={() => handleBadgeClick(badge)}
                      className="flex flex-col items-center p-4 rounded-xl bg-green-50 hover:bg-green-100 transition-colors transform active:scale-95 border border-green-200"
                    >
                      <div className="w-14 h-14 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center mb-2 shadow-sm">
                        <span className="text-xl">{badge.icon}</span>
                      </div>
                      <p className="text-xs font-medium text-center text-green-800">
                        {badge.name}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200">
              <h3 className="font-semibold text-lg text-green-800 mb-4">
                🌟 Available Badges
              </h3>
              
              <div className="grid grid-cols-3 gap-4">
                {badges.filter(badge => !userBadges.includes(badge.id)).map((badge) => (
                  <button
                    key={badge.id}
                    onClick={() => handleBadgeClick(badge)}
                    className="flex flex-col items-center p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors transform active:scale-95 opacity-60 border border-gray-200"
                  >
                    <div className="w-14 h-14 bg-gray-300 rounded-full flex items-center justify-center mb-2">
                      <span className="text-xl grayscale">{badge.icon}</span>
                    </div>
                    <p className="text-xs font-medium text-center text-gray-600">
                      {badge.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="space-y-4">
            {achievements.map((achievement, index) => (
              <div key={index} className={`bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-sm border ${
                achievement.completed ? 'border-green-300 bg-green-50' : 'border-green-200'
              }`}>
                <div className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
                    achievement.completed 
                      ? 'bg-green-100 border-2 border-green-300' 
                      : 'bg-gray-100 border-2 border-gray-200'
                  }`}>
                    <span className="text-lg">{achievement.icon}</span>
                  </div>
                  
                  <div className="flex-1">
                    <h4 className={`font-semibold ${
                      achievement.completed ? 'text-green-800' : 'text-green-600'
                    }`}>
                      {achievement.title}
                    </h4>
                    <p className="text-sm text-green-600">{achievement.description}</p>
                  </div>
                  
                  {achievement.completed && (
                    <div className="w-6 h-6 rounded-full flex items-center justify-center bg-green-500">
                      <CheckCircle size={16} className="text-white" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Badge Modal */}
      {selectedBadge && (
        <BadgeModal
          badge={selectedBadge}
          isOpen={showBadgeModal}
          onClose={() => setShowBadgeModal(false)}
        />
      )}
    </div>
  );
};

export default Profile;