import React, { useState } from 'react';
import { Crown, Calendar, CreditCard, AlertTriangle, Check, Settings } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

interface SubscriptionStatusProps {
  onManageBilling?: () => void;
  onUpgrade?: () => void;
  compact?: boolean;
}

const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({ 
  onManageBilling, 
  onUpgrade,
  compact = false 
}) => {
  const { activeProfile } = useApp();
  const [showDetails, setShowDetails] = useState(false);

  const isProUser = activeProfile?.parentData?.hasProSubscription || false;
  
  // Mock subscription data - in production this would come from your backend
  const subscriptionData = {
    plan: isProUser ? 'Pro - 2 Children' : 'Free',
    status: isProUser ? 'active' : 'free',
    nextBilling: isProUser ? '2024-03-15' : null,
    amount: isProUser ? 167.76 : 0, // 2 children * $6.99 * 12 months * 0.9 (10% family discount)
    childCount: isProUser ? 2 : 0,
    paymentMethod: isProUser ? '**** 4242' : null,
    daysUntilRenewal: isProUser ? 23 : null
  };

  const getStatusConfig = () => {
    if (!isProUser) {
      return {
        icon: Crown,
        color: 'text-text-gray',
        bgColor: 'bg-surface-gray',
        borderColor: 'border-border-gray',
        label: 'Free Plan',
        description: 'Limited access to features'
      };
    }

    if (subscriptionData.daysUntilRenewal && subscriptionData.daysUntilRenewal <= 7) {
      return {
        icon: AlertTriangle,
        color: 'text-warning-yellow',
        bgColor: 'bg-warning-yellow/10',
        borderColor: 'border-warning-yellow/20',
        label: 'Renewing Soon',
        description: `Renews in ${subscriptionData.daysUntilRenewal} days`
      };
    }

    return {
      icon: Crown,
      color: 'text-success-green',
      bgColor: 'bg-success-green/10',
      borderColor: 'border-success-green/20',
      label: 'Pro Active',
      description: 'Full access to all features'
    };
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  if (compact) {
    return (
      <div className={`inline-flex items-center gap-2 px-3 py-2 rounded-full border ${config.bgColor} ${config.borderColor}`}>
        <Icon size={16} className={config.color} />
        <span className={`text-sm font-medium ${config.color}`}>
          {config.label}
        </span>
        {isProUser && (
          <div className="w-2 h-2 bg-success-green rounded-full animate-pulse"></div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-card p-6 shadow-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className={`
            w-12 h-12 rounded-full flex items-center justify-center mr-4
            ${config.bgColor} ${config.borderColor} border
          `}>
            <Icon size={24} className={config.color} />
          </div>
          
          <div>
            <h3 className="font-quicksand font-semibold text-lg text-text-navy">
              {subscriptionData.plan}
            </h3>
            <p className={`text-sm ${config.color}`}>
              {config.description}
            </p>
          </div>
        </div>
        
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="p-2 rounded-full hover:bg-surface-gray transition-colors"
        >
          <Settings size={20} className="text-text-gray" />
        </button>
      </div>

      {/* Subscription Details */}
      {showDetails && (
        <div className="border-t border-border-gray pt-4 space-y-3">
          {isProUser ? (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar size={16} className="text-text-gray mr-2" />
                  <span className="text-sm text-text-gray">Next billing</span>
                </div>
                <span className="text-sm font-medium text-text-navy">
                  {subscriptionData.nextBilling}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <CreditCard size={16} className="text-text-gray mr-2" />
                  <span className="text-sm text-text-gray">Payment method</span>
                </div>
                <span className="text-sm font-medium text-text-navy">
                  {subscriptionData.paymentMethod}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Crown size={16} className="text-text-gray mr-2" />
                  <span className="text-sm text-text-gray">Annual cost</span>
                </div>
                <span className="text-sm font-medium text-text-navy">
                  ${subscriptionData.amount}/year
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Users size={16} className="text-text-gray mr-2" />
                  <span className="text-sm text-text-gray">Children covered</span>
                </div>
                <span className="text-sm font-medium text-text-navy">
                  {subscriptionData.childCount}
                </span>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-text-gray mb-4">
                Upgrade to Pro for premium features per child
              </p>
              
              <div className="space-y-2 text-xs text-text-gray mb-4">
                <div className="flex items-center">
                  <Check size={12} className="text-success-green mr-1" />
                  <span>$7.99/child/month (or $6.99/month yearly)</span>
                </div>
                <div className="flex items-center">
                  <Check size={12} className="text-success-green mr-1" />
                  <span>Family discounts for 2+ children</span>
                </div>
                <div className="flex items-center">
                  <Check size={12} className="text-success-green mr-1" />
                  <span>Advanced analytics per child</span>
                </div>
                <div className="flex items-center">
                  <Check size={12} className="text-success-green mr-1" />
                  <span>Unlimited quest packs</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 mt-4">
        {isProUser ? (
          <>
            {onManageBilling && (
              <button
                onClick={onManageBilling}
                className="flex-1 py-2 px-4 rounded-card font-medium text-text-gray border border-border-gray hover:bg-surface-gray transition-colors"
              >
                Manage Billing
              </button>
            )}
            
            <button className="flex-1 py-2 px-4 rounded-card font-medium text-error-red border border-error-red/20 hover:bg-error-red/5 transition-colors">
              Cancel Subscription
            </button>
          </>
        ) : (
          <button
            onClick={onUpgrade}
            className="w-full py-3 px-6 rounded-card font-semibold transition-all duration-200 transform active:scale-95 bg-gradient-to-r from-accent-yellow to-primary-green text-white hover:shadow-duolingo shadow-duolingo active:shadow-duolingo-pressed active:translate-y-1"
          >
            <Crown size={16} className="inline mr-2" />
            Upgrade to Pro
          </button>
        )}
      </div>
    </div>
  );
};

export default SubscriptionStatus;