import React from 'react';
import { Shield, Clock } from 'lucide-react';

interface SafetyIndicatorProps {
  status: 'verified' | 'review' | 'pending';
  size?: 'sm' | 'md';
  showLabel?: boolean;
}

const SafetyIndicator: React.FC<SafetyIndicatorProps> = ({ 
  status, 
  size = 'md', 
  showLabel = false 
}) => {
  const getIndicatorConfig = () => {
    switch (status) {
      case 'verified':
        return {
          icon: Shield,
          color: 'text-success-green',
          bgColor: 'bg-success-green/10',
          label: 'Verified Safe'
        };
      case 'review':
        return {
          icon: Shield,
          color: 'text-warning-yellow',
          bgColor: 'bg-warning-yellow/10',
          label: 'Under Review'
        };
      case 'pending':
        return {
          icon: Clock,
          color: 'text-info-blue',
          bgColor: 'bg-info-blue/10',
          label: 'Processing'
        };
      default:
        return {
          icon: Shield,
          color: 'text-text-gray',
          bgColor: 'bg-surface-gray',
          label: 'Unknown'
        };
    }
  };

  const config = getIndicatorConfig();
  const Icon = config.icon;
  const iconSize = size === 'sm' ? 14 : 16;

  return (
    <div className={`
      inline-flex items-center gap-1.5 px-2 py-1 rounded-full
      ${config.bgColor}
    `}>
      <Icon size={iconSize} className={config.color} />
      {showLabel && (
        <span className={`text-xs font-medium ${config.color}`}>
          {config.label}
        </span>
      )}
    </div>
  );
};

export default SafetyIndicator;