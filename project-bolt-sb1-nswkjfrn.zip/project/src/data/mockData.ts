import { Quest, User, LeaderboardEntry, Badge, QuestPack } from '../types';
import { ShareableCreation, FriendsLeague, UserTier, WeeklyProgressCard, CommunityMilestone } from '../types';

export const mockUser: User = {
  id: '1',
  name: 'Alex',
  avatar: '🦊',
  level: 12,
  xp: 2450,
  xpToNextLevel: 550,
  streak: 7,
  rank: 12, // Keep for internal use but don't display to kids
  joinDate: '2024-01-15',
  screenTime: 125,
  safetyScore: 98
};

export const mockQuests: Quest[] = [
  {
    id: '1',
    title: 'Creative Story Builder',
    description: 'Write an imaginative story with AI help about a magical forest adventure',
    type: 'chat',
    difficulty: 'easy',
    xpValue: 150,
    duration: 5,
    thumbnail: 'https://images.pexels.com/photos/1496372/pexels-photo-1496372.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: false,
    tags: ['creative', 'writing', 'storytelling'],
    completedBy: 1247
  },
  {
    id: '2',
    title: 'Space Explorer Art',
    description: 'Create amazing space scenes with AI image generation',
    type: 'image',
    difficulty: 'medium',
    xpValue: 200,
    duration: 4,
    thumbnail: 'https://images.pexels.com/photos/2156/sky-earth-space-working.jpg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: true,
    tags: ['art', 'space', 'creative'],
    completedBy: 892
  },
  {
    id: '3',
    title: 'Animal Facts Detective',
    description: 'Research and discover amazing facts about your favorite animals',
    type: 'search',
    difficulty: 'easy',
    xpValue: 120,
    duration: 3,
    thumbnail: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: false,
    tags: ['research', 'animals', 'facts'],
    completedBy: 2134
  },
  {
    id: '4',
    title: 'Robot Friend Designer',
    description: 'Chat with AI to design your perfect robot companion',
    type: 'chat',
    difficulty: 'medium',
    xpValue: 180,
    duration: 6,
    thumbnail: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: false,
    tags: ['design', 'technology', 'creative'],
    completedBy: 756
  },
  {
    id: '5',
    title: 'Underwater World Creator',
    description: 'Generate beautiful underwater scenes with sea creatures',
    type: 'image',
    difficulty: 'hard',
    xpValue: 250,
    duration: 5,
    thumbnail: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: true,
    tags: ['ocean', 'art', 'nature'],
    completedBy: 423
  },
  {
    id: '6',
    title: 'Dinosaur Time Machine',
    description: 'Research prehistoric life and create your own dinosaur encyclopedia',
    type: 'search',
    difficulty: 'medium',
    xpValue: 160,
    duration: 4,
    thumbnail: 'https://images.pexels.com/photos/3568014/pexels-photo-3568014.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    isPremium: false,
    tags: ['dinosaurs', 'history', 'research'],
    completedBy: 1678
  }
];

export const mockLeaderboard: LeaderboardEntry[] = [
  {
    id: '1',
    name: 'Emma',
    avatar: '🐰',
    xp: 4250,
    rank: 1,
    previousRank: 1,
    level: 18,
    streak: 12
  },
  {
    id: '2',
    name: 'Marcus',
    avatar: '🐺',
    xp: 3980,
    rank: 2,
    previousRank: 3,
    level: 17,
    streak: 8
  },
  {
    id: '3',
    name: 'Sophia',
    avatar: '🦌',
    xp: 3756,
    rank: 3,
    previousRank: 2,
    level: 16,
    streak: 15
  },
  {
    id: '4',
    name: 'Alex',
    avatar: '🦊',
    xp: 2450,
    rank: 23,
    previousRank: 25,
    level: 12,
    streak: 7
  }
];

export const mockBadges: Badge[] = [
  {
    id: 'first-quest',
    name: 'First Quest',
    description: 'Complete your very first quest',
    icon: '🎯',
    rarity: 'common'
  },
  {
    id: 'streak-master',
    name: 'Streak Master',
    description: 'Maintain a 7-day streak',
    icon: '🔥',
    rarity: 'rare'
  },
  {
    id: 'creative-genius',
    name: 'Creative Genius',
    description: 'Complete 10 creative quests',
    icon: '🎨',
    rarity: 'epic'
  },
  {
    id: 'explorer',
    name: 'Explorer',
    description: 'Complete quests in all categories',
    icon: '🗺️',
    rarity: 'legendary'
  },
  {
    id: 'early-bird',
    name: 'Early Bird',
    description: 'Complete a quest before 9 AM',
    icon: '🌅',
    rarity: 'common'
  }
];

export const mockQuestPacks: QuestPack[] = [
  {
    id: '1',
    title: 'Space Adventures',
    description: 'Explore the cosmos with 12 space-themed quests',
    price: 4.99,
    questCount: 12,
    thumbnail: 'https://images.pexels.com/photos/2156/sky-earth-space-working.jpg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    tags: ['space', 'science', 'adventure'],
    difficulty: 'medium'
  },
  {
    id: '2',
    title: 'Magical Creatures',
    description: 'Meet dragons, unicorns, and more in 15 magical quests',
    price: 4.99,
    questCount: 15,
    thumbnail: 'https://images.pexels.com/photos/1496372/pexels-photo-1496372.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    tags: ['fantasy', 'creatures', 'creative'],
    difficulty: 'easy'
  },
  {
    id: '3',
    title: 'Ocean Depths',
    description: 'Dive deep into underwater adventures with 10 ocean quests',
    price: 4.99,
    questCount: 10,
    thumbnail: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    tags: ['ocean', 'marine', 'exploration'],
    difficulty: 'hard'
  }
];

export const userTiers: UserTier[] = [
  {
    name: 'Seedling',
    minXp: 0,
    maxXp: 999,
    icon: '🌱',
    color: 'from-blue-400 to-blue-600',
    nextTier: 'Sapling'
  },
  {
    name: 'Sapling',
    minXp: 1000,
    maxXp: 2999,
    icon: '🌿',
    color: 'from-green-400 to-green-600',
    nextTier: 'Ancient Tree'
  },
  {
    name: 'Ancient Tree',
    minXp: 3000,
    maxXp: Infinity,
    icon: '🌳',
    color: 'from-yellow-400 to-yellow-600'
  }
];

export const mockWeeklyProgressCard: WeeklyProgressCard = {
  id: 'progress-week-1',
  userId: '1',
  weekStart: '2024-01-15',
  currentTier: 'Trailblazer',
  nextTier: 'Wizard',
  xpProgress: 2450,
  xpToNext: 550,
  isNewTier: true,
  hasShown: false
};

export const mockCommunityMilestones: CommunityMilestone[] = [
  {
    id: 'milestone-1',
    title: 'City Explorers Unite!',
    description: 'Springfield kids completed 10,000 quests together',
    target: 10000,
    current: 8750,
    reward: 'Special Explorer Badge for everyone!',
    isCompleted: false
  },
  {
    id: 'milestone-2',
    title: 'Creative Community',
    description: 'Our community created 1,000 amazing stories',
    target: 1000,
    current: 1000,
    reward: 'Storyteller Badge unlocked!',
    isCompleted: true,
    completedAt: '2024-01-10'
  }
];

export const mockShareableCreations: ShareableCreation[] = [
  {
    id: 'creation-1',
    questId: '1',
    childId: 'kid1',
    title: 'The Magical Forest Adventure',
    description: 'A wonderful story about Sir Fluffy saving forest animals',
    type: 'story',
    content: 'Once upon a time, there was a brave knight named Sir Fluffy who could talk to all animals. One day, he heard that a family of rabbits needed help because a mean dragon had taken their home. Sir Fluffy put on his shiny armor and rode his horse to the magical forest...',
    createdAt: '2024-01-20T14:30:00Z',
    isPublic: true
  },
  {
    id: 'creation-2',
    questId: '4',
    childId: 'kid1',
    title: 'Pancake Bot Design',
    description: 'A friendly robot that helps with homework and makes pancakes',
    type: 'artwork',
    content: 'My robot friend Pancake Bot looks like a big teddy bear with blue and green lights! It can help me with homework, play games, and make the most delicious pancakes. The best part is that it can also help other kids who don\'t have friends.',
    thumbnail: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    createdAt: '2024-01-19T16:45:00Z',
    isPublic: true
  },
  {
    id: 'creation-3',
    questId: '2',
    childId: 'kid2',
    title: 'Candy Planet Discovery',
    thumbnail: 'https://images.pexels.com/photos/1496372/pexels-photo-1496372.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    createdAt: '2024-01-20T14:30:00Z',
    isPublic: true
  },
  {
    id: 'creation-2',
    questId: '4',
    childId: 'kid1',
    title: 'Pancake Bot - The Helpful Robot Friend',
    description: 'A teddy bear robot with blue and green lights that helps with homework and makes pancakes.',
    type: 'artwork' as const,
    content: 'My robot friend Pancake Bot looks like a big teddy bear but with cool blue and green lights! It can help me with homework and play games and maybe cook pancakes! And maybe it could also help other kids who don\'t have friends.',
    thumbnail: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    createdAt: '2024-01-19T16:45:00Z',
    isPublic: true
  },
  {
    id: 'creation-3',
    questId: '2',
    childId: 'kid2',
    title: 'The Amazing Candy Planet',
    description: 'A space exploration discovering a planet made entirely of candy with safety considerations.',
    type: 'research' as const,
    content: 'I discovered a planet where everything is made of candy! There are gummy bear trees and cotton candy clouds, and mountains of chocolate with rivers of caramel. But I\'m worried the astronauts might get sick from eating too much, so they should just take small samples to study and share with scientists on Earth!',
    thumbnail: 'https://images.pexels.com/photos/2156/sky-earth-space-working.jpg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=2',
    createdAt: '2024-01-18T10:15:00Z',
    isPublic: true
  }
];

export const mockFriendsLeagues = [
  {
    id: 'neighborhood-1',
    name: 'Maple Street Kids',
    type: 'neighborhood' as const,
    childId: 'kid1',
    location: 'Maple Street, Springfield',
    members: [
      {
        id: 'maple-1',
        name: 'Emma',
        avatar: '🐰',
        xp: 3240,
        rank: 1,
        previousRank: 1,
        level: 16,
        streak: 14
      },
      {
        id: 'maple-2',
        name: 'Liam',
        avatar: '🦁',
        xp: 2890,
        rank: 2,
        previousRank: 3,
        level: 14,
        streak: 8
      },
      {
        id: 'maple-3',
        name: 'Sophia',
        avatar: '🦋',
        xp: 2650,
        rank: 3,
        previousRank: 2,
        level: 13,
        streak: 11
      },
      {
        id: 'kid1',
        name: 'Alex',
        avatar: '🦊',
        xp: 2450,
        rank: 4,
        previousRank: 4,
        level: 12,
        streak: 7
      },
      {
        id: 'maple-4',
        name: 'Noah',
        avatar: '🐻',
        xp: 2280,
        rank: 5,
        previousRank: 5,
        level: 11,
        streak: 6
      },
      {
        id: 'maple-5',
        name: 'Olivia',
        avatar: '🦄',
        xp: 2150,
        rank: 6,
        previousRank: 6,
        level: 10,
        streak: 9
      }
    ]
  },
  {
    id: 'school-1',
    name: 'Lincoln Elementary 3rd Grade',
    type: 'school' as const,
    childId: 'kid1',
    location: 'Lincoln Elementary School',
    members: [
      {
        id: 'lincoln-1',
        name: 'Isabella',
        avatar: '🌸',
        xp: 3450,
        rank: 1,
        previousRank: 1,
        level: 17,
        streak: 16
      },
      {
        id: 'lincoln-2',
        name: 'Mason',
        avatar: '🚀',
        xp: 3120,
        rank: 2,
        previousRank: 2,
        level: 15,
        streak: 12
      },
      {
        id: 'lincoln-3',
        name: 'Ava',
        avatar: '🌺',
        xp: 2980,
        rank: 3,
        previousRank: 4,
        level: 14,
        streak: 13
      },
      {
        id: 'lincoln-4',
        name: 'Ethan',
        avatar: '⚡',
        xp: 2750,
        rank: 4,
        previousRank: 3,
        level: 13,
        streak: 9
      },
      {
        id: 'lincoln-5',
        name: 'Charlotte',
        avatar: '🎨',
        xp: 2620,
        rank: 5,
        previousRank: 5,
        level: 13,
        streak: 7
      },
      {
        id: 'kid1',
        name: 'Alex',
        avatar: '🦊',
        xp: 2450,
        rank: 6,
        previousRank: 7,
        level: 12,
        streak: 7
      },
      {
        id: 'lincoln-6',
        name: 'Lucas',
        avatar: '🎯',
        xp: 2380,
        rank: 7,
        previousRank: 6,
        level: 11,
        streak: 10
      },
      {
        id: 'lincoln-7',
        name: 'Amelia',
        avatar: '🌟',
        xp: 2290,
        rank: 8,
        previousRank: 8,
        level: 12,
        streak: 5
      }
    ]
  },
  {
    id: 'age-group-1',
    name: 'Age 8-9 Champions',
    type: 'age_group' as const,
    childId: 'kid1',
    ageRange: '8-9 years',
    members: [
      {
        id: 'age-1',
        name: 'Zoe',
        avatar: '👑',
        xp: 4850,
        rank: 1,
        previousRank: 1,
        level: 24,
        streak: 28
      },
      {
        id: 'age-2',
        name: 'Jackson',
        avatar: '🏆',
        xp: 4720,
        rank: 2,
        previousRank: 3,
        level: 23,
        streak: 25
      },
      {
        id: 'age-3',
        name: 'Luna',
        avatar: '🌙',
        xp: 4650,
        rank: 3,
        previousRank: 2,
        level: 23,
        streak: 22
      },
      {
        id: 'kid1',
        name: 'Alex',
        avatar: '🦊',
        xp: 2450,
        rank: 1247,
        previousRank: 1289,
        level: 12,
        streak: 7
      },
      {
        id: 'age-4',
        name: 'Kai',
        avatar: '🌊',
        xp: 2420,
        rank: 1248,
        previousRank: 1250,
        level: 12,
        streak: 9
      }
    ]
  },
  {
    id: 'neighborhood-2',
    name: 'Oakwood Community',
    type: 'neighborhood' as const,
    childId: 'kid2',
    location: 'Oakwood District, Springfield',
    members: [
      {
        id: 'kid2',
        name: 'Emma',
        avatar: '🐰',
        xp: 4250,
        rank: 1,
        previousRank: 1,
        level: 18,
        streak: 12
      },
      {
        id: 'oak-1',
        name: 'Oliver',
        avatar: '🌳',
        xp: 4120,
        rank: 2,
        previousRank: 2,
        level: 17,
        streak: 19
      },
      {
        id: 'oak-2',
        name: 'Harper',
        avatar: '🎭',
        xp: 3890,
        rank: 3,
        previousRank: 3,
        level: 19,
        streak: 15
      },
      {
        id: 'oak-3',
        name: 'Sebastian',
        avatar: '🎪',
        xp: 3650,
        rank: 4,
        previousRank: 4,
        level: 18,
        streak: 13
      },
      {
        id: 'oak-4',
        name: 'Aria',
        avatar: '🎵',
        xp: 3480,
        rank: 5,
        previousRank: 5,
        level: 17,
        streak: 11
      }
    ]
  }
];