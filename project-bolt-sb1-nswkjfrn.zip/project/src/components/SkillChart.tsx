import React from 'react';
import { useApp } from '../contexts/AppContext';

const SkillChart: React.FC = () => {
  const { completedQuests, quests } = useApp();

  // Calculate skill levels based on completed quests
  const completedQuestData = quests.filter(q => completedQuests.includes(q.id));
  
  const skills = {
    creativity: Math.min(completedQuestData.filter(q => q.tags.includes('creative')).length * 20, 100),
    logic: Math.min(completedQuestData.filter(q => q.tags.includes('research')).length * 25, 100),
    communication: Math.min(completedQuestData.filter(q => q.type === 'chat').length * 30, 100),
    research: Math.min(completedQuestData.filter(q => q.type === 'search').length * 25, 100)
  };

  const skillData = [
    { name: 'Creativity', value: skills.creativity, color: 'from-pink-400 to-purple-500', icon: '🎨' },
    { name: 'Logic', value: skills.logic, color: 'from-blue-400 to-blue-600', icon: '🧩' },
    { name: 'Communication', value: skills.communication, color: 'from-green-400 to-green-600', icon: '💬' },
    { name: 'Research', value: skills.research, color: 'from-yellow-400 to-orange-500', icon: '🔍' }
  ];

  return (
    <div className="space-y-4">
      {skillData.map((skill) => (
        <div key={skill.name} className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-xl mr-2">{skill.icon}</span>
              <span className="font-medium text-gray-800">{skill.name}</span>
            </div>
            <span className="font-bold text-primary-green">
              {skill.value}%
            </span>
          </div>
          
          <div className="h-3 bg-surface-gray rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-primary-green to-primary-blue transition-all duration-1000 ease-out"
              style={{ width: `${skill.value}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

export default SkillChart;