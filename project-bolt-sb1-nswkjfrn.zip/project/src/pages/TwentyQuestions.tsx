import React, { useState, useEffect } from 'react';
import { ArrowLeft, Mic, MicOff, MessageSquare, Brain, Lightbulb, Target, Sparkles, TreePine, Leaf } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';

interface GameState {
  secretObject: string;
  questionsAsked: string[];
  answersGiven: string[];
  questionsRemaining: number;
  gameStatus: 'playing' | 'won' | 'lost';
  currentQuestion: string;
  isThinking: boolean;
  hints: string[];
  hintsUsed: number;
}

const TwentyQuestions: React.FC = () => {
  const navigate = useNavigate();
  const { user, completeTile } = useApp();
  
  const [gameState, setGameState] = useState<GameState>({
    secretObject: '',
    questionsAsked: [],
    answersGiven: [],
    questionsRemaining: 20,
    gameStatus: 'playing',
    currentQuestion: '',
    isThinking: false,
    hints: [],
    hintsUsed: 0
  });
  
  const [isListening, setIsListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [showGuessDialog, setShowGuessDialog] = useState(false);
  const [finalGuess, setFinalGuess] = useState('');
  const [xp, setXp] = useState(0);
  const [cogwoodLeaves, setCogwoodLeaves] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);

  // Forest creatures for the game
  const forestCreatures = [
    'wise owl', 'playful squirrel', 'gentle deer', 'busy beaver', 'curious fox',
    'singing bird', 'hopping rabbit', 'climbing bear', 'swimming fish', 'buzzing bee'
  ];

  useEffect(() => {
    // Check for voice support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    setVoiceSupported(!!SpeechRecognition);
    
    // Initialize game
    initializeGame();
  }, []);

  const initializeGame = () => {
    const randomCreature = forestCreatures[Math.floor(Math.random() * forestCreatures.length)];
    setGameState(prev => ({
      ...prev,
      secretObject: randomCreature,
      questionsAsked: [],
      answersGiven: [],
      questionsRemaining: 20,
      gameStatus: 'playing',
      hints: generateHints(randomCreature),
      hintsUsed: 0
    }));
  };

  const generateHints = (creature: string): string[] => {
    const hintMap: { [key: string]: string[] } = {
      'wise owl': ['It flies at night', 'It has big round eyes', 'It makes a "hoot" sound'],
      'playful squirrel': ['It climbs trees', 'It collects nuts', 'It has a bushy tail'],
      'gentle deer': ['It has antlers', 'It runs very fast', 'It eats plants'],
      'busy beaver': ['It builds dams', 'It has big front teeth', 'It loves water'],
      'curious fox': ['It has a red coat', 'It\'s very clever', 'It has a pointed snout'],
      'singing bird': ['It has colorful feathers', 'It makes beautiful sounds', 'It builds nests'],
      'hopping rabbit': ['It has long ears', 'It hops instead of walks', 'It loves carrots'],
      'climbing bear': ['It\'s big and strong', 'It loves honey', 'It sleeps in winter'],
      'swimming fish': ['It lives in water', 'It has scales', 'It breathes through gills'],
      'buzzing bee': ['It makes honey', 'It has yellow stripes', 'It helps flowers grow']
    };
    
    return hintMap[creature] || ['It lives in the forest', 'It\'s a wonderful creature', 'You\'ll love learning about it'];
  };

  const handleBack = () => {
    navigate('/');
  };

  const startVoiceRecognition = () => {
    if (!voiceSupported) return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setGameState(prev => ({ ...prev, currentQuestion: transcript }));
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const askQuestion = async () => {
    if (!gameState.currentQuestion.trim() || gameState.isThinking) return;

    const question = gameState.currentQuestion.trim();
    
    setGameState(prev => ({
      ...prev,
      questionsAsked: [...prev.questionsAsked, question],
      questionsRemaining: prev.questionsRemaining - 1,
      isThinking: true,
      currentQuestion: ''
    }));

    // Simulate AI thinking
    setTimeout(() => {
      const answer = generateAnswer(question, gameState.secretObject);
      
      setGameState(prev => ({
        ...prev,
        answersGiven: [...prev.answersGiven, answer],
        isThinking: false
      }));
      
      setXp(prev => prev + 10);
      
      // Check if it's time to guess
      if (gameState.questionsRemaining <= 1) {
        setTimeout(() => setShowGuessDialog(true), 1000);
      }
    }, 2000);
  };

  const generateAnswer = (question: string, secretObject: string): string => {
    const lowerQuestion = question.toLowerCase();
    const lowerObject = secretObject.toLowerCase();
    
    // Simple keyword matching for demo
    if (lowerQuestion.includes('fly') && lowerObject.includes('owl')) return 'Yes! 🟢';
    if (lowerQuestion.includes('climb') && (lowerObject.includes('squirrel') || lowerObject.includes('bear'))) return 'Yes! 🟢';
    if (lowerQuestion.includes('water') && (lowerObject.includes('beaver') || lowerObject.includes('fish'))) return 'Yes! 🟢';
    if (lowerQuestion.includes('big') && (lowerObject.includes('bear') || lowerObject.includes('deer'))) return 'Yes! 🟢';
    if (lowerQuestion.includes('small') && (lowerObject.includes('bee') || lowerObject.includes('bird'))) return 'Yes! 🟢';
    
    // Random yes/no for other questions
    return Math.random() > 0.6 ? 'Yes! 🟢' : 'No 🔴';
  };

  const makeGuess = () => {
    if (!finalGuess.trim()) return;
    
    const isCorrect = finalGuess.toLowerCase().includes(gameState.secretObject.toLowerCase()) ||
                     gameState.secretObject.toLowerCase().includes(finalGuess.toLowerCase());
    
    if (isCorrect) {
      setGameState(prev => ({ ...prev, gameStatus: 'won' }));
      setXp(prev => prev + 100);
      setCogwoodLeaves(prev => prev + 2);
      setShowSuccess(true);
      
      // Complete the tile and return to home
      setTimeout(() => {
        completeTile('tile-2');
        navigate('/');
      }, 3000);
    } else {
      setGameState(prev => ({ ...prev, gameStatus: 'lost' }));
    }
    
    setShowGuessDialog(false);
  };

  const useHint = () => {
    if (gameState.hintsUsed >= gameState.hints.length) return;
    
    setGameState(prev => ({
      ...prev,
      hintsUsed: prev.hintsUsed + 1
    }));
    
    setXp(prev => prev - 5); // Small XP cost for hints
  };

  const restartGame = () => {
    initializeGame();
    setXp(0);
    setCogwoodLeaves(0);
    setShowSuccess(false);
    setShowGuessDialog(false);
    setFinalGuess('');
  };

  const getAnswerEmoji = (answer: string) => {
    if (answer.includes('🟢')) return '🟢';
    if (answer.includes('🔴')) return '🔴';
    return '🟡';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 via-indigo-50 to-blue-50 relative overflow-hidden">
      {/* Forest Background Elements with Brain Theme */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-purple-600">🧠</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-indigo-700">🌲</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-purple-500">💭</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-indigo-800">🧠</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-purple-600">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-indigo-700">💭</div>
        
        {/* Floating Brain Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-purple-400 animate-bounce">🧠</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-indigo-500 animate-pulse">💭</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-purple-500 animate-bounce">🎯</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-indigo-400 animate-pulse">🧠</div>
      </div>

      {/* Voice Listening Indicator */}
      {isListening && (
        <div className="fixed top-0 left-0 right-0 bg-red-500 text-white py-2 px-4 z-50 animate-ping">
          <div className="text-center">
            🎤 Listening for your forest question...
          </div>
        </div>
      )}

      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-purple-200 shadow-sm px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-purple-100 hover:bg-purple-200 transition-colors mr-3"
            >
              <ArrowLeft size={20} className="text-purple-600" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                <div className={`mr-2 transition-all duration-300 ${gameState.isThinking ? 'animate-pulse text-purple-500' : 'text-purple-600'}`}>
                  <Brain size={20} />
                </div>
                <h1 className="font-bold text-purple-800 text-lg truncate">
                  🧠 20 Forest Questions
                </h1>
              </div>
              <div className="flex items-center text-sm text-purple-600">
                <span>Questions: {gameState.questionsRemaining}/20</span>
                <span className="mx-2">•</span>
                <span>XP: {xp}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center bg-yellow-100 rounded-full px-3 py-2 border border-yellow-200">
            <TreePine size={16} className="text-purple-600 mr-2" />
            <span className="font-bold text-purple-700">{cogwoodLeaves}</span>
            <span className="text-purple-600 ml-1 text-xs">Cogwood</span>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-purple-600 mb-2">
            <span>Forest Detective Progress</span>
            <span>{Math.round(((20 - gameState.questionsRemaining) / 20) * 100)}%</span>
          </div>
          <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-purple-500 to-indigo-500"
              style={{ width: `${((20 - gameState.questionsRemaining) / 20) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-6 pb-24 max-w-md mx-auto">
        {/* Game Introduction */}
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200 mb-6">
          <div className="text-center">
            <div className="text-4xl mb-3 animate-bounce">🎯</div>
            <h2 className="font-bold text-purple-800 text-xl mb-2">
              Forest Creature Mystery
            </h2>
            <p className="text-purple-600 text-base mb-4">
              I'm thinking of a forest creature! Ask yes or no questions to discover what it is.
            </p>
            <div className="bg-purple-50 rounded-2xl border border-purple-200 p-4">
              <p className="text-purple-700 text-sm">
                🌲 Use your detective skills to solve the mystery in 20 questions or less!
              </p>
            </div>
          </div>
        </div>

        {/* Voice Support Indicator */}
        {voiceSupported && (
          <div className="bg-green-50 rounded-2xl border border-green-200 p-3 mb-4">
            <div className="flex items-center justify-center text-green-700 text-sm">
              <Mic size={16} className="mr-2" />
              🎤 Voice questions available! Tap the microphone to speak.
            </div>
          </div>
        )}

        {/* Question Input */}
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200 mb-6">
          <h3 className="font-semibold text-purple-800 text-lg mb-4 flex items-center">
            💭 Ask Your Forest Question
          </h3>
          
          <div className="relative mb-4">
            <MessageSquare size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-purple-400" />
            <input
              type="text"
              value={gameState.currentQuestion}
              onChange={(e) => setGameState(prev => ({ ...prev, currentQuestion: e.target.value }))}
              onKeyPress={(e) => e.key === 'Enter' && askQuestion()}
              placeholder="Ask a yes or no question..."
              className="w-full pl-12 pr-16 py-4 border border-purple-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 bg-purple-50 text-purple-800 placeholder-purple-400"
              disabled={gameState.isThinking || gameState.questionsRemaining <= 0}
            />
            
            {voiceSupported && (
              <button
                onClick={startVoiceRecognition}
                disabled={isListening || gameState.isThinking}
                className={`absolute right-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full transition-all duration-200 ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse' 
                    : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
                }`}
              >
                {isListening ? <MicOff size={16} /> : <Mic size={16} />}
              </button>
            )}
          </div>
          
          <button
            onClick={askQuestion}
            disabled={!gameState.currentQuestion.trim() || gameState.isThinking || gameState.questionsRemaining <= 0}
            className={`w-full py-4 px-6 rounded-2xl font-bold transition-all duration-200 transform active:scale-95 ${
              !gameState.currentQuestion.trim() || gameState.isThinking || gameState.questionsRemaining <= 0
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white hover:from-purple-600 hover:to-indigo-700 shadow-lg'
            }`}
          >
            {gameState.isThinking ? (
              <div className="flex items-center justify-center">
                <Brain size={20} className="mr-2 animate-spin" />
                Forest AI Thinking...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <Target size={20} className="mr-2 animate-bounce" />
                Ask Question ({gameState.questionsRemaining} left)
              </div>
            )}
          </button>
        </div>

        {/* Make a Guess Button */}
        {gameState.questionsAsked.length > 0 && gameState.gameStatus === 'playing' && (
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200 mb-6">
            <h3 className="font-semibold text-purple-800 text-lg mb-4 flex items-center">
              🎯 Ready to Solve the Mystery?
            </h3>
            
            <p className="text-purple-600 text-sm mb-4 text-center">
              Think you know what forest creature I'm thinking of? Make your guess!
            </p>
            
            <button
              onClick={() => setShowGuessDialog(true)}
              className="w-full py-4 px-6 rounded-2xl font-bold text-white bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 transition-colors shadow-lg transform active:scale-95"
            >
              <Target size={20} className="mr-2 inline animate-pulse" />
              🌟 Make My Guess!
            </button>
          </div>
        )}

        {/* Forest Wisdom (Hints) */}
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200 mb-6">
          <h3 className="font-semibold text-purple-800 text-lg mb-4 flex items-center">
            🌳 Forest Wisdom
          </h3>
          
          {gameState.hintsUsed < gameState.hints.length ? (
            <div className="text-center">
              <p className="text-purple-600 text-sm mb-4">
                The ancient trees whisper helpful clues...
              </p>
              <button
                onClick={useHint}
                className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white py-3 px-6 rounded-2xl font-bold hover:from-yellow-500 hover:to-orange-600 transition-colors shadow-md"
              >
                <Lightbulb size={16} className="mr-2 inline" />
                Get Forest Wisdom (-5 XP)
              </button>
            </div>
          ) : (
            <p className="text-purple-600 text-sm text-center">
              🌲 You've used all available wisdom from the forest trees.
            </p>
          )}
          
          {/* Show used hints */}
          {gameState.hintsUsed > 0 && (
            <div className="mt-4 space-y-2">
              {gameState.hints.slice(0, gameState.hintsUsed).map((hint, index) => (
                <div key={index} className="bg-yellow-50 rounded-xl border border-yellow-200 p-3">
                  <p className="text-yellow-800 text-sm">🌟 {hint}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Question History */}
        {gameState.questionsAsked.length > 0 && (
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200 mb-6">
            <h3 className="font-semibold text-purple-800 text-lg mb-4 flex items-center">
              📝 Forest Detective Notes
            </h3>
            
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {gameState.questionsAsked.map((question, index) => (
                <div key={index} className="flex items-start justify-between p-3 bg-purple-50 rounded-xl border border-purple-200">
                  <div className="flex-1">
                    <p className="text-purple-800 text-sm font-medium mb-1">
                      Q{index + 1}: {question}
                    </p>
                    <p className="text-purple-600 text-sm">
                      A: {gameState.answersGiven[index] || 'Thinking...'}
                    </p>
                  </div>
                  <div className="ml-3 text-xl">
                    {gameState.answersGiven[index] && getAnswerEmoji(gameState.answersGiven[index])}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cogwood Branch Growth */}
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-lg border border-purple-200">
          <h3 className="font-semibold text-purple-800 text-lg mb-4 flex items-center">
            🧠 Your Cogwood Branch
          </h3>
          
          <div className="relative">
            <div className="flex items-center justify-center mb-4">
              <div className="relative">
                <div className="w-32 h-20 relative">
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-2 h-8 bg-amber-700 rounded-t-sm"></div>
                  <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-16 h-12 bg-gradient-to-t from-purple-600 to-indigo-400 rounded-full">
                    {/* Cogwood leaves */}
                    {[...Array(cogwoodLeaves)].map((_, i) => (
                      <div key={i} 
                           className="absolute text-purple-400 animate-pulse text-sm"
                           style={{
                             left: `${20 + (i * 20) % 60}%`,
                             top: `${30 + (i * 15) % 40}%`,
                             animationDelay: `${i * 0.5}s`
                           }}>
                        🧠
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-purple-600 text-sm mb-2">
                🧠 {cogwoodLeaves} Cogwood Leaves earned
              </p>
              <div className="bg-purple-100 rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-indigo-400 transition-all duration-1000"
                  style={{ width: `${Math.min(cogwoodLeaves * 25, 100)}%` }}
                />
              </div>
              <p className="text-purple-600 text-xs mt-1">
                Branch Growth: {Math.min(cogwoodLeaves * 25, 100)}%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Guess Dialog */}
      {showGuessDialog && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full mx-4 shadow-2xl border border-purple-200">
            <div className="text-center">
              <div className="text-4xl mb-4 animate-bounce">🎯</div>
              <h3 className="font-bold text-purple-800 text-xl mb-2">
                Time to Guess!
              </h3>
              <p className="text-purple-600 text-sm mb-4">
                What forest creature am I thinking of?
              </p>
              
              <input
                type="text"
                value={finalGuess}
                onChange={(e) => setFinalGuess(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && makeGuess()}
                placeholder="Enter your guess..."
                className="w-full p-4 border border-purple-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 mb-4 text-center font-medium"
                autoFocus
              />
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowGuessDialog(false)}
                  className="flex-1 py-3 px-4 rounded-2xl font-medium text-purple-600 bg-purple-100 hover:bg-purple-200 transition-colors"
                >
                  Ask More Questions
                </button>
                <button
                  onClick={makeGuess}
                  disabled={!finalGuess.trim()}
                  className="flex-1 py-3 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 transition-colors shadow-md disabled:opacity-50"
                >
                  🎯 Final Guess!
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full mx-4 shadow-2xl border border-purple-200 text-center">
            <div className="text-6xl mb-4 animate-bounce">🎉</div>
            <h3 className="font-bold text-purple-800 text-2xl mb-2">
              Forest Mystery Solved!
            </h3>
            <p className="text-purple-600 text-base mb-4">
              You discovered the {gameState.secretObject}! Your detective skills are amazing!
            </p>
            <div className="bg-purple-50 rounded-2xl border border-purple-200 p-4 mb-4">
              <p className="text-purple-700 text-sm">
                🧠 +{cogwoodLeaves} Cogwood Leaves earned!
              </p>
            </div>
            <p className="text-purple-500 text-sm">
              Returning to Forest Trail...
            </p>
          </div>
        </div>
      )}

      {/* Game Over States */}
      {gameState.gameStatus === 'lost' && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full mx-4 shadow-2xl border border-purple-200">
            <div className="text-center">
              <div className="text-4xl mb-4">🤔</div>
              <h3 className="font-bold text-purple-800 text-xl mb-2">
                Mystery Remains!
              </h3>
              <p className="text-purple-600 text-sm mb-4">
                The forest creature was: <strong>{gameState.secretObject}</strong>
              </p>
              <p className="text-purple-600 text-sm mb-6">
                Great detective work! Try again to earn more Cogwood Leaves.
              </p>
              
              <div className="flex space-x-3">
                <button
                  onClick={handleBack}
                  className="flex-1 py-3 px-4 rounded-2xl font-medium text-purple-600 bg-purple-100 hover:bg-purple-200 transition-colors"
                >
                  Back to Forest
                </button>
                <button
                  onClick={restartGame}
                  className="flex-1 py-3 px-4 rounded-2xl font-bold text-white bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 transition-colors shadow-md"
                >
                  🔄 Try Again
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Confetti for Success */}
      {showSuccess && (
        <div className="fixed inset-0 pointer-events-none z-40">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className={`absolute animate-bounce text-xl ${
                i % 4 === 0 ? 'text-purple-400' : 
                i % 4 === 1 ? 'text-indigo-400' : 
                i % 4 === 2 ? 'text-yellow-400' : 'text-pink-400'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 0.5}s`
              }}
            >
              {i % 4 === 0 ? '🧠' : i % 4 === 1 ? '🎯' : i % 4 === 2 ? '⭐' : '✨'}
            </div>
          ))}
        </div>
      )}

      {/* Idle Animation */}
      {gameState.questionsAsked.length === 0 && !gameState.isThinking && (
        <div className="fixed bottom-32 right-4 animate-bounce">
          <div className="bg-purple-100 rounded-full p-3 border border-purple-200 shadow-lg">
            <p className="text-purple-600 text-xs">💭 Forest Wisdom Whisper</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default TwentyQuestions;