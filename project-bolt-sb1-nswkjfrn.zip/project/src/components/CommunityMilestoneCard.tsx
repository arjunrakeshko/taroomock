import React from 'react';
import { Users, Gift, CheckCircle } from 'lucide-react';
import { CommunityMilestone } from '../types';

interface CommunityMilestoneCardProps {
  milestone: CommunityMilestone;
}

const CommunityMilestoneCard: React.FC<CommunityMilestoneCardProps> = ({ milestone }) => {
  const progress = Math.min((milestone.current / milestone.target) * 100, 100);
  
  return (
    <div className={`bg-white rounded-card p-6 shadow-card border-2 ${
      milestone.isCompleted 
        ? 'border-success-green bg-success-green/5' 
        : 'border-primary-blue/20'
    }`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
            milestone.isCompleted 
              ? 'bg-success-green text-white' 
              : 'bg-primary-blue/20 text-primary-blue'
          }`}>
            {milestone.isCompleted ? (
              <CheckCircle size={24} />
            ) : (
              <Users size={24} />
            )}
          </div>
          
          <div>
            <h3 className="font-quicksand font-semibold text-lg text-text-navy">
              {milestone.title}
            </h3>
            <p className="text-text-gray text-sm">
              {milestone.description}
            </p>
          </div>
        </div>
        
        {milestone.isCompleted && (
          <div className="text-2xl">🎉</div>
        )}
      </div>
      
      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between text-sm text-text-gray mb-2">
          <span>Community Progress</span>
          <span>{milestone.current.toLocaleString()} / {milestone.target.toLocaleString()}</span>
        </div>
        
        <div className="h-4 bg-surface-gray rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-1000 ease-out ${
              milestone.isCompleted 
                ? 'bg-gradient-to-r from-success-green to-green-400' 
                : 'bg-gradient-to-r from-primary-blue to-blue-400'
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      
      {/* Reward */}
      <div className={`flex items-center p-3 rounded-tile ${
        milestone.isCompleted 
          ? 'bg-success-green/10 border border-success-green/20' 
          : 'bg-accent-yellow/10 border border-accent-yellow/20'
      }`}>
        <Gift size={16} className={milestone.isCompleted ? 'text-success-green' : 'text-accent-yellow'} />
        <span className={`ml-2 text-sm font-medium ${
          milestone.isCompleted ? 'text-success-green' : 'text-text-navy'
        }`}>
          {milestone.reward}
        </span>
      </div>
      
      {milestone.isCompleted && milestone.completedAt && (
        <p className="text-xs text-text-gray mt-2 text-center">
          Completed {new Date(milestone.completedAt).toLocaleDateString()}
        </p>
      )}
    </div>
  );
};

export default CommunityMilestoneCard;