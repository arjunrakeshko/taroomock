import React, { useState, useEffect } from 'react';
import { ArrowLeft, Volume2, VolumeX, Send, Lightbulb, Shuffle, Edit3, Save, RotateCcw, Trophy, Star, Zap, Heart, BookOpen, Sparkles, Check } from 'lucide-react';

interface StoryData {
  character: string;
  setting: string;
  events: string;
  resolution: string;
}

interface StoryStep {
  id: string;
  title: string;
  prompt: string;
  placeholder: string;
  guide: string[];
  inspirations: string[];
}

const CreativeStoryBuilder: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [storyData, setStoryData] = useState<StoryData>({
    character: '',
    setting: '',
    events: '',
    resolution: ''
  });
  const [storyText, setStoryText] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedStory, setEditedStory] = useState('');
  const [cluesRemaining, setCluesRemaining] = useState([3, 3, 3, 3]);
  const [xp, setXp] = useState(0);
  const [hearts, setHearts] = useState(5);
  const [streak, setStreak] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [currentInput, setCurrentInput] = useState('');
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const storySteps: StoryStep[] = [
    {
      id: 'character',
      title: "Who's Your Main Character?",
      prompt: "Tell me about your main character! What are they like?",
      placeholder: "Describe your character's personality, appearance, or special traits...",
      guide: [
        "Give your character a unique personality trait",
        "Think about what makes them special or different",
        "Consider their age, background, or magical abilities",
        "What do they care about most?"
      ],
      inspirations: [
        "Meet [character name], a brave [age] year old who could [special ability] whenever they felt [emotion]. They had [unique trait] and always [what they do to help others].",
        "There once was a curious [character name] with [physical feature] who loved to [favorite activity]. Their greatest strength was [character strength] and they dreamed of [big dream].",
        "[Character name] was known throughout [place] for their [special talent]. Even though they were [character flaw], they never gave up when [challenging situation] because [motivation]."
      ]
    },
    {
      id: 'setting',
      title: "Where Does This Take Place?",
      prompt: "Paint me a picture of where your story happens!",
      placeholder: "Describe the world, time period, or magical place...",
      guide: [
        "Create atmosphere with sensory details (sounds, smells, sights)",
        "Think about the mood - is it mysterious, cheerful, dangerous?",
        "Consider the time period - past, present, future, or fantasy",
        "What makes this place special or unique?"
      ],
      inspirations: [
        "In the magical land of [place name], where [magical element] filled the air and [creatures] roamed freely through [landscape features]. The [weather/atmosphere] made everything feel [mood], and [unique feature] could be seen from miles away.",
        "Deep in [location type], there was a hidden [special place] that only appeared when [condition]. The [sensory detail] and [another sensory detail] made visitors feel [emotion] as they discovered [what's special about it].",
        "The story takes place in [time period] in a [type of place] where [unusual thing] happened every [time period]. People lived in [type of homes] and spent their days [daily activities] while [background activity] filled the [time of day]."
      ]
    },
    {
      id: 'events',
      title: "What Happens in Your Story?",
      prompt: "What exciting events unfold? What does your character discover or face?",
      placeholder: "Describe the main events, conflicts, or discoveries...",
      guide: [
        "Start with a discovery, problem, or unexpected event",
        "Build tension - what obstacles does your character face?",
        "Include action and dialogue to bring scenes to life",
        "Show how your character grows or changes"
      ],
      inspirations: [
        "One day, [character] discovered [mysterious object/place] that [what it did]. But when [problem occurred], they realized [important discovery]. '[Dialogue from character],' they said as [action they took] while [complication happened].",
        "Everything changed when [event happened]. [Character] had to [challenge] while [complication], but they remembered [lesson/advice] and decided to [brave action]. The [obstacle] seemed impossible until [turning point].",
        "The adventure began when [character] heard [sound/saw something] and decided to [action]. Little did they know that [plot twist] was waiting for them. As they [what they did], [unexpected ally/enemy] appeared and [what happened next]."
      ]
    },
    {
      id: 'resolution',
      title: "How Does It All Work Out?",
      prompt: "Bring your story to a satisfying conclusion! How does your character succeed?",
      placeholder: "Describe how the story ends and what your character learns...",
      guide: [
        "Show how your character uses what they've learned",
        "Resolve the main conflict in a creative way",
        "Include the character's growth or change",
        "End with hope, wisdom, or a new beginning"
      ],
      inspirations: [
        "In the end, [character] realized that [wisdom/lesson] was more important than [what they thought they wanted]. Using [skill/trait they developed], they [solution] and [positive outcome]. Everyone celebrated because [why it mattered], and [character] learned [final lesson].",
        "With [help/tool/realization], [character] was able to [solve problem] and [positive change]. The [place/people] were saved, and from that day forward, [how things changed]. [Character] became known as [new title/reputation] and [what they did next].",
        "[Character] discovered that the real [treasure/power/answer] was [meaningful conclusion] all along. They returned home [how they changed] and shared [what they learned] with [who they told]. The [place] was never the same because [lasting impact]."
      ]
    }
  ];

  const currentStepData = storySteps[currentStep];

  useEffect(() => {
    generateStoryText();
  }, [storyData]);

  useEffect(() => {
    // Initialize chat with AI greeting
    if (chatMessages.length === 0) {
      setChatMessages([
        {
          type: 'ai',
          content: `Welcome to Creative Story Builder! 🎨 I'm your AI writing assistant, and I'm so excited to help you create an amazing story! Let's start with your main character. Who is the hero of your adventure?`,
          timestamp: Date.now()
        }
      ]);
    }
  }, []);

  const generateStoryText = () => {
    let story = "Once upon a time...";
    
    if (storyData.character) {
      story = `Once upon a time, ${storyData.character}`;
    }
    
    if (storyData.setting) {
      story += ` ${storyData.setting}`;
    }
    
    if (storyData.events) {
      story += `\n\n${storyData.events}`;
    }
    
    if (storyData.resolution) {
      story += `\n\n${storyData.resolution}`;
    }

    setStoryText(story);
    setEditedStory(story);
  };

  const handleInputChange = (value: string) => {
    setCurrentInput(value);
  };

  const useInspiration = (inspiration: string) => {
    if (cluesRemaining[currentStep] > 0) {
      const newClues = [...cluesRemaining];
      newClues[currentStep]--;
      setCluesRemaining(newClues);
      
      setCurrentInput(inspiration);
    }
  };

  const getIdeas = () => {
    if (cluesRemaining[currentStep] > 0) {
      const newClues = [...cluesRemaining];
      newClues[currentStep]--;
      setCluesRemaining(newClues);
      
      const ideas = [
        "Try adding more sensory details - what does your character see, hear, or feel?",
        "Consider giving your character a unique quirk or special ability!",
        "What if something unexpected happens that changes everything?",
        "Think about what your character wants most and what's stopping them.",
        "Add some dialogue - what would your character say in this moment?"
      ];
      
      const randomIdea = ideas[Math.floor(Math.random() * ideas.length)];
      
      // Add AI response to chat
      const aiResponse = {
        type: 'ai',
        content: `💡 Here's a creative idea: ${randomIdea}`,
        timestamp: Date.now()
      };
      setChatMessages(prev => [...prev, aiResponse]);
    }
  };

  const surpriseMe = () => {
    if (cluesRemaining[currentStep] > 0) {
      const randomInspiration = currentStepData.inspirations[Math.floor(Math.random() * currentStepData.inspirations.length)];
      useInspiration(randomInspiration);
    }
  };

  const handleSendMessage = async () => {
    if (!currentInput.trim() || isGenerating) return;

    const userMessage = {
      type: 'user',
      content: currentInput,
      timestamp: Date.now()
    };

    setChatMessages(prev => [...prev, userMessage]);
    
    // Update story data
    const stepKey = currentStepData.id as keyof StoryData;
    setStoryData(prev => ({ ...prev, [stepKey]: currentInput }));
    
    setCurrentInput('');
    setIsGenerating(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        type: 'ai',
        content: generateAIResponse(currentInput, currentStep),
        timestamp: Date.now()
      };
      
      setChatMessages(prev => [...prev, aiResponse]);
      setIsGenerating(false);
      setXp(prev => prev + 25);
      setStreak(prev => prev + 1);
      
      if (isTTSEnabled) {
        speakText(aiResponse.content);
      }
    }, 2000);
  };

  const generateAIResponse = (input: string, step: number) => {
    const responses = [
      [
        "What an amazing character! I love how creative you are. Your hero sounds really special! 🌟",
        "Fantastic! Your character has such personality. I can already imagine their adventures! ✨",
        "Wonderful character creation! They sound like someone I'd love to read about. Great job! 🎭"
      ],
      [
        "What a magical place! I can picture it perfectly. Your world-building skills are incredible! 🏰",
        "Amazing setting! The atmosphere you've created is so vivid and exciting! 🌍",
        "Perfect! Your world sounds like the perfect place for an adventure. Brilliant work! 🗺️"
      ],
      [
        "Wow! What an exciting adventure! The plot twists and action are fantastic! 🎢",
        "Incredible events! Your story is getting so thrilling. I can't wait to see what happens next! ⚡",
        "Amazing storytelling! The way you've built the tension and excitement is masterful! 🎪"
      ],
      [
        "What a perfect ending! Your story is complete and beautiful. You're a natural storyteller! 🏆",
        "Brilliant conclusion! The way you wrapped everything up is so satisfying. Amazing work! 🎉",
        "Perfect resolution! Your character's journey is inspiring and your story is wonderful! ⭐"
      ]
    ];

    const stepResponses = responses[step] || responses[0];
    return stepResponses[Math.floor(Math.random() * stepResponses.length)];
  };

  const speakText = (text: string) => {
    if (isTTSEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }
  };

  const handleTTSToggle = () => {
    setIsTTSEnabled(!isTTSEnabled);
    if (!isTTSEnabled) {
      speakText("Text to speech is now enabled");
    }
  };

  const canContinue = () => {
    const currentValue = storyData[currentStepData.id as keyof StoryData];
    return currentValue.length > 20;
  };

  const canFinish = () => {
    const totalWords = storyText.split(' ').length;
    return totalWords > 100 && Object.values(storyData).filter(v => v.length > 0).length >= 2;
  };

  const nextStep = () => {
    if (currentStep < storySteps.length - 1) {
      setCurrentStep(prev => prev + 1);
      
      // Add AI message for next step
      const nextStepData = storySteps[currentStep + 1];
      const aiMessage = {
        type: 'ai',
        content: `Great! Now let's work on the next part. ${nextStepData.prompt}`,
        timestamp: Date.now()
      };
      setChatMessages(prev => [...prev, aiMessage]);
    } else {
      completeQuest();
    }
  };

  const completeQuest = () => {
    setIsCompleted(true);
    setShowCelebration(true);
    setXp(prev => prev + 100);
    
    setTimeout(() => {
      setShowCelebration(false);
    }, 3000);
  };

  const saveStoryEdit = () => {
    setStoryText(editedStory);
    setIsEditing(false);
  };

  const resetStoryEdit = () => {
    setEditedStory(storyText);
    setIsEditing(false);
  };

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 p-4">
        {showCelebration && (
          <div className="fixed inset-0 pointer-events-none z-50">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className={`absolute animate-confetti text-3xl ${
                  i % 4 === 0 ? 'text-yellow-400' : 
                  i % 4 === 1 ? 'text-pink-400' : 
                  i % 4 === 2 ? 'text-blue-400' : 'text-green-400'
                }`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 0.5}s`
                }}
              >
                ✨
              </div>
            ))}
          </div>
        )}
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-4">
                  <Trophy className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Quest Complete!</h1>
              <p className="text-xl text-gray-600">You've created an amazing story!</p>
              
              <div className="flex justify-center gap-6 mt-6">
                <div className="text-center">
                  <div className="bg-blue-100 rounded-full p-3 mb-2">
                    <Zap className="w-6 h-6 text-blue-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600">{xp}</div>
                  <div className="text-sm text-gray-600">XP Earned</div>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 rounded-full p-3 mb-2">
                    <BookOpen className="w-6 h-6 text-green-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-green-600">{storyText.split(' ').length}</div>
                  <div className="text-sm text-gray-600">Words Written</div>
                </div>
                <div className="text-center">
                  <div className="bg-purple-100 rounded-full p-3 mb-2">
                    <Sparkles className="w-6 h-6 text-purple-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600">{streak}</div>
                  <div className="text-sm text-gray-600">Creativity Score</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <div className="border-b border-gray-200 pb-4 mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Your Amazing Story</h2>
              <p className="text-gray-600">By: Young Author</p>
            </div>
            
            <div className="prose prose-lg max-w-none">
              <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                {storyText}
              </div>
            </div>
            
            <div className="flex gap-4 mt-8 pt-6 border-t border-gray-200">
              <button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg">
                Share Story
              </button>
              <button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-blue-600 transition-all duration-200 shadow-lg">
                Create Another
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex flex-col">
      {/* Header */}
      <div className="bg-white sticky top-0 z-40 px-4 py-4 border-b border-gray-200 safe-area-pt">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors mr-3">
              <ArrowLeft size={20} className="text-gray-600" />
            </button>
            <div className="flex-1 min-w-0">
              <h1 className="font-quicksand font-semibold text-lg text-gray-800 truncate">
                Creative Story Builder
              </h1>
              <div className="flex items-center text-sm text-gray-600">
                <span>Step {currentStep + 1} of {storySteps.length}</span>
                <span className="mx-2">•</span>
                <span>Clues: {cluesRemaining[currentStep]}/3</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-red-100 px-3 py-1 rounded-full">
              <Heart size={16} className="text-red-500" />
              <span className="text-red-600 font-semibold text-sm">{hearts}</span>
            </div>
            <div className="flex items-center gap-2 bg-yellow-100 px-3 py-1 rounded-full">
              <Zap size={16} className="text-yellow-600" />
              <span className="text-yellow-700 font-semibold text-sm">{xp}</span>
            </div>
            <button
              onClick={handleTTSToggle}
              className={`p-2 rounded-full transition-colors ${
                isTTSEnabled 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
              }`}
            >
              {isTTSEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Story Progress</span>
            <span>{Math.round(((currentStep + 1) / storySteps.length) * 100)}%</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-blue-500 to-green-500"
              style={{ width: `${((currentStep + 1) / storySteps.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Story Development Area */}
        <div className="flex-1 flex flex-col">
          {/* Story Preview */}
          <div className="bg-white border-b border-gray-200 p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-800">Your Story</h2>
              <div className="flex gap-2">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="bg-blue-100 text-blue-600 p-2 rounded-lg hover:bg-blue-200 transition-colors"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                {isEditing && (
                  <>
                    <button
                      onClick={saveStoryEdit}
                      className="bg-green-100 text-green-600 p-2 rounded-lg hover:bg-green-200 transition-colors"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={resetStoryEdit}
                      className="bg-gray-100 text-gray-600 p-2 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            </div>
            
            {isEditing ? (
              <textarea
                value={editedStory}
                onChange={(e) => setEditedStory(e.target.value)}
                className="w-full h-32 p-3 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Edit your story here..."
              />
            ) : (
              <div className="bg-gray-50 rounded-lg p-3 h-32 overflow-y-auto">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed text-sm">
                  {storyText || "Your story will appear here as you create it..."}
                </div>
              </div>
            )}
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] px-4 py-3 rounded-2xl ${
                  message.type === 'user'
                    ? 'bg-blue-500 text-white'
                    : 'bg-white text-gray-800 shadow-md'
                }`}>
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
              </div>
            ))}
            
            {isGenerating && (
              <div className="flex justify-start">
                <div className="max-w-[85%] px-4 py-3 rounded-2xl bg-white shadow-md">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Input Area */}
          <div className="bg-white border-t border-gray-200 p-4">
            <div className="mb-3">
              <h3 className="font-medium text-gray-800 mb-2">{currentStepData.title}</h3>
              <p className="text-sm text-gray-600">{currentStepData.prompt}</p>
            </div>

            {/* Inspiration Buttons */}
            <div className="flex gap-2 mb-3">
              <button
                onClick={getIdeas}
                disabled={cluesRemaining[currentStep] === 0}
                className="flex items-center gap-2 bg-yellow-500 text-white px-3 py-2 rounded-lg hover:bg-yellow-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed text-sm"
              >
                <Lightbulb className="w-4 h-4" />
                Get Ideas
              </button>
              <button
                onClick={surpriseMe}
                disabled={cluesRemaining[currentStep] === 0}
                className="flex items-center gap-2 bg-purple-500 text-white px-3 py-2 rounded-lg hover:bg-purple-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed text-sm"
              >
                <Shuffle className="w-4 h-4" />
                Surprise Me
              </button>
            </div>

            {/* Inspiration Templates */}
            <div className="mb-3 space-y-2">
              {currentStepData.inspirations.map((inspiration, index) => (
                <button
                  key={index}
                  onClick={() => useInspiration(inspiration)}
                  disabled={cluesRemaining[currentStep] === 0}
                  className="w-full text-left p-2 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors border border-gray-200 disabled:bg-gray-100 disabled:cursor-not-allowed text-xs"
                >
                  <p className="text-gray-700">{inspiration}</p>
                </button>
              ))}
            </div>

            <div className="flex items-end space-x-3">
              <textarea
                value={currentInput}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={currentStepData.placeholder}
                className="flex-1 px-3 py-2 rounded-lg border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                disabled={isGenerating}
                rows={2}
              />
              <button
                onClick={handleSendMessage}
                disabled={!currentInput.trim() || isGenerating}
                className={`p-2 rounded-full transition-all duration-200 transform active:scale-95 ${
                  !currentInput.trim() || isGenerating
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600 shadow-lg'
                }`}
                style={{ minWidth: '40px', minHeight: '40px' }}
              >
                <Send size={16} />
              </button>
            </div>

            {/* Continue/Finish Buttons */}
            {(canContinue() || canFinish()) && (
              <div className="flex gap-3 mt-3">
                {canContinue() && currentStep < storySteps.length - 1 && (
                  <button
                    onClick={nextStep}
                    className="flex-1 bg-blue-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-600 transition-colors text-sm"
                  >
                    Continue to Next Step
                  </button>
                )}
                
                {canFinish() && (
                  <button
                    onClick={completeQuest}
                    className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-600 transition-colors text-sm"
                  >
                    Finish Quest
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Writing Guide Sidebar */}
        <div className="w-80 bg-white border-l border-gray-200 p-4 hidden lg:block">
          <h3 className="font-semibold text-gray-800 mb-4">Writing Guide</h3>
          <div className="space-y-3">
            {currentStepData.guide.map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <Star className="w-3 h-3 text-blue-600" />
                </div>
                <p className="text-sm text-gray-700">{tip}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreativeStoryBuilder;