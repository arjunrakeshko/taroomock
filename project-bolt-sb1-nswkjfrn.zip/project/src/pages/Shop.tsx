import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Crown, Star, Users, Clock, ShoppingBag, Check, CreditCard, Settings } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { mockQuestPacks } from '../data/mockData';
import ProFeatureGate from '../components/ProFeatureGate';
import SubscriptionStatus from '../components/SubscriptionStatus';
import ProUpgradeModal from '../components/ProUpgradeModal';

const Shop: React.FC = () => {
  const navigate = useNavigate();
  const { activeProfile } = useApp();
  const [purchasedPacks, setPurchasedPacks] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'packs' | 'subscription' | 'billing'>('packs');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const handleBack = () => {
    navigate('/parent-dashboard');
  };

  const handlePurchase = (packId: string) => {
    // In production, this would integrate with payment processing
    setPurchasedPacks(prev => [...prev, packId]);
  };

  const handleUpgradeComplete = (plan: 'monthly' | 'yearly', childCount: number) => {
    // In production, this would handle the actual upgrade process
    console.log(`Upgrading to ${plan} plan for ${childCount} children`);
    
    // Update user's subscription status
    if (activeProfile?.parentData) {
      activeProfile.parentData.hasProSubscription = true;
      activeProfile.parentData.subscribedChildCount = childCount;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const tabs = [
    { key: 'packs', label: 'Quest Packs', icon: ShoppingBag },
    { key: 'subscription', label: 'Pro Subscription', icon: Crown },
    { key: 'billing', label: 'Billing', icon: CreditCard }
  ];

  const isProUser = activeProfile?.parentData?.hasProSubscription || false;

  return (
    <div className="min-h-screen bg-surface-gray">
      {/* Header */}
      <div className="bg-gradient-to-r from-accent-yellow to-primary-green px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            style={{ minWidth: '48px', minHeight: '48px' }}
          >
            <ArrowLeft size={20} className="text-white" />
          </button>
          
          <h1 className="font-quicksand font-bold text-xl text-white">
            Shop & Billing
          </h1>
          
          <div className="w-12"></div>
        </div>
        
        <div className="text-center text-white">
          <div className="w-16 h-16 mx-auto mb-4 bg-white/20 rounded-full flex items-center justify-center">
            <ShoppingBag size={32} className="text-white" />
          </div>
          <p className="text-white/90">
            Manage subscriptions and purchase content
          </p>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Tab Navigation */}
        <div className="bg-white rounded-card p-2 shadow-card flex mb-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 py-3 px-4 rounded-tile font-semibold text-sm transition-all duration-200 transform active:scale-95 flex items-center justify-center ${
                activeTab === tab.key
                  ? 'bg-primary-green text-white shadow-duolingo'
                  : 'text-text-gray hover:bg-surface-gray'
              }`}
            >
              <tab.icon size={16} className="mr-2" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'subscription' && (
          <div className="space-y-6">
            <SubscriptionStatus 
              onUpgrade={() => setShowUpgradeModal(true)}
              onManageBilling={() => setActiveTab('billing')}
            />

            {/* Pro Features */}
            <div className="bg-white rounded-card p-6 shadow-card">
              <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4">
                Pro Features
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-green/20 rounded-full flex items-center justify-center mr-3 mt-1">
                    <Check size={16} className="text-primary-green" />
                  </div>
                  <div>
                    <h4 className="font-medium text-text-navy">Unlimited Quest Packs</h4>
                    <p className="text-sm text-text-gray">Access to all current and future quest content</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-green/20 rounded-full flex items-center justify-center mr-3 mt-1">
                    <Check size={16} className="text-primary-green" />
                  </div>
                  <div>
                    <h4 className="font-medium text-text-navy">Advanced Analytics</h4>
                    <p className="text-sm text-text-gray">Detailed insights into your child's learning progress</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-green/20 rounded-full flex items-center justify-center mr-3 mt-1">
                    <Check size={16} className="text-primary-green" />
                  </div>
                  <div>
                    <h4 className="font-medium text-text-navy">Priority Support</h4>
                    <p className="text-sm text-text-gray">Get help faster with dedicated support</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-green/20 rounded-full flex items-center justify-center mr-3 mt-1">
                    <Check size={16} className="text-primary-green" />
                  </div>
                  <div>
                    <h4 className="font-medium text-text-navy">Early Access</h4>
                    <p className="text-sm text-text-gray">Be first to try new features and content</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'billing' && (
          <div className="space-y-6">
            {/* Payment Method */}
            <div className="bg-white rounded-card p-6 shadow-card">
              <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4">
                Payment Method
              </h3>
              
              <div className="flex items-center justify-between p-4 border border-border-gray rounded-tile">
                <div className="flex items-center">
                  <div className="w-12 h-8 bg-gradient-to-r from-blue-600 to-blue-800 rounded text-white text-xs font-bold flex items-center justify-center mr-3">
                    VISA
                  </div>
                  <div>
                    <p className="font-medium text-text-navy">•••• •••• •••• 4242</p>
                    <p className="text-sm text-text-gray">Expires 12/25</p>
                  </div>
                </div>
                
                <button className="text-primary-blue font-medium text-sm hover:underline">
                  Update
                </button>
              </div>
            </div>

            {/* Billing History */}
            <ProFeatureGate 
              feature="billing history"
              title="Billing History"
              description="View your complete payment history and manage billing details."
            >
              <div className="bg-white rounded-card p-6 shadow-card">
                <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4">
                  Billing History
                </h3>
                
                <div className="space-y-3">
                  {[
                    { date: 'Feb 15, 2024', amount: '$9.99', status: 'Paid', description: 'Pro Subscription' },
                    { date: 'Jan 15, 2024', amount: '$9.99', status: 'Paid', description: 'Pro Subscription' },
                    { date: 'Dec 15, 2023', amount: '$4.99', status: 'Paid', description: 'Space Adventures Pack' }
                  ].map((transaction, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-border-gray rounded-tile">
                      <div>
                        <p className="font-medium text-text-navy">{transaction.description}</p>
                        <p className="text-sm text-text-gray">{transaction.date}</p>
                      </div>
                      
                      <div className="text-right">
                        <p className="font-medium text-text-navy">{transaction.amount}</p>
                        <span className="text-xs px-2 py-1 bg-success-green/20 text-success-green rounded-full">
                          {transaction.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ProFeatureGate>
          </div>
        )}

        {activeTab === 'packs' && (
          <div className="space-y-6">
            {/* Pro Status Banner */}
            <SubscriptionStatus 
              onUpgrade={() => setShowUpgradeModal(true)}
              onManageBilling={() => setActiveTab('billing')}
              compact={true}
            />

            {/* Quest Packs */}
            <div>
              <h2 className="font-quicksand font-semibold text-xl text-text-navy mb-4">
                Quest Packs
              </h2>
              
              <div className="space-y-6">
                {mockQuestPacks.map((pack) => {
                  const isPurchased = purchasedPacks.includes(pack.id) || isProUser;
                  
                  return (
                    <div key={pack.id} className="bg-white rounded-card overflow-hidden shadow-card">
                      <div className="relative">
                        <img
                          src={pack.thumbnail}
                          alt={pack.title}
                          className="w-full h-40 object-cover"
                        />
                        
                        <div className="absolute top-4 left-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getDifficultyColor(pack.difficulty)}`}>
                            {pack.difficulty.toUpperCase()}
                          </span>
                        </div>
                        
                        {isPurchased && (
                          <div className="absolute top-4 right-4 w-8 h-8 bg-success-green rounded-full flex items-center justify-center">
                            <Check size={16} className="text-white" />
                          </div>
                        )}
                        
                        {isProUser && (
                          <div className="absolute bottom-4 right-4 px-2 py-1 bg-accent-yellow rounded-full">
                            <span className="text-xs font-bold text-text-navy">PRO</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <h3 className="font-quicksand font-semibold text-lg text-text-navy">
                            {pack.title}
                          </h3>
                          <div className="text-right">
                            <div className="text-xl font-bold text-primary-green">
                              {isProUser ? 'Included' : `$${pack.price}`}
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-text-gray mb-4">
                          {pack.description}
                        </p>
                        
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center text-sm text-text-gray">
                            <Star size={16} className="mr-1" />
                            <span>{pack.questCount} quests</span>
                          </div>
                          <div className="flex items-center text-sm text-text-gray">
                            <Users size={16} className="mr-1" />
                            <span>Ages 6-9</span>
                          </div>
                          <div className="flex items-center text-sm text-text-gray">
                            <Clock size={16} className="mr-1" />
                            <span>5 min each</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-4">
                          {pack.tags.map((tag, index) => (
                            <span key={index} className="px-2 py-1 bg-surface-gray rounded-full text-xs text-text-gray">
                              #{tag}
                            </span>
                          ))}
                        </div>
                        
                        <button
                          onClick={() => handlePurchase(pack.id)}
                          disabled={isPurchased}
                          className={`w-full py-3 px-6 rounded-full font-semibold transition-all duration-200 transform active:scale-95 ${
                            isPurchased
                              ? 'bg-success-green/20 text-success-green cursor-not-allowed'
                              : 'btn-primary'
                          }`}
                        >
                          {isPurchased ? (isProUser ? 'Available' : 'Purchased') : 'Purchase'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Coming Soon */}
            <div className="bg-white rounded-card p-6 shadow-card text-center">
              <div className="text-4xl mb-4">🔮</div>
              <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-2">
                More Packs Coming Soon!
              </h3>
              <p className="text-text-gray mb-4">
                We're working on exciting new quest packs. Check back soon for updates!
              </p>
              
              <div className="flex justify-center space-x-4 text-sm text-text-gray">
                <span>🌊 Ocean Adventures</span>
                <span>🦕 Dinosaur World</span>
                <span>🎭 Theater Arts</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <ProUpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onUpgrade={handleUpgradeComplete}
      />
    </div>
  );
};

export default Shop;