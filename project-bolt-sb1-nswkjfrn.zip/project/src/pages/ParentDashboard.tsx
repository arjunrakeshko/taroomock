import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Bell, 
  Settings, 
  BarChart3, 
  MessageSquare, 
  AlertTriangle, 
  CheckCircle, 
  Heart, 
  BookOpen,
  Clock,
  Zap,
  Shield,
  TrendingUp,
  Eye,
  Flag,
  ThumbsUp,
  Brain,
  Users,
  Star,
  Crown,
  Play,
  Calendar,
  Target,
  Award,
  Activity,
  Smile,
  Monitor,
  ArrowUp,
  ArrowDown,
  Minus,
  ChevronRight,
  Filter,
  Search,
  Lock
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { mockProfiles } from '../data/mockProfiles';
import ProUpgradeModal from '../components/ProUpgradeModal';
import { Quest } from '../types';

const ParentDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { 
    activeProfile, 
    parentAlerts, 
    markAlertAsRead, 
    getUnreadAlertsCount,
    quests,
    getLockedQuests,
    toggleQuestLock,
    lockAllQuests,
    unlockAllQuests
  } = useApp();
  
  const [activeTab, setActiveTab] = useState<'analytics' | 'reviews' | 'alerts' | 'management' | 'settings'>('analytics');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState<string>('all');
  const [questFilter, setQuestFilter] = useState<'all' | 'recent' | 'flagged'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Sample quest completion data for demo
  const sampleQuestCompletions = [
    {
      id: 'completion-1',
      questId: '1',
      childId: 'kid1',
      childName: 'Alex',
      questTitle: 'Creative Story Builder',
      completedAt: '2024-01-20T14:30:00Z',
      duration: 8,
      xpEarned: 150,
      safetyScore: 98,
      messageCount: 6,
      sentiment: 'positive' as const
    },
    {
      id: 'completion-2',
      questId: '4',
      childId: 'kid1',
      childName: 'Alex',
      questTitle: 'Robot Friend Designer',
      completedAt: '2024-01-19T16:45:00Z',
      duration: 12,
      xpEarned: 180,
      safetyScore: 95,
      messageCount: 8,
      sentiment: 'positive' as const
    },
    {
      id: 'completion-3',
      questId: '2',
      childId: 'kid2',
      childName: 'Emma',
      questTitle: 'Space Explorer Art',
      completedAt: '2024-01-18T10:15:00Z',
      duration: 6,
      xpEarned: 200,
      safetyScore: 100,
      messageCount: 4,
      sentiment: 'positive' as const
    }
  ];

  const isProUser = activeProfile?.parentData?.hasProSubscription || false;
  const childProfiles = mockProfiles.filter(p => p.type === 'kid');
  const unreadAlerts = getUnreadAlertsCount();
  const lockedQuests = getLockedQuests();

  const handleUpgradeComplete = (plan: 'monthly' | 'yearly', childCount: number) => {
    if (activeProfile?.parentData) {
      activeProfile.parentData.hasProSubscription = true;
      activeProfile.parentData.subscribedChildCount = childCount;
    }
    setShowUpgradeModal(false);
    setActiveTab('analytics');
  };

  const handleQuestReview = (questId: string, childId: string) => {
    console.log('Navigating to quest review:', questId, childId);
    navigate(`/parent/quest-review/${questId}/${childId}`);
  };

  const handleAlertClick = (alert: any) => {
    markAlertAsRead(alert.id);
    if (alert.questId) {
      navigate(`/parent/quest-review/${alert.questId}/${alert.childId}`);
    }
  };

  const handleToggleQuestLock = (questId: string) => {
    toggleQuestLock(questId);
  };

  const handleLockHardQuests = () => {
    const hardQuests = quests.filter(q => q.difficulty === 'hard');
    hardQuests.forEach(quest => toggleQuestLock(quest.id));
  };

  const handleLockPremiumQuests = () => {
    const premiumQuests = quests.filter(q => q.isPremium);
    premiumQuests.forEach(quest => toggleQuestLock(quest.id));
  };

  const getFilteredQuestCompletions = () => {
    let filtered = sampleQuestCompletions;

    // Filter by child
    if (selectedChild !== 'all') {
      filtered = filtered.filter(completion => completion.childId === selectedChild);
    }

    // Filter by type
    if (questFilter === 'recent') {
      const threeDaysAgo = new Date();
      threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
      filtered = filtered.filter(completion => new Date(completion.completedAt) > threeDaysAgo);
    } else if (questFilter === 'flagged') {
      filtered = filtered.filter(completion => completion.safetyScore < 98);
    }

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(completion => 
        completion.questTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        completion.childName.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filtered.sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-50 border-green-200';
      case 'neutral': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'concerning': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSafetyScoreColor = (score: number) => {
    if (score >= 98) return 'text-green-600';
    if (score >= 95) return 'text-yellow-600';
    return 'text-red-600';
  };

  const tabs = [
    { 
      key: 'analytics', 
      label: 'Analytics', 
      icon: BarChart3,
      description: isProUser ? 'Advanced insights' : 'Basic overview'
    },
    { 
      key: 'reviews', 
      label: 'Quest Reviews', 
      icon: MessageSquare,
      description: 'Conversation history'
    },
    { 
      key: 'alerts', 
      label: 'Alerts', 
      icon: Bell,
      description: 'Safety & learning alerts',
      badge: unreadAlerts > 0 ? unreadAlerts : undefined
    },
    { 
      key: 'management', 
      label: 'Quest Management', 
      icon: Lock,
      description: 'Control quest access'
    },
    { 
      key: 'settings', 
      label: 'Settings', 
      icon: Settings,
      description: 'Account & preferences'
    }
  ];

  if (!activeProfile || activeProfile.type !== 'parent') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">This area is for parents only.</p>
          <button 
            onClick={() => navigate('/profiles')}
            className="text-blue-600 hover:underline"
          >
            Return to Profile Selection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex-1 text-center">
              <h1 className="text-3xl font-bold text-gray-900">Taroo Parents</h1>
              <p className="text-gray-600">Monitor and support your children's learning journey</p>
            </div>
            
            {/* Child Switcher */}
            <div className="flex items-center">
              <select
                value={selectedChild}
                onChange={(e) => setSelectedChild(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
              >
                <option value="all">All Children</option>
                {childProfiles.map((child) => (
                  <option key={child.id} value={child.id}>{child.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Tab Navigation */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-2 mb-8">
          <div className="grid grid-cols-5 gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`relative p-4 rounded-lg font-semibold text-base transition-all duration-200 flex flex-col items-center justify-center ${
                  activeTab === tab.key
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <div className="relative">
                  <tab.icon size={24} className="mb-2" />
                  {tab.badge && (
                    <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-sm font-medium">{tab.label}</span>
                <span className={`text-xs mt-1 ${activeTab === tab.key ? 'text-white/80' : 'text-gray-500'}`}>
                  {tab.description}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {!isProUser && (
              <div className="bg-gradient-to-r from-yellow-50 to-green-50 rounded-xl p-4 border border-yellow-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Crown size={20} className="text-yellow-600 mr-3" />
                    <div>
                      <h3 className="font-semibold text-gray-900">Unlock Pro Analytics</h3>
                      <p className="text-sm text-gray-600">Get detailed insights into your children's learning patterns</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowUpgradeModal(true)}
                    className="px-4 py-2 bg-yellow-500 text-white rounded-lg font-medium hover:bg-yellow-600 transition-colors"
                  >
                    Upgrade - $20/mo
                  </button>
                </div>
              </div>
            )}

            {isProUser ? (
              <div className="space-y-8">
                {/* Skill-Mastery Wheel */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-semibold text-xl text-gray-900">Skill-Mastery Wheel</h3>
                    <div className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                      Pro Analytics
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="relative">
                      <div className="w-64 h-64 mx-auto relative">
                        {/* Skill rings */}
                        <div className="absolute inset-0 rounded-full border-8 border-green-200">
                          <div className="absolute inset-2 rounded-full border-8 border-blue-200">
                            <div className="absolute inset-2 rounded-full border-8 border-purple-200">
                              <div className="absolute inset-2 rounded-full border-8 border-orange-200">
                                <div className="absolute inset-8 rounded-full bg-gray-100 flex items-center justify-center">
                                  <div className="text-center">
                                    <div className="text-3xl font-bold text-gray-900">87%</div>
                                    <div className="text-sm text-gray-600">Overall</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6 space-y-3">
                        <div className="flex items-center">
                          <div className="w-4 h-4 bg-green-500 rounded-full mr-3"></div>
                          <span className="text-gray-700">Creativity: 92%</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-4 h-4 bg-blue-500 rounded-full mr-3"></div>
                          <span className="text-gray-700">Logic & Reasoning: 85%</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-4 h-4 bg-purple-500 rounded-full mr-3"></div>
                          <span className="text-gray-700">Communication: 89%</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-4 h-4 bg-orange-500 rounded-full mr-3"></div>
                          <span className="text-gray-700">Research Skills: 82%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="font-semibold text-gray-900">Skill Breakdown</h4>
                      {[
                        { skill: 'Creative Writing', level: 94, trend: 'up' },
                        { skill: 'Problem Solving', level: 87, trend: 'up' },
                        { skill: 'Verbal Expression', level: 91, trend: 'stable' },
                        { skill: 'Information Gathering', level: 84, trend: 'up' }
                      ].map((item, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-700">{item.skill}</span>
                            <div className="flex items-center">
                              <span className="text-sm font-bold text-gray-900 mr-2">{item.level}%</span>
                              {item.trend === 'up' && <ArrowUp size={14} className="text-green-600" />}
                              {item.trend === 'down' && <ArrowDown size={14} className="text-red-600" />}
                              {item.trend === 'stable' && <Minus size={14} className="text-gray-600" />}
                            </div>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full">
                            <div 
                              className="h-full bg-gradient-to-r from-blue-500 to-green-500 rounded-full transition-all duration-1000"
                              style={{ width: `${item.level}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Growth Trajectory */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="font-semibold text-xl text-gray-900 mb-6">Growth Trajectory</h3>
                  
                  <div className="grid grid-cols-3 gap-6 mb-6">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">+15%</div>
                      <div className="text-sm text-gray-600">Monthly Growth</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">245</div>
                      <div className="text-sm text-gray-600">Daily XP Average</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">12</div>
                      <div className="text-sm text-gray-600">Day Streak</div>
                    </div>
                  </div>
                  
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <TrendingUp size={48} className="mx-auto mb-2" />
                      <p>Interactive growth chart would appear here</p>
                    </div>
                  </div>
                </div>

                {/* Strengths & Stretches */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h3 className="font-semibold text-xl text-gray-900 mb-6 text-green-700">Strengths</h3>
                    <div className="space-y-4">
                      {[
                        'Exceptional creative storytelling abilities',
                        'Strong emotional intelligence in character development',
                        'Advanced vocabulary usage for age group',
                        'Excellent problem-solving approach'
                      ].map((strength, index) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle size={20} className="text-green-600 mr-3 mt-1 flex-shrink-0" />
                          <p className="text-gray-700">{strength}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h3 className="font-semibold text-xl text-gray-900 mb-6 text-orange-700">Growth Opportunities</h3>
                    <div className="space-y-4">
                      {[
                        'Could benefit from more structured research quests',
                        'Encourage deeper exploration of scientific topics',
                        'Practice with logical reasoning challenges',
                        'Develop presentation and sharing skills'
                      ].map((stretch, index) => (
                        <div key={index} className="flex items-start">
                          <Target size={20} className="text-orange-600 mr-3 mt-1 flex-shrink-0" />
                          <p className="text-gray-700">{stretch}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Peer Progress Band */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-semibold text-xl text-gray-900">Peer Progress Band</h3>
                    <div className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
                      Parent-Only
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                    {[
                      { skill: 'Creativity', percentile: 85, peers: '8-9 year olds' },
                      { skill: 'Logic', percentile: 72, peers: '8-9 year olds' },
                      { skill: 'Communication', percentile: 91, peers: '8-9 year olds' },
                      { skill: 'Research', percentile: 68, peers: '8-9 year olds' }
                    ].map((item, index) => (
                      <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-900 mb-1">{item.percentile}th</div>
                        <div className="text-sm font-medium text-gray-700 mb-1">{item.skill}</div>
                        <div className="text-xs text-gray-500">{item.peers}</div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-700">
                      <strong>Peer Insights:</strong> Your child is performing above average in most areas, 
                      with exceptional creativity and communication skills compared to peers.
                    </p>
                  </div>
                </div>

                {/* Screen-Time Balance */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="font-semibold text-xl text-gray-900 mb-6">Screen-Time Balance</h3>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Monitor size={32} className="text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">25 min</div>
                      <div className="text-sm text-gray-600">Daily Average</div>
                      <div className="text-xs text-green-600 mt-1">Within recommended limits</div>
                    </div>
                    
                    <div className="space-y-3">
                      <h4 className="font-medium text-gray-900">Weekly Breakdown</h4>
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                        const minutes = [20, 30, 25, 15, 35, 40, 28][index];
                        return (
                          <div key={day} className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">{day}</span>
                            <div className="flex items-center">
                              <div className="w-20 h-2 bg-gray-200 rounded-full mr-2">
                                <div 
                                  className="h-full bg-green-500 rounded-full"
                                  style={{ width: `${(minutes / 60) * 100}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium text-gray-900">{minutes}m</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    
                    <div className="space-y-3">
                      <h4 className="font-medium text-gray-900">Recommendations</h4>
                      <div className="space-y-2">
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle size={16} className="mr-2" />
                          <span>Healthy balance maintained</span>
                        </div>
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle size={16} className="mr-2" />
                          <span>Good variety in quest types</span>
                        </div>
                        <div className="flex items-center text-sm text-blue-600">
                          <Star size={16} className="mr-2" />
                          <span>Consider outdoor activities</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Safety & Well-Being Flags */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="font-semibold text-xl text-gray-900 mb-6">Safety & Well-Being Flags</h3>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Shield size={32} className="text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">98%</div>
                      <div className="text-sm text-gray-600">Overall Safety Score</div>
                    </div>
                    
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Heart size={32} className="text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">Excellent</div>
                      <div className="text-sm text-gray-600">Emotional Well-being</div>
                    </div>
                    
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Activity size={32} className="text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">High</div>
                      <div className="text-sm text-gray-600">Engagement Level</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Safety Metrics</h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Content Safety</span>
                          <span className="text-sm font-medium text-green-600">100%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Emotional Well-being</span>
                          <span className="text-sm font-medium text-green-600">97%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Engagement Quality</span>
                          <span className="text-sm font-medium text-green-600">95%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Recent Activity</h4>
                      <div className="space-y-2">
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle size={16} className="mr-2" />
                          <span>No safety concerns in last 30 days</span>
                        </div>
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle size={16} className="mr-2" />
                          <span>Positive interaction patterns</span>
                        </div>
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle size={16} className="mr-2" />
                          <span>Age-appropriate content engagement</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                <div className="text-center">
                  <BarChart3 size={64} className="text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Basic Analytics</h3>
                  <p className="text-gray-600 mb-6">
                    View basic learning statistics and progress for your children.
                  </p>
                  
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-900">12</div>
                      <div className="text-sm text-gray-600">Quests Completed</div>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-900">1,250</div>
                      <div className="text-sm text-gray-600">Total XP Earned</div>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-900">7</div>
                      <div className="text-sm text-gray-600">Day Streak</div>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-900">98%</div>
                      <div className="text-sm text-gray-600">Safety Score</div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setShowUpgradeModal(true)}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    Unlock Advanced Analytics - $20/month
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div className="flex items-center space-x-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Child</label>
                    <select
                      value={selectedChild}
                      onChange={(e) => setSelectedChild(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="all">All Children</option>
                      {childProfiles.map((child) => (
                        <option key={child.id} value={child.id}>{child.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Filter</label>
                    <select
                      value={questFilter}
                      onChange={(e) => setQuestFilter(e.target.value as any)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="all">All Quests</option>
                      <option value="recent">Recent (3 days)</option>
                      <option value="flagged">Flagged Content</option>
                    </select>
                  </div>
                </div>
                
                <div className="relative">
                  <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search quests..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Quest Completions List */}
            <div className="space-y-4">
              {getFilteredQuestCompletions().map((completion) => (
                <div key={completion.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                        <MessageSquare size={24} className="text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-gray-900">{completion.questTitle}</h3>
                        <p className="text-gray-600">
                          {completion.childName} • {new Date(completion.completedAt).toLocaleDateString()} at {new Date(completion.completedAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className={`px-3 py-1 rounded-full border text-sm font-medium ${getSentimentColor(completion.sentiment)}`}>
                        {completion.sentiment.toUpperCase()}
                      </div>
                      
                      <button
                        onClick={() => handleQuestReview(completion.questId, completion.childId)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center"
                      >
                        View Review
                        <ChevronRight size={16} className="ml-1" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-6">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Clock size={20} className="text-gray-600 mx-auto mb-1" />
                      <div className="text-lg font-bold text-gray-900">{completion.duration}m</div>
                      <div className="text-xs text-gray-600">Duration</div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Zap size={20} className="text-yellow-600 mx-auto mb-1" />
                      <div className="text-lg font-bold text-gray-900">+{completion.xpEarned}</div>
                      <div className="text-xs text-gray-600">XP Earned</div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Shield size={20} className={`mx-auto mb-1 ${getSafetyScoreColor(completion.safetyScore)}`} />
                      <div className={`text-lg font-bold ${getSafetyScoreColor(completion.safetyScore)}`}>
                        {completion.safetyScore}%
                      </div>
                      <div className="text-xs text-gray-600">Safety Score</div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <MessageSquare size={20} className="text-purple-600 mx-auto mb-1" />
                      <div className="text-lg font-bold text-gray-900">{completion.messageCount}</div>
                      <div className="text-xs text-gray-600">Messages</div>
                    </div>
                  </div>
                </div>
              ))}
              
              {getFilteredQuestCompletions().length === 0 && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                  <MessageSquare size={64} className="text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No Quest Reviews Found</h3>
                  <p className="text-gray-600">
                    {searchQuery || questFilter !== 'all' || selectedChild !== 'all'
                      ? 'Try adjusting your search or filters'
                      : 'Quest reviews will appear here as your children complete quests'
                    }
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="space-y-6">
            {parentAlerts.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                <CheckCircle size={64} className="text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">All Clear!</h3>
                <p className="text-gray-600">No alerts at this time. We'll notify you of any important updates.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {parentAlerts.map((alert) => {
                  const AlertIcon = alert.type === 'safety' ? AlertTriangle :
                                   alert.type === 'emotional' ? Heart :
                                   alert.type === 'educational' ? BookOpen : CheckCircle;
                  
                  const alertColor = alert.severity === 'high' ? 'border-red-200 bg-red-50' :
                                    alert.severity === 'medium' ? 'border-yellow-200 bg-yellow-50' :
                                    'border-blue-200 bg-blue-50';
                  
                  const iconColor = alert.severity === 'high' ? 'text-red-600' :
                                   alert.severity === 'medium' ? 'text-yellow-600' :
                                   'text-blue-600';

                  return (
                    <div
                      key={alert.id}
                      className={`bg-white rounded-xl shadow-sm border p-6 cursor-pointer hover:shadow-md transition-all ${
                        alert.isRead ? 'opacity-75' : ''
                      } ${alertColor}`}
                      onClick={() => handleAlertClick(alert)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start">
                          <AlertIcon size={24} className={`mr-4 mt-1 ${iconColor}`} />
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <h3 className="font-semibold text-gray-900 mr-3">{alert.title}</h3>
                              {!alert.isRead && (
                                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                              )}
                            </div>
                            <p className="text-gray-700 mb-2">{alert.description}</p>
                            <div className="flex items-center text-sm text-gray-500">
                              <span>{new Date(alert.timestamp).toLocaleDateString()}</span>
                              <span className="mx-2">•</span>
                              <span className="capitalize">{alert.severity} priority</span>
                              {alert.actionRequired && (
                                <>
                                  <span className="mx-2">•</span>
                                  <span className="text-red-600 font-medium">Action Required</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <ChevronRight size={20} className="text-gray-400" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'management' && (
          <div className="space-y-6">
            {/* Quest Management Header */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Quest Access Control</h3>
                  <p className="text-gray-600">Manage which quests your children can access</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">{lockedQuests.length}</div>
                  <div className="text-sm text-gray-600">Locked Quests</div>
                </div>
              </div>
              
              {/* Bulk Actions */}
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={unlockAllQuests}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center"
                >
                  <CheckCircle size={16} className="mr-2" />
                  Unlock All Quests
                </button>
                
                <button
                  onClick={handleLockHardQuests}
                  className="px-4 py-2 bg-yellow-600 text-white rounded-lg font-medium hover:bg-yellow-700 transition-colors flex items-center"
                >
                  <AlertTriangle size={16} className="mr-2" />
                  Lock Hard Quests
                </button>
                
                <button
                  onClick={handleLockPremiumQuests}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center"
                >
                  <Crown size={16} className="mr-2" />
                  Lock Premium Quests
                </button>
                
                <button
                  onClick={lockAllQuests}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors flex items-center"
                >
                  <Lock size={16} className="mr-2" />
                  Lock All Quests
                </button>
              </div>
            </div>

            {/* Information Box */}
            <div className="bg-blue-50 rounded-xl p-6 border border-blue-200">
              <div className="flex items-start">
                <Shield size={24} className="text-blue-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">How Quest Locking Works</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Locked quests are hidden from your children's quest selection</li>
                    <li>• Changes take effect immediately across all devices</li>
                    <li>• Previously completed quests remain in their history</li>
                    <li>• You can unlock quests at any time</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Quest Grid */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">All Quests</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quests.map((quest) => {
                  const isLocked = lockedQuests.includes(quest.id);
                  const completionCount = sampleQuestCompletions.filter(c => c.questId === quest.id).length;
                  
                  return (
                    <div key={quest.id} className={`relative rounded-xl border-2 transition-all duration-200 ${
                      isLocked 
                        ? 'border-red-200 bg-red-50' 
                        : 'border-gray-200 bg-white hover:border-blue-300'
                    }`}>
                      {/* Quest Image */}
                      <div className="relative">
                        <img
                          src={quest.thumbnail}
                          alt={quest.title}
                          className={`w-full h-32 object-cover rounded-t-xl ${
                            isLocked ? 'grayscale opacity-60' : ''
                          }`}
                        />
                        
                        {/* Lock Overlay */}
                        {isLocked && (
                          <div className="absolute inset-0 bg-red-500/20 rounded-t-xl flex items-center justify-center">
                            <div className="bg-red-500 text-white p-2 rounded-full">
                              <Lock size={20} />
                            </div>
                          </div>
                        )}
                        
                        {/* Premium Badge */}
                        {quest.isPremium && (
                          <div className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                            PREMIUM
                          </div>
                        )}
                        
                        {/* Difficulty Badge */}
                        <div className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-bold ${
                          quest.difficulty === 'easy' ? 'bg-green-500 text-white' :
                          quest.difficulty === 'medium' ? 'bg-yellow-500 text-white' :
                          'bg-red-500 text-white'
                        }`}>
                          {quest.difficulty.toUpperCase()}
                        </div>
                      </div>
                      
                      {/* Quest Content */}
                      <div className="p-4">
                        <h4 className={`font-semibold text-lg mb-2 ${
                          isLocked ? 'text-gray-500' : 'text-gray-900'
                        }`}>
                          {quest.title}
                        </h4>
                        
                        <p className={`text-sm mb-4 line-clamp-2 ${
                          isLocked ? 'text-gray-400' : 'text-gray-600'
                        }`}>
                          {quest.description}
                        </p>
                        
                        {/* Quest Stats */}
                        <div className="grid grid-cols-3 gap-3 mb-4 text-xs">
                          <div className="text-center">
                            <Clock size={14} className={`mx-auto mb-1 ${isLocked ? 'text-gray-400' : 'text-blue-600'}`} />
                            <div className={`font-medium ${isLocked ? 'text-gray-400' : 'text-gray-900'}`}>
                              {quest.duration}m
                            </div>
                          </div>
                          <div className="text-center">
                            <Zap size={14} className={`mx-auto mb-1 ${isLocked ? 'text-gray-400' : 'text-yellow-600'}`} />
                            <div className={`font-medium ${isLocked ? 'text-gray-400' : 'text-gray-900'}`}>
                              {quest.xpValue} XP
                            </div>
                          </div>
                          <div className="text-center">
                            <Users size={14} className={`mx-auto mb-1 ${isLocked ? 'text-gray-400' : 'text-green-600'}`} />
                            <div className={`font-medium ${isLocked ? 'text-gray-400' : 'text-gray-900'}`}>
                              {completionCount}
                            </div>
                          </div>
                        </div>
                        
                        {/* Quest Type */}
                        <div className="flex items-center justify-between mb-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            quest.type === 'chat' ? 'bg-blue-100 text-blue-700' :
                            quest.type === 'image' ? 'bg-purple-100 text-purple-700' :
                            'bg-green-100 text-green-700'
                          } ${isLocked ? 'opacity-50' : ''}`}>
                            {quest.type === 'chat' ? '💬' : quest.type === 'image' ? '🎨' : '🔍'}
                            <span className="ml-1">
                              {quest.type === 'chat' ? 'Chat' : quest.type === 'image' ? 'Create' : 'Explore'}
                            </span>
                          </span>
                          
                          <div className="flex flex-wrap gap-1">
                            {quest.tags.slice(0, 2).map((tag, index) => (
                              <span key={index} className={`px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs ${
                                isLocked ? 'opacity-50' : ''
                              }`}>
                                #{tag}
                              </span>
                            ))}
                          </div>
                        </div>
                        
                        {/* Lock/Unlock Button */}
                        <button
                          onClick={() => handleToggleQuestLock(quest.id)}
                          className={`w-full py-2 px-4 rounded-lg font-medium transition-all duration-200 transform active:scale-95 ${
                            isLocked
                              ? 'bg-red-600 text-white hover:bg-red-700'
                              : 'bg-green-600 text-white hover:bg-green-700'
                          }`}
                        >
                          {isLocked ? (
                            <div className="flex items-center justify-center">
                              <Lock size={16} className="mr-2" />
                              Unlock Quest
                            </div>
                          ) : (
                            <div className="flex items-center justify-center">
                              <Shield size={16} className="mr-2" />
                              Lock Quest
                            </div>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
              <Settings size={64} className="text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Settings</h3>
              <p className="text-gray-600">Account settings and preferences will be available here.</p>
            </div>
          </div>
        )}
      </div>

      <ProUpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onUpgrade={handleUpgradeComplete}
      />
    </div>
  );
};

export default ParentDashboard;