import React, { useState, useEffect } from 'react';

interface MascotAvatarProps {
  size?: 'sm' | 'md' | 'lg';
  mood?: 'happy' | 'excited' | 'thinking' | 'encouraging';
  showBlink?: boolean;
  className?: string;
}

const MascotAvatar: React.FC<MascotAvatarProps> = ({ 
  size = 'md', 
  mood = 'happy', 
  showBlink = true,
  className = '' 
}) => {
  const [isBlinking, setIsBlinking] = useState(false);

  useEffect(() => {
    if (!showBlink) return;

    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 8000); // Blink every 8 seconds as per guidelines

    return () => clearInterval(blinkInterval);
  }, [showBlink]);

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const getMascotEmoji = () => {
    switch (mood) {
      case 'excited': return '🤩';
      case 'thinking': return '🤔';
      case 'encouraging': return '😊';
      default: return '😄';
    }
  };

  return (
    <div className={`
      ${sizeClasses[size]} 
      rounded-full 
      bg-gradient-to-br from-primary-green to-primary-blue 
      flex items-center justify-center 
      shadow-soft
      ${className}
    `}>
      <span 
        className={`text-white transition-transform duration-150 ${
          isBlinking ? 'scale-y-10' : 'scale-y-100'
        }`}
        style={{ 
          fontSize: size === 'sm' ? '16px' : size === 'md' ? '20px' : '28px',
          transformOrigin: 'center'
        }}
      >
        {getMascotEmoji()}
      </span>
    </div>
  );
};

export default MascotAvatar;