import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative overflow-hidden flex items-center justify-center">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600 animate-pulse">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700 animate-bounce">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500 animate-pulse">🌿</div>
        <div className="absolute top-96 right-4 text-7xl opacity-10 text-green-800 animate-bounce">🌲</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600 animate-pulse">🌳</div>
        <div className="absolute bottom-64 right-12 text-6xl opacity-15 text-green-700 animate-bounce">🌲</div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute top-80 left-1/4 text-2xl opacity-35 text-yellow-500 animate-bounce">🌸</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🦋</div>
      </div>

      <div className="text-center relative z-10">
        {/* Animated Growing Tree */}
        <div className="relative mb-8">
          <div className="w-32 h-40 mx-auto relative">
            {/* Tree Base/Trunk */}
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4 h-6 bg-amber-700 rounded-t-sm animate-pulse"></div>
            
            {/* Tree Canopy - animated growth */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 transition-all duration-2000 ease-out animate-pulse"
                 style={{ width: '80px', height: '70px' }}>
              <div className="w-full h-full bg-gradient-to-t from-green-600 to-green-400 rounded-full relative overflow-hidden">
                {/* Tree texture/details */}
                <div className="absolute inset-0 opacity-30">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} 
                         className="absolute w-2 h-2 bg-green-300 rounded-full animate-pulse"
                         style={{
                           left: `${20 + (i * 15) % 60}%`,
                           top: `${30 + (i * 20) % 40}%`,
                           animationDelay: `${i * 0.3}s`
                         }}>
                    </div>
                  ))}
                </div>
                
                {/* Leaves floating around tree */}
                <div className="absolute -inset-4 pointer-events-none">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} 
                         className="absolute text-lg animate-bounce opacity-60"
                         style={{
                           left: `${10 + (i * 25) % 80}%`,
                           top: `${10 + (i * 30) % 70}%`,
                           animationDelay: `${i * 0.5}s`,
                           animationDuration: '2s'
                         }}>
                      {i % 3 === 0 ? '🍃' : i % 3 === 1 ? '🌿' : '🍂'}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Growth sparkles */}
            <div className="absolute -inset-2 pointer-events-none">
              {[...Array(6)].map((_, i) => (
                <div key={i} 
                     className="absolute text-yellow-400 animate-pulse"
                     style={{
                       left: `${20 + (i * 30) % 60}%`,
                       top: `${20 + (i * 25) % 60}%`,
                       animationDelay: `${i * 0.4}s`
                     }}>
                  ✨
                </div>
              ))}
            </div>
          </div>
          
          {/* Spinning forest ring around tree */}
          <div className="absolute inset-0 w-32 h-32 mx-auto mt-4 border-4 border-green-200 rounded-full animate-spin border-t-green-600"></div>
        </div>
        
        {/* Forest-themed loading text */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200 max-w-sm mx-auto">
          <h2 className="text-2xl font-quicksand font-bold text-green-800 mb-2">
            🌲 Growing Your Forest...
          </h2>
          <p className="text-green-600 mb-4">
            Preparing your magical forest adventure
          </p>
          
          {/* Animated loading dots */}
          <div className="flex justify-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-bounce"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-3 h-3 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
        
        {/* Forest creatures loading animation */}
        <div className="mt-6 flex justify-center space-x-4">
          {['🦊', '🐰', '🐺', '🦌'].map((creature, i) => (
            <div key={i} 
                 className="text-2xl animate-bounce opacity-70"
                 style={{ animationDelay: `${i * 0.2}s` }}>
              {creature}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;