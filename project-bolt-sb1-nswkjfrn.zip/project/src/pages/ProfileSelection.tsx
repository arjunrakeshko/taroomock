import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Settings, Lock } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { mockProfiles } from '../data/mockProfiles';

const ProfileSelection: React.FC = () => {
  const navigate = useNavigate();
  const { setActiveProfile } = useApp();
  const [profiles] = useState(mockProfiles);

  const handleProfileSelect = (profile: any) => {
    setActiveProfile(profile);
    navigate('/pin-entry', { state: { profile } });
  };

  const handleManageProfiles = () => {
    navigate('/manage-profiles');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex flex-col items-center justify-center p-4">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-primary-green to-primary-blue rounded-card flex items-center justify-center shadow-2xl">
          <span className="text-3xl">🌳</span>
        </div>
        <h1 className="font-quicksand font-bold text-4xl mb-2 text-white">
          Taroo
        </h1>
        <p className="text-lg text-white/80">
          Who's exploring the forest today?
        </p>
      </div>

      {/* Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 max-w-4xl w-full">
        {profiles.map((profile) => (
          <button
            key={profile.id}
            onClick={() => handleProfileSelect(profile)}
            className="group relative backdrop-blur-sm rounded-card p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 active:scale-95 border bg-white/10 border-white/20"
          >
            {/* Profile Image */}
            <div className="relative mb-6">
              <div className="w-24 h-24 mx-auto rounded-full border-4 transition-all duration-300 border-white/30 group-hover:border-white/60 bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <span className="text-5xl">{profile.avatar}</span>
              </div>
              
              {/* PIN Lock Indicator */}
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center shadow-lg">
                <Lock size={14} className="text-gray-700" />
              </div>
              
              {/* Profile Type Badge */}
              {profile.type === 'parent' && (
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center shadow-lg">
                  <Settings size={14} className="text-white" />
                </div>
              )}
            </div>
            
            {/* Profile Name */}
            <h3 className="font-quicksand font-semibold text-xl mb-2 text-white">
              {profile.name}
            </h3>
            
            {/* Profile Stats for Kids */}
            {profile.type === 'kid' && profile.user && (
              <div className="text-sm text-white/70">
                <p>Level {profile.user.level}</p>
                <p>{profile.user.xp.toLocaleString()} XP</p>
              </div>
            )}
            
            {/* Parent Badge */}
            {profile.type === 'parent' && (
              <div className="text-sm text-white/70">
                <p>Parent Dashboard</p>
                <p>Insights & Controls</p>
              </div>
            )}
          </button>
        ))}
        
        {/* Add Profile Button */}
        <button
          onClick={handleManageProfiles}
          className="group backdrop-blur-sm rounded-card p-8 hover:bg-white/10 transition-all duration-300 transform hover:scale-105 active:scale-95 border-2 border-dashed bg-white/5 border-white/30 hover:border-white/50"
        >
          <div className="w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center transition-all duration-300 bg-white/10 group-hover:bg-white/20 border-4 border-white/20">
            <Plus size={32} className="text-white/70" />
          </div>
          
          <h3 className="font-quicksand font-semibold text-xl mb-2 text-white/70">
            Add Profile
          </h3>
          
          <p className="text-sm text-white/50">
            Create new account
          </p>
        </button>
      </div>

      {/* Footer */}
      <div className="text-center">
        <button
          onClick={handleManageProfiles}
          className="transition-colors text-sm flex items-center text-white/60 hover:text-white/80"
        >
          <Settings size={16} className="mr-2" />
          Manage Profiles
        </button>
      </div>
    </div>
  );
};

export default ProfileSelection;