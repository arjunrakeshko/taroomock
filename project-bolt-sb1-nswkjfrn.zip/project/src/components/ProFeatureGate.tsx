import React, { useState } from 'react';
import { Lock, Crown, Star } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import ProUpgradeModal from './ProUpgradeModal';

interface ProFeatureGateProps {
  children: React.ReactNode;
  feature: string;
  title?: string;
  description?: string;
  showUpgrade?: boolean;
  className?: string;
}

const ProFeatureGate: React.FC<ProFeatureGateProps> = ({ 
  children, 
  feature, 
  title,
  description,
  showUpgrade = true,
  className = '' 
}) => {
  const { activeProfile } = useApp();
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const isProUser = activeProfile?.parentData?.hasProSubscription || false;

  const handleUpgrade = (plan: 'monthly' | 'yearly') => {
    // In production, this would handle the actual upgrade process
    console.log(`Upgrading to ${plan} plan for feature: ${feature}`);
    
    // Update user's subscription status
    if (activeProfile?.parentData) {
      activeProfile.parentData.hasProSubscription = true;
    }
  };

  // If user has Pro access, render children normally
  if (isProUser) {
    return <>{children}</>;
  }

  // Render locked state
  return (
    <>
      <div className={`relative ${className}`}>
        <div className="relative">
          {/* Blurred/disabled content */}
          <div className="filter blur-sm opacity-60 pointer-events-none">
            {children}
          </div>
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/20 rounded-card flex items-center justify-center backdrop-blur-sm">
            <div className="text-center p-6 max-w-sm bg-white/95 backdrop-blur-sm rounded-card shadow-card">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-accent-yellow to-primary-green rounded-full flex items-center justify-center">
                <Crown size={32} className="text-white" />
              </div>
              
              <h3 className="font-quicksand font-bold text-lg text-text-navy mb-2">
                {title || 'Pro Feature'}
              </h3>
              
              <p className="text-text-gray text-sm mb-4">
                {description || `Upgrade to Pro to unlock ${feature} and get the full experience.`}
              </p>
              
              {showUpgrade && (
                <div className="space-y-3">
                  <button
                    onClick={() => setShowUpgradeModal(true)}
                    className="w-full py-3 px-6 rounded-card font-semibold transition-all duration-200 transform active:scale-95 bg-gradient-to-r from-accent-yellow to-primary-green text-white hover:shadow-duolingo shadow-duolingo active:shadow-duolingo-pressed active:translate-y-1"
                  >
                    <Crown size={16} className="inline mr-2" />
                    Upgrade to Pro
                  </button>
                  
                  <div className="flex items-center justify-center text-xs text-text-gray">
                    <Star size={12} className="mr-1" />
                    <span>30-day money-back guarantee</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <ProUpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onUpgrade={handleUpgrade}
      />
    </>
  );
};

export default ProFeatureGate;