import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  MessageSquare, 
  AlertTriangle, 
  CheckCircle, 
  Heart, 
  BookOpen,
  Clock,
  Zap,
  Shield,
  TrendingUp,
  Eye,
  Flag,
  ThumbsUp,
  Brain,
  Users,
  Star,
  Bell,
  Lock,
  Crown
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const QuestReview: React.FC = () => {
  const { questId, childId } = useParams();
  const navigate = useNavigate();
  const { 
    getQuestExchange, 
    quests, 
    markAlertAsRead,
    parentAlerts,
    activeProfile
  } = useApp();
  
  const [activeTab, setActiveTab] = useState<'conversation' | 'analysis'>('conversation');

  const exchange = getQuestExchange(questId!, childId!);
  const quest = quests.find(q => q.id === questId);
  const relatedAlerts = parentAlerts.filter(alert => 
    alert.questId === questId && alert.childId === childId
  );
  
  const isProUser = activeProfile?.parentData?.hasProSubscription || false;

  const handleBack = () => {
    navigate('/parent-dashboard');
  };

  if (!exchange || !quest) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Quest exchange not found</h2>
          <button 
            onClick={handleBack}
            className="text-blue-600 hover:underline p-2"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  };

  // Mark related alerts as read when viewing
  React.useEffect(() => {
    relatedAlerts.forEach(alert => {
      if (!alert.isRead) {
        markAlertAsRead(alert.id);
      }
    });
  }, [relatedAlerts, markAlertAsRead]);

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-50 border-green-200';
      case 'neutral': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'concerning': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'safety': return AlertTriangle;
      case 'emotional': return Heart;
      case 'educational': return BookOpen;
      case 'positive': return CheckCircle;
      default: return AlertTriangle;
    }
  };

  const tabs = [
    { key: 'conversation', label: 'Conversation', icon: MessageSquare },
    { key: 'analysis', label: 'AI Analysis', icon: Brain }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <button
                onClick={handleBack}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors mr-4"
              >
                <ArrowLeft size={20} className="text-gray-600" />
              </button>
              
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Quest Review</h1>
                <p className="text-gray-600">Detailed analysis of quest interaction</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6 border border-blue-200">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-1">
                  {quest.title}
                </h2>
                <p className="text-gray-600">
                  Completed {new Date(exchange.completedAt).toLocaleDateString()} at {new Date(exchange.completedAt).toLocaleTimeString()}
                </p>
              </div>
              
              <div className={`px-4 py-2 rounded-full border ${getSentimentColor(exchange.aiAnalysis.overallSentiment)}`}>
                <span className="font-medium">
                  {exchange.aiAnalysis.overallSentiment.toUpperCase()} Interaction
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Quest Summary Stats */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Duration</p>
                <p className="text-2xl font-bold text-gray-900">{exchange.duration}m</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Clock size={24} className="text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">XP Earned</p>
                <p className="text-2xl font-bold text-gray-900">+{exchange.xpEarned}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Zap size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Safety Score</p>
                <p className="text-2xl font-bold text-gray-900">{exchange.aiAnalysis.safetyScore}%</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Shield size={24} className="text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Messages</p>
                <p className="text-2xl font-bold text-gray-900">{exchange.messages.length}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <MessageSquare size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-2 mb-8">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as 'conversation' | 'analysis')}
                className={`flex-1 py-3 px-6 rounded-lg font-semibold text-base transition-all duration-200 flex items-center justify-center relative ${
                  activeTab === tab.key
                    ? 'bg-blue-600 text-white shadow-md'
                    : tab.key === 'analysis' && !isProUser
                    ? 'text-gray-400 cursor-not-allowed'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
                disabled={tab.key === 'analysis' && !isProUser}
              >
                <tab.icon size={20} className="mr-2" />
                {tab.label}
                {tab.key === 'analysis' && !isProUser && (
                  <Lock size={16} className="ml-2" />
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'conversation' ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">
                  Full Conversation
                </h3>
                
                <div className="space-y-6 max-h-96 overflow-y-auto">
                  {exchange.messages.map((message, index) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[80%] px-6 py-4 rounded-xl relative ${
                        message.type === 'user'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      } ${message.flagged ? 'ring-2 ring-red-500' : ''}`}>
                        
                        {message.type === 'ai' && (
                          <div className="flex items-center mb-3">
                            <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mr-2">
                              <Brain size={12} className="text-white" />
                            </div>
                            <span className="text-sm font-medium text-gray-600">AI Assistant</span>
                          </div>
                        )}
                        
                        <p className="text-base leading-relaxed">{message.content}</p>
                        
                        {message.flagged && (
                          <div className="mt-3 flex items-center text-sm text-red-600">
                            <Flag size={14} className="mr-1" />
                            <span>{message.flagReason}</span>
                          </div>
                        )}
                        
                        <div className="text-xs opacity-70 mt-3">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : activeTab === 'analysis' && !isProUser ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Crown size={40} className="text-yellow-600" />
                  </div>
                  
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                    Advanced AI Analysis
                  </h3>
                  
                  <p className="text-gray-600 mb-8 max-w-md mx-auto">
                    Get detailed insights into your child's learning patterns, emotional development, 
                    and safety analysis with Pro Analytics.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 max-w-lg mx-auto">
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                      <ThumbsUp size={20} className="text-green-600 mr-3" />
                      <span className="text-sm text-gray-700">Positive Highlights</span>
                    </div>
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                      <TrendingUp size={20} className="text-blue-600 mr-3" />
                      <span className="text-sm text-gray-700">Learning Recommendations</span>
                    </div>
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                      <AlertTriangle size={20} className="text-yellow-600 mr-3" />
                      <span className="text-sm text-gray-700">Areas of Attention</span>
                    </div>
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                      <Flag size={20} className="text-red-600 mr-3" />
                      <span className="text-sm text-gray-700">Safety Analysis</span>
                    </div>
                  </div>
                  
                  <button className="px-8 py-3 bg-gradient-to-r from-yellow-400 to-green-500 text-white rounded-lg font-semibold hover:from-yellow-500 hover:to-green-600 transition-all shadow-lg">
                    <Crown size={18} className="inline mr-2" />
                    Upgrade to Pro - $20/month
                  </button>
                </div>
              </div>
            ) : activeTab === 'analysis' && isProUser ? (
              <div className="space-y-8">
                {/* Positive Signals */}
                {exchange.aiAnalysis.positiveSignals.length > 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div className="flex items-center mb-6">
                      <ThumbsUp size={24} className="text-green-600 mr-3" />
                      <h3 className="text-xl font-semibold text-gray-900">
                        Positive Highlights
                      </h3>
                    </div>
                    
                    <div className="space-y-4">
                      {exchange.aiAnalysis.positiveSignals.map((signal, index) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle size={20} className="text-green-600 mr-4 mt-1 flex-shrink-0" />
                          <p className="text-gray-900">{signal}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Concerns */}
                {exchange.aiAnalysis.concerns.length > 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div className="flex items-center mb-6">
                      <AlertTriangle size={24} className="text-yellow-600 mr-3" />
                      <h3 className="text-xl font-semibold text-gray-900">
                        Areas of Attention
                      </h3>
                    </div>
                    
                    <div className="space-y-4">
                      {exchange.aiAnalysis.concerns.map((concern, index) => (
                        <div key={index} className="flex items-start">
                          <AlertTriangle size={20} className="text-yellow-600 mr-4 mt-1 flex-shrink-0" />
                          <p className="text-gray-900">{concern}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recommendations */}
                {exchange.aiAnalysis.recommendations.length > 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div className="flex items-center mb-6">
                      <TrendingUp size={24} className="text-blue-600 mr-3" />
                      <h3 className="text-xl font-semibold text-gray-900">
                        Recommendations
                      </h3>
                    </div>
                    
                    <div className="space-y-4">
                      {exchange.aiAnalysis.recommendations.map((recommendation, index) => (
                        <div key={index} className="flex items-start">
                          <Star size={20} className="text-blue-600 mr-4 mt-1 flex-shrink-0" />
                          <p className="text-gray-900">{recommendation}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Flagged Content */}
                {exchange.aiAnalysis.flaggedContent.length > 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div className="flex items-center mb-6">
                      <Flag size={24} className="text-red-600 mr-3" />
                      <h3 className="text-xl font-semibold text-gray-900">
                        Flagged Content
                      </h3>
                    </div>
                    
                    <div className="space-y-6">
                      {exchange.aiAnalysis.flaggedContent.map((flag, index) => (
                        <div key={index} className={`p-6 rounded-xl border ${getSeverityColor(flag.severity)}`}>
                          <div className="flex items-center justify-between mb-3">
                            <span className="font-semibold text-gray-900">{flag.category.replace('_', ' ').toUpperCase()}</span>
                            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSeverityColor(flag.severity)}`}>
                              {flag.severity.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-gray-900 mb-3">{flag.description}</p>
                          <p className="text-sm text-gray-600 italic">{flag.suggestion}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            {/* Overall Assessment */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center mb-4">
                <Eye size={20} className="text-purple-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">
                  Overall Assessment
                </h3>
              </div>
              
              <div className="space-y-4">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-1">
                    {exchange.aiAnalysis.safetyScore}%
                  </div>
                  <div className="text-sm text-gray-600">Safety Score</div>
                </div>
                
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className={`text-2xl font-bold mb-1 ${
                    exchange.aiAnalysis.overallSentiment === 'positive' ? 'text-green-600' :
                    exchange.aiAnalysis.overallSentiment === 'neutral' ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {exchange.aiAnalysis.overallSentiment.toUpperCase()}
                  </div>
                  <div className="text-sm text-gray-600">Overall Sentiment</div>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-gray-900">
                  <strong>Summary:</strong> This quest interaction shows {
                    exchange.aiAnalysis.overallSentiment === 'positive' ? 'healthy engagement and positive learning outcomes' :
                    exchange.aiAnalysis.overallSentiment === 'neutral' ? 'normal interaction with some areas for improvement' :
                    'concerning patterns that may require attention'
                  }. The safety score of {exchange.aiAnalysis.safetyScore}% indicates {
                    exchange.aiAnalysis.safetyScore >= 95 ? 'excellent' :
                    exchange.aiAnalysis.safetyScore >= 85 ? 'good' :
                    'concerning'
                  } content safety levels.
                </p>
              </div>
            </div>

            {/* Related Alerts */}
            {relatedAlerts.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center mb-4">
                  <Bell size={20} className="text-orange-600 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-900">
                    Generated Alerts
                  </h3>
                </div>
                
                <div className="space-y-4">
                  {relatedAlerts.map((alert) => {
                    const AlertIcon = getTypeIcon(alert.type);
                    const alertColor = getSeverityColor(alert.severity);
                    
                    return (
                      <div key={alert.id} className={`p-4 rounded-lg border ${alertColor}`}>
                        <div className="flex items-start">
                          <AlertIcon size={16} className="mr-3 mt-1" />
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 mb-1">{alert.title}</h4>
                            <p className="text-sm text-gray-600">{alert.description}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quest Details */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quest Details</h3>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Quest Type:</span>
                  <span className="font-medium text-gray-900">{quest.type.charAt(0).toUpperCase() + quest.type.slice(1)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Difficulty:</span>
                  <span className="font-medium text-gray-900">{quest.difficulty.charAt(0).toUpperCase() + quest.difficulty.slice(1)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Expected Duration:</span>
                  <span className="font-medium text-gray-900">{quest.duration} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">XP Value:</span>
                  <span className="font-medium text-gray-900">{quest.xpValue} XP</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuestReview;