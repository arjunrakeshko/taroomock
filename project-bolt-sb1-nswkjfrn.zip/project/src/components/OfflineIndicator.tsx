import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Download } from 'lucide-react';

const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setIsLoading(true);
      // Simulate asset preload
      setTimeout(() => setIsLoading(false), 3000);
    };
    
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && !isLoading) return null;

  return (
    <div className={`
      fixed top-4 left-1/2 transform -translate-x-1/2 z-50
      px-4 py-2 rounded-full shadow-card
      ${isOnline ? 'bg-info-blue' : 'bg-warning-yellow'}
      text-white text-sm font-medium
      flex items-center gap-2
      animate-slide-up
    `}>
      {isLoading ? (
        <>
          <Download size={16} className="animate-pulse" />
          <span>Loading content...</span>
        </>
      ) : (
        <>
          <WifiOff size={16} />
          <span>You're offline</span>
        </>
      )}
    </div>
  );
};

export default OfflineIndicator;