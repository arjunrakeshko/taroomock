import React, { createContext, useContext, useState, useEffect } from 'react';
import { mockQuests, mockUser, mockLeaderboard, mockBadges, mockShareableCreations, mockFriendsLeagues } from '../data/mockData';
import { userTiers, mockWeeklyProgressCard, mockCommunityMilestones } from '../data/mockData';
import { mockQuestExchanges, mockParentAlerts } from '../data/mockQuestExchanges';
import { Quest, User, LeaderboardEntry, Badge, Profile, QuestExchange, ParentAlert, ShareableCreation, FriendsLeague, UserTier, WeeklyProgressCard, CommunityMilestone, QuestTile, ShuffleToken } from '../types';

interface AppContextType {
  user: User;
  quests: Quest[];
  questTiles: QuestTile[];
  shuffleTokens: ShuffleToken;
  leaderboard: LeaderboardEntry[];
  badges: Badge[];
  userBadges: string[];
  completedQuests: string[];
  favoriteQuests: string[];
  questExchanges: QuestExchange[];
  parentAlerts: ParentAlert[];
  shareableCreations: ShareableCreation[];
  friendsLeagues: FriendsLeague[];
  userTiers: UserTier[];
  weeklyProgressCard: WeeklyProgressCard | null;
  communityMilestones: CommunityMilestone[];
  streak: number;
  isParentMode: boolean;
  activeProfile: Profile | null;
  completeQuest: (questId: string) => void;
  completeTile: (tileId: string) => void;
  shuffleTheme: (tileId: string) => void;
  toggleFavorite: (questId: string) => void;
  earnBadge: (badgeId: string) => void;
  setParentMode: (mode: boolean) => void;
  updateStreak: () => void;
  setActiveProfile: (profile: Profile | null) => void;
  setUser: (user: User) => void;
  markAlertAsRead: (alertId: string) => void;
  getUnreadAlertsCount: () => number;
  getLockedQuests: () => string[];
  toggleQuestLock: (questId: string) => void;
  lockAllQuests: () => void;
  unlockAllQuests: () => void;
  getQuestExchange: (questId: string, childId: string) => QuestExchange | undefined;
  getShareableCreations: (childId: string) => ShareableCreation[];
  getFriendsLeagues: (childId: string) => FriendsLeague[];
  getUserTier: (xp: number) => UserTier;
  getProgressToNextTier: (xp: number) => { current: number; total: number; percentage: number };
  dismissWeeklyProgressCard: () => void;
  shouldShowConfetti: () => boolean;
  resetConfettiFlag: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(mockUser);
  const [quests] = useState<Quest[]>(mockQuests);
  const [questTiles, setQuestTiles] = useState<QuestTile[]>([
    {
      id: 'tile-1',
      gameType: 'snap-trail',
      theme: 'Forest Adventure',
      level: 1,
      isUnlocked: true,
      isCompleted: false,
      shuffleCost: 1,
      xpReward: 150,
      description: 'Capture magical moments in the enchanted forest'
    },
    {
      id: 'tile-2',
      gameType: '20q',
      theme: 'Forest Animals',
      level: 2,
      isUnlocked: true,
      isCompleted: false,
      shuffleCost: 1,
      xpReward: 200,
      description: 'Guess the hidden object in 20 questions or less'
    },
    {
      id: 'tile-3',
      gameType: 'prompt-potion',
      theme: 'Woodland Creatures',
      level: 1,
      isUnlocked: true,
      isCompleted: false,
      shuffleCost: 1,
      xpReward: 180,
      description: 'Brew stories with friendly forest animals'
    },
    {
      id: 'tile-4',
      gameType: 'logic-dash',
      theme: 'Tree Puzzles',
      level: 1,
      isUnlocked: false,
      isCompleted: false,
      shuffleCost: 1,
      xpReward: 220,
      description: 'Solve mysteries hidden in ancient trees'
    },
    {
      id: 'tile-5',
      gameType: 'heart-connect',
      theme: 'Nature Friends',
      level: 3,
      isUnlocked: false,
      isCompleted: false,
      shuffleCost: 1,
      xpReward: 240,
      description: 'Connect with the heart of the forest'
    },
  ]);
  const [shuffleTokens, setShuffleTokens] = useState<ShuffleToken>({ count: 3, earnedFrom: [] });
  const [leaderboard] = useState<LeaderboardEntry[]>(mockLeaderboard);
  const [badges] = useState<Badge[]>(mockBadges);
  const [userBadges, setUserBadges] = useState<string[]>(['early-bird', 'first-quest']);
  const [completedQuests, setCompletedQuests] = useState<string[]>(['1', '3']);
  const [favoriteQuests, setFavoriteQuests] = useState<string[]>(['2', '4']);
  const [questExchanges] = useState<QuestExchange[]>(mockQuestExchanges);
  const [parentAlerts, setParentAlerts] = useState<ParentAlert[]>(mockParentAlerts);
  const [shareableCreations] = useState<ShareableCreation[]>(mockShareableCreations);
  const [friendsLeagues] = useState<FriendsLeague[]>(mockFriendsLeagues);
  const [weeklyProgressCard, setWeeklyProgressCard] = useState<WeeklyProgressCard | null>(mockWeeklyProgressCard);
  const [communityMilestones] = useState<CommunityMilestone[]>(mockCommunityMilestones);
  const [confettiShown, setConfettiShown] = useState(false);
  const [streak, setStreak] = useState(7);
  const [isParentMode, setIsParentMode] = useState(false);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [lockedQuests, setLockedQuests] = useState<string[]>([]);

  const completeQuest = (questId: string) => {
    const quest = quests.find(q => q.id === questId);
    if (quest && !completedQuests.includes(questId)) {
      setCompletedQuests(prev => [...prev, questId]);
      setUser(prev => ({
        ...prev,
        xp: prev.xp + quest.xpValue,
        level: Math.floor((prev.xp + quest.xpValue) / 200) + 1
      }));
      
      // Check for badge unlocks
      if (completedQuests.length === 0) {
        earnBadge('first-quest');
      }
    }
  };

  const completeTile = (tileId: string) => {
    setQuestTiles(prev => prev.map(tile => {
      if (tile.id === tileId) {
        return { ...tile, isCompleted: true };
      }
      return tile;
    }));
    
    // Find the completed tile to get XP reward
    const completedTile = questTiles.find(t => t.id === tileId);
    if (completedTile) {
      // Award XP and shuffle token
      setUser(prevUser => ({
        ...prevUser,
        xp: prevUser.xp + completedTile.xpReward,
        level: Math.floor((prevUser.xp + completedTile.xpReward) / 200) + 1
      }));
      
      setShuffleTokens(prevTokens => ({
        count: prevTokens.count + 1,
        earnedFrom: [...prevTokens.earnedFrom, tileId]
      }));
    }
    
    // Ensure we always have 4 tiles available (3 unlocked + 1 locked for preview)
    setQuestTiles(prev => {
      const completedCount = prev.filter(t => t.isCompleted).length;
      const unlockedCount = prev.filter(t => t.isUnlocked && !t.isCompleted).length;
      const totalAvailable = completedCount + unlockedCount;
      
      // If we have less than 3 unlocked tiles available, unlock the next one
      if (totalAvailable < 4) {
        const nextLockedTile = prev.find(t => !t.isUnlocked && !t.isCompleted);
        if (nextLockedTile) {
          return prev.map(tile => {
            if (tile.id === nextLockedTile.id) {
              return { ...tile, isUnlocked: true };
            }
            return tile;
          });
        }
      }
      return prev;
    });
  };

  const shuffleTheme = (tileId: string) => {
    if (shuffleTokens.count <= 0) return;
    
    const themes = {
      'snap-trail': ['Forest Adventure', 'Mountain Peaks', 'Ocean Depths', 'Desert Oasis', 'Arctic Wonder'],
      '20q': ['Forest Animals', 'Woodland Plants', 'Nature Objects', 'Forest Sounds', 'Tree Types'],
      'prompt-potion': ['Woodland Creatures', 'Magical Beings', 'Space Friends', 'Underwater Life', 'Sky Dwellers'],
      'logic-dash': ['Tree Puzzles', 'Rock Formations', 'Water Flows', 'Wind Patterns', 'Fire Elements'],
      'heart-connect': ['Nature Friends', 'Animal Bonds', 'Plant Spirits', 'Weather Moods', 'Season Changes']
    };
    
    setQuestTiles(prev => prev.map(tile => {
      if (tile.id === tileId && tile.isUnlocked && !tile.isCompleted) {
        const availableThemes = themes[tile.gameType].filter(theme => theme !== tile.theme);
        const newTheme = availableThemes[Math.floor(Math.random() * availableThemes.length)];
        return { ...tile, theme: newTheme };
      }
      return tile;
    }));
    
    setShuffleTokens(prev => ({
      count: prev.count - 1,
      earnedFrom: prev.earnedFrom
    }));
  };
  const toggleFavorite = (questId: string) => {
    setFavoriteQuests(prev => 
      prev.includes(questId) 
        ? prev.filter(id => id !== questId)
        : [...prev, questId]
    );
  };

  const earnBadge = (badgeId: string) => {
    if (!userBadges.includes(badgeId)) {
      setUserBadges(prev => [...prev, badgeId]);
    }
  };

  const updateStreak = () => {
    setStreak(prev => prev + 1);
    if (streak >= 7) {
      earnBadge('streak-master');
    }
  };

  const markAlertAsRead = (alertId: string) => {
    setParentAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId ? { ...alert, isRead: true } : alert
      )
    );
  };

  const getUnreadAlertsCount = () => {
    return parentAlerts.filter(alert => !alert.isRead).length;
  };

  const getQuestExchange = (questId: string, childId: string) => {
    return questExchanges.find(exchange => 
      exchange.questId === questId && exchange.childId === childId
    );
  };

  const getShareableCreations = (childId: string) => {
    return shareableCreations.filter(creation => creation.childId === childId);
  };

  const getFriendsLeagues = (childId: string) => {
    return friendsLeagues.filter(league => league.childId === childId);
  };
  const getProgressToNextTier = (xp: number) => {
    const currentTier = getUserTier(xp);
    const nextTier = userTiers.find(tier => tier.name === currentTier.nextTier);
    
    if (!nextTier) {
      return { current: 100, total: 100, percentage: 100 };
    }
    
    const current = xp - currentTier.minXp;
    const total = nextTier.minXp - currentTier.minXp;
    const percentage = Math.min((current / total) * 100, 100);
    
    return { current, total, percentage };
  };

  const dismissWeeklyProgressCard = () => {
    setWeeklyProgressCard(null);
  };
  const getUserTier = (xp: number): UserTier => {
    return userTiers.find(tier => xp >= tier.minXp && xp <= tier.maxXp) || userTiers[0];
  };

  const shouldShowConfetti = () => {
    return !confettiShown;
  };

  const resetConfettiFlag = () => {
    setConfettiShown(true);
  };

  const getLockedQuests = () => {
    return lockedQuests;
  };

  const toggleQuestLock = (questId: string) => {
    setLockedQuests(prev => 
      prev.includes(questId) 
        ? prev.filter(id => id !== questId)
        : [...prev, questId]
    );
  };

  const lockAllQuests = () => {
    setLockedQuests(quests.map(q => q.id));
  };

  const unlockAllQuests = () => {
    setLockedQuests([]);
  };

  return (
    <AppContext.Provider value={{
      user,
      quests,
      questTiles,
      shuffleTokens,
      leaderboard,
      badges,
      userBadges,
      completedQuests,
      favoriteQuests,
      questExchanges,
      parentAlerts,
      shareableCreations,
      friendsLeagues,
      userTiers,
      weeklyProgressCard,
      communityMilestones,
      streak,
      isParentMode,
      activeProfile,
      completeQuest,
      completeTile,
      shuffleTheme,
      toggleFavorite,
      earnBadge,
      setParentMode: setIsParentMode,
      updateStreak,
      setActiveProfile,
      setUser,
      markAlertAsRead,
      getUnreadAlertsCount,
      getQuestExchange,
      getShareableCreations,
      getFriendsLeagues,
      getUserTier,
      getProgressToNextTier,
      dismissWeeklyProgressCard,
      shouldShowConfetti,
      resetConfettiFlag,
      getLockedQuests,
      toggleQuestLock,
      lockAllQuests,
      unlockAllQuests
    }}>
      {children}
    </AppContext.Provider>
  );
};