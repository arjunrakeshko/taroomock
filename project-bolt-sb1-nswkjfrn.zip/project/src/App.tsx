import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import MobileLayout from './components/MobileLayout';
import OfflineIndicator from './components/OfflineIndicator';
import WeeklyLeague from './components/WeeklyLeague';
import Home from './pages/Home';
import CreativeStoryBuilder from './pages/CreativeStoryBuilder';
import QuestDetail from './pages/QuestDetail';
import Leaderboard from './pages/Leaderboard';
import Profile from './pages/Profile';
import MyQuests from './pages/MyQuests';
import ParentDashboard from './pages/ParentDashboard';
import Shop from './pages/Shop';
import ProfileSelection from './pages/ProfileSelection';
import PinEntry from './pages/PinEntry';
import QuestReview from './pages/QuestReview';
import SnapTrail from './pages/SnapTrail';
import TwentyQuestions from './pages/TwentyQuestions';

const AppContent: React.FC = () => {

  return (
    <div className="min-h-screen bg-gray-50">
      <OfflineIndicator />
      <WeeklyLeague />
      <Routes>
        <Route path="/profiles" element={<ProfileSelection />} />
        <Route path="/pin-entry" element={<PinEntry />} />
        <Route path="/parent-dashboard" element={<ParentDashboard />} />
        <Route path="/parent/shop" element={<Shop />} />
        <Route path="/parent/quest-review/:questId/:childId" element={<QuestReview />} />
        <Route path="/" element={<MobileLayout />}>
          <Route index element={<Home />} />
          <Route path="quest/:id" element={<QuestDetail />} />
          <Route path="creative-story-builder" element={<CreativeStoryBuilder />} />
          <Route path="snap-trail" element={<SnapTrail />} />
          <Route path="20q" element={<TwentyQuestions />} />
          <Route path="quests" element={<MyQuests />} />
          <Route path="leaderboard" element={<Leaderboard />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Routes>
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <Router>
        <AppContent />
      </Router>
    </AppProvider>
  );
}

export default App;