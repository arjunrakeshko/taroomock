import React, { useState, useEffect } from 'react';
import { ArrowLeft, Volume2, VolumeX, Sparkles, Download, Share2, Palette, Zap, Clock, Camera } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SpaceExplorerArt: React.FC = () => {
  const navigate = useNavigate();
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [questProgress, setQuestProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(240); // 4 minutes
  const [xp, setXp] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleQuestComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleBack = () => {
    navigate('/');
  };

  const handleTTSToggle = () => {
    setIsTTSEnabled(!isTTSEnabled);
  };

  const handleGenerateArt = async () => {
    if (!currentPrompt.trim() || isGenerating) return;

    setIsGenerating(true);
    
    // Simulate image generation
    setTimeout(() => {
      const mockImageUrl = `https://images.pexels.com/photos/${Math.floor(Math.random() * 1000000)}/pexels-photo-${Math.floor(Math.random() * 1000000)}.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2`;
      setGeneratedImages(prev => [...prev, mockImageUrl]);
      setQuestProgress(prev => Math.min(prev + 25, 100));
      setXp(prev => prev + 50);
      setIsGenerating(false);
      setCurrentPrompt('');
      
      if (questProgress >= 75) {
        setTimeout(() => handleQuestComplete(), 1000);
      }
    }, 3000);
  };

  const handleQuestComplete = () => {
    setIsCompleted(true);
    setXp(prev => prev + 200);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const spacePrompts = [
    "A colorful nebula with swirling galaxies and bright stars",
    "An astronaut floating near a beautiful planet with rings",
    "A space station orbiting around a glowing moon",
    "Alien creatures living on a crystal planet",
    "A rocket ship flying through a meteor shower"
  ];

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-4">
                  <Camera className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Space Art Complete!</h1>
              <p className="text-xl text-gray-600">You've created amazing space artwork!</p>
              
              <div className="flex justify-center gap-6 mt-6">
                <div className="text-center">
                  <div className="bg-blue-100 rounded-full p-3 mb-2">
                    <Zap className="w-6 h-6 text-blue-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600">{xp}</div>
                  <div className="text-sm text-gray-600">XP Earned</div>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 rounded-full p-3 mb-2">
                    <Camera className="w-6 h-6 text-green-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-green-600">{generatedImages.length}</div>
                  <div className="text-sm text-gray-600">Images Created</div>
                </div>
                <div className="text-center">
                  <div className="bg-purple-100 rounded-full p-3 mb-2">
                    <Sparkles className="w-6 h-6 text-purple-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600">100%</div>
                  <div className="text-sm text-gray-600">Creativity Score</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Space Art Gallery</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`Space artwork ${index + 1}`}
                    className="w-full h-64 object-cover rounded-xl shadow-lg"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center">
                    <div className="flex space-x-3">
                      <button className="p-3 bg-white rounded-full hover:bg-gray-100 transition-colors">
                        <Download size={20} className="text-gray-700" />
                      </button>
                      <button className="p-3 bg-white rounded-full hover:bg-gray-100 transition-colors">
                        <Share2 size={20} className="text-gray-700" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={() => navigate('/')}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg"
              >
                Back to Quests
              </button>
              <button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-blue-600 transition-all duration-200 shadow-lg">
                Create More Art
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex flex-col">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm sticky top-0 z-40 px-4 py-4 border-b border-white/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors mr-3"
            >
              <ArrowLeft size={20} className="text-white" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                <Camera size={20} className="text-white mr-2" />
                <h1 className="font-quicksand font-semibold text-lg text-white truncate">
                  Space Explorer Art
                </h1>
              </div>
              <div className="flex items-center text-sm text-white/70">
                <Clock size={14} className="mr-1" />
                <span>{formatTime(timeRemaining)}</span>
                <Zap size={14} className="ml-3 mr-1" />
                <span>{xp} XP</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={handleTTSToggle}
            className={`p-3 rounded-full transition-colors ml-2 ${
              isTTSEnabled 
                ? 'bg-green-500 text-white' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
          >
            {isTTSEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-white/70 mb-2">
            <span>Art Creation Progress</span>
            <span>{questProgress}%</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-purple-400 to-pink-400"
              style={{ width: `${questProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4">
        {/* Art Creation Panel */}
        <div className="bg-white/10 backdrop-blur-sm rounded-card p-6 mb-6">
          <h2 className="font-quicksand font-semibold text-xl text-white mb-4 flex items-center">
            <Palette size={24} className="mr-2" />
            Create Space Art
          </h2>
          <p className="text-white/80 mb-6">
            Describe the space scene you want to create and watch AI bring it to life!
          </p>
          
          <textarea
            value={currentPrompt}
            onChange={(e) => setCurrentPrompt(e.target.value)}
            placeholder="Describe your space artwork... (e.g., 'A colorful nebula with swirling galaxies')"
            className="w-full px-4 py-3 rounded-xl border border-white/20 bg-white/10 backdrop-blur-sm text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 resize-none"
            rows={3}
          />
          
          <div className="flex flex-wrap gap-2 my-4">
            <span className="text-white/70 text-sm">Quick ideas:</span>
            {spacePrompts.slice(0, 3).map((prompt, index) => (
              <button
                key={index}
                onClick={() => setCurrentPrompt(prompt)}
                className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white/80 text-xs transition-colors"
              >
                {prompt.slice(0, 30)}...
              </button>
            ))}
          </div>
          
          <button
            onClick={handleGenerateArt}
            disabled={!currentPrompt.trim() || isGenerating}
            className={`w-full py-4 px-6 rounded-xl font-semibold transition-all duration-200 transform active:scale-95 ${
              !currentPrompt.trim() || isGenerating
                ? 'bg-white/20 text-white/50 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg'
            }`}
          >
            {isGenerating ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Creating Space Art...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <Sparkles size={20} className="mr-2" />
                Generate Space Art
              </div>
            )}
          </button>
        </div>

        {/* Generated Images Gallery */}
        {generatedImages.length > 0 && (
          <div className="bg-white/10 backdrop-blur-sm rounded-card p-6">
            <h3 className="font-quicksand font-semibold text-lg text-white mb-4">
              Your Space Art Gallery
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`Space artwork ${index + 1}`}
                    className="w-full h-48 object-cover rounded-xl"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center">
                    <div className="flex space-x-3">
                      <button className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors">
                        <Download size={16} className="text-gray-700" />
                      </button>
                      <button className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors">
                        <Share2 size={16} className="text-gray-700" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SpaceExplorerArt;