import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface MascotToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
  type?: 'success' | 'info' | 'warning';
}

const MascotToast: React.FC<MascotToastProps> = ({ 
  message, 
  isVisible, 
  onClose, 
  type = 'info' 
}) => {
  const [shouldRender, setShouldRender] = useState(isVisible);

  useEffect(() => {
    if (isVisible) {
      setShouldRender(true);
      const timer = setTimeout(() => {
        onClose();
      }, 4000);
      return () => clearTimeout(timer);
    } else {
      const timer = setTimeout(() => {
        setShouldRender(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!shouldRender) return null;

  const mascotExpression = {
    success: '🎉',
    info: '💡',
    warning: '⚠️'
  };

  const bgColor = {
    success: 'bg-success-green/10',
    info: 'bg-info-blue/10',
    warning: 'bg-warning-yellow/10'
  };

  return (
    <div className={`fixed bottom-24 left-4 right-4 z-50 transition-all duration-300 ${
      isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
    }`}>
      <div className={`flex items-center p-4 rounded-card shadow-lg ${bgColor[type]}`} style={{ minHeight: '72px' }}>
        <div className="flex-shrink-0 mr-4">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-md">
            <span className="text-2xl">{mascotExpression[type]}</span>
          </div>
        </div>
        
        <div className="flex-1">
          <p className="text-text-navy font-medium">
            {message}
          </p>
        </div>
        
        <button
          onClick={onClose}
          className="flex-shrink-0 ml-4 p-2 rounded-full bg-white hover:bg-surface-gray transition-colors"
          style={{ minWidth: '48px', minHeight: '48px' }}
        >
          <X size={20} className="text-gray-600" />
        </button>
      </div>
    </div>
  );
};

export default MascotToast;