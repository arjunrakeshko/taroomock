import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { LeaderboardEntry } from '../types';

interface LeaderboardRowProps {
  entry: LeaderboardEntry;
  index: number;
}

const LeaderboardRow: React.FC<LeaderboardRowProps> = ({ entry, index }) => {
  const isCurrentUser = false; // Hidden from children - only shown in parent analytics
  const rankImproved = entry.previousRank > entry.rank;
  // Remove rank worsened indicators - only show positive changes

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'text-yellow-600';
    if (rank === 2) return 'text-gray-600';
    if (rank === 3) return 'text-orange-600';
    return 'text-gray-800';
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return rank.toString();
  };

  return (
    <div className={`flex items-center p-4 rounded-card transition-all duration-200 ${
      isCurrentUser 
        ? 'bg-green-50 border-2 border-primary-green'
        : 'bg-white hover:bg-gray-50'
    } ${index < 3 ? 'shadow-lg' : 'shadow-md'}`}>
      <div className="flex items-center justify-center w-12 h-12 mr-4">
        <span className={`text-xl font-bold ${getRankColor(entry.rank)}`}>
          {getRankIcon(entry.rank)}
        </span>
      </div>
      
      <div className="w-12 h-12 rounded-full mr-4 bg-white border-2 border-green-200 flex items-center justify-center shadow-sm"
           style={{ minWidth: '48px', minHeight: '48px' }}>
        <span className="text-2xl">{entry.avatar}</span>
      </div>
      
      <div className="flex-1">
        <div className="flex items-center">
          <h3 className={`font-semibold ${isCurrentUser ? 'text-text-navy' : 'text-text-navy'}`}>
            {entry.name}
          </h3>
          {isCurrentUser && (
            <span className="ml-2 px-2 py-1 rounded-full text-xs font-medium bg-primary-green text-white">
              You
            </span>
          )}
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <div className="flex items-center text-sm text-text-gray">
            <span>Level {entry.level}</span>
            {entry.streak > 0 && (
              <>
                <span className="mx-2">•</span>
                <span className="flex items-center">
                  🔥 {entry.streak} day streak
                </span>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="text-right">
        <div className="text-lg font-bold text-primary-green">
          {entry.xp.toLocaleString()}
        </div>
        <div className="flex items-center justify-end text-sm">
          {rankImproved && (
            <div className="flex items-center text-green-600">
              <TrendingUp size={16} className="mr-1" />
              <span>Improved!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaderboardRow;