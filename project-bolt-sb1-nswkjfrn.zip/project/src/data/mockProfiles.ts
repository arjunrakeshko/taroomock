import { Profile, User } from '../types';

export const mockProfiles: Profile[] = [
  {
    id: 'kid1',
    name: 'Alex',
    avatar: '🦊',
    type: 'kid',
    pin: '1111',
    isActive: false,
    user: {
      id: '1',
      name: 'Alex',
      avatar: '🦊',
      level: 12,
      xp: 2450,
      xpToNextLevel: 550,
      streak: 7,
      rank: 23,
      joinDate: '2024-01-15',
      screenTime: 125,
      safetyScore: 98
    }
  },
  {
    id: 'kid2',
    name: 'Emma',
    avatar: '🐰',
    type: 'kid',
    pin: '2222',
    isActive: false,
    user: {
      id: '2',
      name: 'Emma',
      avatar: '🐰',
      level: 18,
      xp: 4250,
      xpToNextLevel: 350,
      streak: 12,
      rank: 1,
      joinDate: '2023-12-01',
      screenTime: 95,
      safetyScore: 100
    }
  },
  {
    id: 'parent',
    name: 'Parents',
    avatar: '🐻',
    type: 'parent',
    pin: '9999',
    isActive: false,
    parentData: {
      hasProSubscription: false,
      subscribedChildCount: 0,
      children: ['kid1', 'kid2']
    }
  }
];