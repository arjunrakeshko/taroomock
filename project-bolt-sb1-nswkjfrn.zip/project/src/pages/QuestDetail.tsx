import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Volume2, VolumeX, Send, Camera, Search, MessageCircle, Zap, Clock } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import SpaceExplorerArt from './SpaceExplorerArt';
import AnimalFactsDetective from './AnimalFactsDetective';
import RobotFriendDesigner from './RobotFriendDesigner';
import BadgeModal from '../components/BadgeModal';
import MascotToast from '../components/MascotToast';

const QuestDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { quests, completeQuest, earnBadge, badges } = useApp();
  
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [currentInput, setCurrentInput] = useState('');
  const [questProgress, setQuestProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [earnedBadge, setEarnedBadge] = useState(null);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const quest = quests.find(q => q.id === id);

  // Redirect to Creative Story Builder for quest ID 1
  useEffect(() => {
    if (quest && quest.id === '1') {
      navigate('/creative-story-builder');
      return;
    }
    
    // Redirect to dedicated quest pages
    if (quest && quest.id === '2') {
      // Space Explorer Art - render component directly
      return;
    }
    if (quest && quest.id === '3') {
      // Animal Facts Detective - render component directly
      return;
    }
    if (quest && quest.id === '4') {
      // Robot Friend Designer - render component directly
      return;
    }
  }, [quest, navigate]);

  useEffect(() => {
    if (!quest) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleQuestComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [quest]);

  useEffect(() => {
    if (quest && quest.type === 'chat') {
      setChatMessages([
        {
          type: 'ai',
          content: `Welcome to "${quest.title}"! ${quest.description} Let's start by telling me what kind of story you'd like to create!`,
          timestamp: Date.now()
        }
      ]);
    }
  }, [quest]);

  if (!quest) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Quest not found</h2>
          <button 
            onClick={() => navigate('/')}
            className="text-primary-blue hover:underline p-2"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  // Render dedicated quest components
  if (quest.id === '2') {
    return <SpaceExplorerArt />;
  }
  
  if (quest.id === '3') {
    return <AnimalFactsDetective />;
  }
  
  if (quest.id === '4') {
    return <RobotFriendDesigner />;
  }

  const handleBack = () => {
    navigate('/');
  };

  const handleTTSToggle = () => {
    setIsTTSEnabled(!isTTSEnabled);
    if (!isTTSEnabled) {
      speakText("Text to speech is now enabled");
    }
  };

  const speakText = (text: string) => {
    if (isTTSEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }
  };

  const handleSendMessage = async () => {
    if (!currentInput.trim() || isGenerating) return;

    const userMessage = {
      type: 'user',
      content: currentInput,
      timestamp: Date.now()
    };

    setChatMessages(prev => [...prev, userMessage]);
    setCurrentInput('');
    setIsGenerating(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        type: 'ai',
        content: generateAIResponse(currentInput, quest.type),
        timestamp: Date.now()
      };
      
      setChatMessages(prev => [...prev, aiResponse]);
      setIsGenerating(false);
      setQuestProgress(prev => Math.min(prev + 25, 100));
      
      if (isTTSEnabled) {
        speakText(aiResponse.content);
      }

      if (questProgress >= 75) {
        setTimeout(() => handleQuestComplete(), 1000);
      }
    }, 2000);
  };

  const generateAIResponse = (input: string, type: string) => {
    const responses = {
      chat: [
        "That's a fantastic idea! Let's build on that. What happens next in your story?",
        "I love your creativity! How about we add some magical elements to make it even more exciting?",
        "Wonderful! Your story is taking shape beautifully. Can you describe the main character?",
        "Amazing work! Let's add some adventure to your tale. What challenge should they face?"
      ],
      image: [
        "Great concept! I'm generating an amazing image based on your description...",
        "Your imagination is incredible! Creating a beautiful artwork for you now...",
        "Perfect details! Let me bring your vision to life with AI art...",
        "Excellent idea! Generating a stunning image that matches your creativity..."
      ],
      search: [
        "Interesting question! Let me help you discover some amazing facts about that...",
        "Great research topic! I found some fascinating information you'll love...",
        "Excellent curiosity! Here are some incredible discoveries about your subject...",
        "Perfect question! Let me share some mind-blowing facts I found..."
      ]
    };

    const typeResponses = responses[type] || responses.chat;
    return typeResponses[Math.floor(Math.random() * typeResponses.length)];
  };

  const handleQuestComplete = () => {
    completeQuest(quest.id);
    
    // Check for badge earning
    const possibleBadges = ['first-quest', 'creative-genius', 'explorer'];
    const randomBadge = possibleBadges[Math.floor(Math.random() * possibleBadges.length)];
    const badge = badges.find(b => b.id === randomBadge);
    
    if (badge) {
      setEarnedBadge(badge);
      earnBadge(badge.id);
    }
    
    setShowCompletionModal(true);
    setToastMessage(`Amazing work! You earned ${quest.xpValue} XP! 🎉`);
    setShowToast(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getQuestIcon = (type: string) => {
    switch (type) {
      case 'chat': return <MessageCircle size={20} />;
      case 'image': return <Camera size={20} />;
      case 'search': return <Search size={20} />;
      default: return <MessageCircle size={20} />;
    }
  };

  const progressPercentage = questProgress;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex flex-col">
      {/* Header */}
      <div className="bg-white sticky top-0 z-40 px-4 py-4 border-b border-border-gray safe-area-pt">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-surface-gray hover:bg-border-gray transition-colors mr-3"
              style={{ minWidth: '48px', minHeight: '48px' }}
            >
              <ArrowLeft size={20} className="text-text-gray" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                {getQuestIcon(quest.type)}
                <h1 className="font-quicksand font-semibold text-lg text-text-navy ml-2 truncate">
                  {quest.title}
                </h1>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Clock size={14} className="mr-1" />
                <span>{formatTime(timeRemaining)}</span>
                <Zap size={14} className="ml-3 mr-1" />
                <span>{quest.xpValue} XP</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={handleTTSToggle}
            className={`p-3 rounded-full transition-colors ml-2 ${
              isTTSEnabled 
                ? 'bg-primary-green text-white' 
                : 'bg-surface-gray hover:bg-border-gray text-text-gray'
            }`}
            style={{ minWidth: '48px', minHeight: '48px' }}
          >
            {isTTSEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-text-gray mb-2">
            <span>Quest Progress</span>
            <span>{progressPercentage}%</span>
          </div>
          <div className="h-2 bg-surface-gray rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-primary-green to-green-400"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quest Content */}
      <div className="flex-1 flex flex-col pb-24">
        {quest.type === 'chat' && (
          <>
            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatMessages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] px-4 py-3 rounded-2xl ${
                    message.type === 'user'
                      ? 'bg-primary-green text-white'
                      : 'bg-white text-text-navy shadow-md'
                  }`}>
                    <p className="text-sm leading-relaxed">{message.content}</p>
                  </div>
                </div>
              ))}
              
              {isGenerating && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] px-4 py-3 rounded-2xl bg-white shadow-md">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Input Area */}
            <div className="bg-white border-t border-border-gray p-4 safe-area-pb">
              <div className="flex items-end space-x-3">
                <textarea
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-3 rounded-2xl border border-border-gray bg-surface-gray focus:outline-none focus:ring-2 focus:ring-primary-green/20 focus:border-primary-green resize-none"
                  disabled={isGenerating}
                  rows={1}
                  style={{ minHeight: '48px', maxHeight: '120px' }}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!currentInput.trim() || isGenerating}
                  className={`p-3 rounded-full transition-all duration-200 transform active:scale-95 ${
                    !currentInput.trim() || isGenerating
                      ? 'bg-surface-gray text-text-gray cursor-not-allowed'
                      : 'bg-primary-green text-white hover:bg-green-600 shadow-button'
                  }`}
                  style={{ minWidth: '48px', minHeight: '48px' }}
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </>
        )}

        {quest.type === 'image' && (
          <div className="flex-1 p-4 pb-24">
            <div className="bg-white rounded-card p-6 shadow-card mb-6">
              <h2 className="font-quicksand font-semibold text-xl text-text-navy mb-4">
                Create Amazing Art! 🎨
              </h2>
              <p className="text-gray-600 mb-6">
                Describe what you want to create and watch AI bring your imagination to life!
              </p>
              
              <textarea
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                placeholder="Describe your artwork... (e.g., 'A magical unicorn flying over a rainbow castle')"
                className="w-full px-4 py-3 rounded-xl border border-border-gray bg-surface-gray focus:outline-none focus:ring-2 focus:ring-primary-green/20 focus:border-primary-green resize-none"
                rows={4}
              />
              
              <button
                onClick={handleSendMessage}
                disabled={!currentInput.trim() || isGenerating}
                className={`w-full mt-4 py-4 px-6 rounded-full font-semibold transition-all duration-200 transform active:scale-95 ${
                  !currentInput.trim() || isGenerating
                    ? 'bg-surface-gray text-text-gray cursor-not-allowed'
                    : 'bg-primary-green text-white hover:bg-green-600 shadow-button'
                }`}
              >
                {isGenerating ? 'Creating Magic...' : 'Generate Artwork'}
              </button>
            </div>
            
            {questProgress > 0 && (
              <div className="bg-white rounded-card p-6 shadow-card">
                <div className="aspect-square bg-surface-gray rounded-xl flex items-center justify-center mb-4">
                  <div className="text-center">
                    <div className="text-4xl mb-2">🎨</div>
                    <p className="text-gray-600">Your amazing artwork will appear here!</p>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-sm text-text-gray">Great work! Keep creating to complete your quest.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {quest.type === 'search' && (
          <div className="flex-1 p-4 pb-24">
            <div className="bg-white rounded-card p-6 shadow-card mb-6">
              <h2 className="font-quicksand font-semibold text-xl text-text-navy mb-4">
                Research Adventure! 🔍
              </h2>
              <p className="text-gray-600 mb-6">
                Ask questions and discover amazing facts about the world around you!
              </p>
              
              <input
                type="text"
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="What would you like to learn about?"
                className="w-full px-4 py-4 rounded-full border border-border-gray bg-surface-gray focus:outline-none focus:ring-2 focus:ring-primary-green/20 focus:border-primary-green"
              />
              
              <button
                onClick={handleSendMessage}
                disabled={!currentInput.trim() || isGenerating}
                className={`w-full mt-4 py-4 px-6 rounded-full font-semibold transition-all duration-200 transform active:scale-95 ${
                  !currentInput.trim() || isGenerating
                    ? 'bg-surface-gray text-text-gray cursor-not-allowed'
                    : 'bg-primary-green text-white hover:bg-green-600 shadow-button'
                }`}
              >
                {isGenerating ? 'Researching...' : 'Start Research'}
              </button>
            </div>
            
            {chatMessages.length > 0 && (
              <div className="space-y-4">
                {chatMessages.filter(msg => msg.type === 'ai').map((message, index) => (
                  <div key={index} className="bg-white rounded-card p-6 shadow-card">
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-primary-blue rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                        <Search size={20} className="text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-navy mb-2">Research Results</h3>
                        <p className="text-text-navy leading-relaxed">{message.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Completion Modal */}
      {earnedBadge && (
        <BadgeModal
          badge={earnedBadge}
          isOpen={showCompletionModal}
          onClose={() => {
            setShowCompletionModal(false);
            navigate('/');
          }}
        />
      )}

      {/* Toast */}
      <MascotToast
        message={toastMessage}
        isVisible={showToast}
        onClose={() => setShowToast(false)}
        type="success"
      />
    </div>
  );
};

export default QuestDetail;