import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Eye, EyeOff, Shield } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const PinEntry: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { setActiveProfile, setUser } = useApp();
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const profile = location.state?.profile;

  useEffect(() => {
    if (!profile) {
      navigate('/profiles');
    }
  }, [profile, navigate]);

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + digit);
      setError('');
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
    setError('');
  };

  const handleSubmit = async () => {
    if (pin.length !== 4) return;

    setIsLoading(true);
    
    setTimeout(() => {
      if (pin === profile.pin) {
        setActiveProfile(profile);
        
        if (profile.type === 'kid' && profile.user) {
          setUser(profile.user);
          navigate('/');
        } else if (profile.type === 'parent') {
          navigate('/parent-dashboard');
        }
      } else {
        setError('Incorrect PIN. Please try again.');
        setPin('');
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleBack = () => {
    navigate('/profiles');
  };

  if (!profile) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <button
          onClick={handleBack}
          className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors backdrop-blur-sm"
          style={{ minWidth: '48px', minHeight: '48px' }}
        >
          <ArrowLeft size={20} className="text-white" />
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white/10 backdrop-blur-lg border border-white/20 rounded-card p-8 shadow-2xl">
          {/* Profile Info */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full border-4 border-white/30 bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <span className="text-4xl">{profile.avatar}</span>
            </div>
            
            <h1 className="font-quicksand font-bold text-2xl mb-2 text-white">
              Welcome back, {profile.name}!
            </h1>
            <p className="text-white/70">
              Enter your 4-digit PIN to continue
            </p>
          </div>

          {/* PIN Display */}
          <div className="mb-8">
            <div className="flex justify-center space-x-4 mb-4">
              {[0, 1, 2, 3].map((index) => (
                <div
                  key={index}
                  className={`w-16 h-16 rounded-tile border-2 flex items-center justify-center text-2xl font-bold transition-all duration-200 ${
                    pin.length > index
                      ? 'border-primary-green bg-primary-green text-white'
                      : 'border-white/30 bg-white/10 text-white/30'
                  }`}
                >
                  {pin.length > index && (showPin ? pin[index] : '•')}
                </div>
              ))}
            </div>
            
            <button
              onClick={() => setShowPin(!showPin)}
              className="flex items-center justify-center w-full transition-colors text-white/60 hover:text-white/80"
            >
              {showPin ? <EyeOff size={16} /> : <Eye size={16} />}
              <span className="ml-2 text-sm">
                {showPin ? 'Hide PIN' : 'Show PIN'}
              </span>
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-error-red/20 border border-error-red/30 rounded-tile backdrop-blur-sm">
              <p className="text-error-red text-center text-sm">{error}</p>
            </div>
          )}

          {/* Number Pad */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
              <button
                key={digit}
                onClick={() => handlePinInput(digit.toString())}
                disabled={isLoading || pin.length >= 4}
                className="h-16 rounded-tile font-semibold text-xl transition-all duration-200 transform active:scale-95 bg-white/10 hover:bg-white/20 text-white border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-sm"
              >
                {digit}
              </button>
            ))}
            
            <div></div>
            
            <button
              onClick={() => handlePinInput('0')}
              disabled={isLoading || pin.length >= 4}
              className="h-16 rounded-tile font-semibold text-xl transition-all duration-200 transform active:scale-95 bg-white/10 hover:bg-white/20 text-white border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-sm"
            >
              0
            </button>
            
            <button
              onClick={handleDelete}
              disabled={isLoading || pin.length === 0}
              className="h-16 rounded-tile font-semibold transition-all duration-200 transform active:scale-95 bg-white/10 hover:bg-white/20 text-white/70 border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-sm"
            >
              ⌫
            </button>
          </div>

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={pin.length !== 4 || isLoading}
            className={`w-full py-4 rounded-card font-semibold transition-all duration-200 transform active:scale-95 ${
              pin.length === 4 && !isLoading
                ? 'bg-primary-green text-white hover:bg-green-600 shadow-lg'
                : 'bg-white/20 text-white/40 cursor-not-allowed'
            }`}
          >
            {isLoading ? 'Verifying...' : 'Enter'}
          </button>

          {/* Help Text */}
          <div className="mt-6 text-center">
            <p className="text-xs text-white/50">
              Forgot your PIN? Ask a parent for help.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PinEntry;