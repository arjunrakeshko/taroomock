import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Trophy, User, BookOpen } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const BottomNav: React.FC = () => {
  const location = useLocation();
  const { activeProfile } = useApp();

  // Don't show navigation for parent profiles
  if (!activeProfile || activeProfile.type === 'parent') {
    return null;
  }

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/leaderboard', icon: Trophy, label: 'Journey' },
    { path: '/quests', icon: BookOpen, label: 'My Quests' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-border-gray px-2 py-2 z-50 safe-area-pb">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`flex flex-col items-center py-2 px-3 rounded-tile transition-all duration-200 transform active:scale-95 ${
                isActive 
                  ? 'text-primary-green bg-success-green/10' 
                  : 'text-text-gray hover:text-text-navy'
              }`}
              style={{ minWidth: '72px', minHeight: '60px' }}
            >
              <Icon 
                size={24} 
                className={`mb-1 ${isActive ? 'fill-current' : ''}`} 
              />
              <span className="text-xs font-medium leading-tight">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;