export interface Quest {
  id: string;
  title: string;
  description: string;
  type: 'chat' | 'image' | 'search';
  difficulty: 'easy' | 'medium' | 'hard';
  xpValue: number;
  duration: number; // in minutes
  thumbnail: string;
  isPremium: boolean;
  tags: string[];
  completedBy?: number;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  xpToNextLevel: number;
  streak: number;
  rank: number;
  joinDate: string;
  screenTime: number; // in minutes
  safetyScore: number;
}

export interface Profile {
  id: string;
  name: string;
  avatar: string;
  type: 'kid' | 'parent';
  pin: string;
  isActive: boolean;
  user?: User; // For kid profiles
  parentData?: ParentData; // For parent profiles
}

export interface ParentData {
  hasProSubscription: boolean;
  subscribedChildCount?: number;
  children: string[]; // Profile IDs of children
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  xp: number;
  rank: number;
  previousRank: number;
  level: number;
  streak: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: string;
}

export interface QuestPack {
  id: string;
  title: string;
  description: string;
  price: number;
  questCount: number;
  thumbnail: string;
  tags: string[];
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface ParentInsight {
  date: string;
  screenTime: number;
  questsCompleted: number;
  xpEarned: number;
  safetyFlags: number;
  skillProgress: {
    creativity: number;
    logic: number;
    communication: number;
    research: number;
  };
}

export interface QuestExchange {
  id: string;
  questId: string;
  childId: string;
  completedAt: string;
  messages: ChatMessage[];
  aiAnalysis: AIAnalysis;
  duration: number;
  xpEarned: number;
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: number;
  flagged?: boolean;
  flagReason?: string;
}

export interface AIAnalysis {
  overallSentiment: 'positive' | 'neutral' | 'concerning';
  safetyScore: number;
  positiveSignals: string[];
  concerns: string[];
  recommendations: string[];
  flaggedContent: FlaggedContent[];
}

export interface FlaggedContent {
  messageId: string;
  severity: 'low' | 'medium' | 'high';
  category: 'inappropriate_language' | 'personal_info' | 'safety_concern' | 'emotional_distress';
  description: string;
  suggestion: string;
}

export interface ParentAlert {
  id: string;
  childId: string;
  questId: string;
  type: 'safety' | 'emotional' | 'educational' | 'positive';
  severity: 'low' | 'medium' | 'high';
  title: string;
  description: string;
  timestamp: string;
  isRead: boolean;
  actionRequired: boolean;
}

export interface UserTier {
  name: string;
  minXp: number;
  maxXp: number;
  icon: string;
  color: string;
  nextTier?: string;
}

export interface WeeklyProgressCard {
  id: string;
  userId: string;
  weekStart: string;
  currentTier: string;
  nextTier?: string;
  xpProgress: number;
  xpToNext: number;
  isNewTier: boolean;
  hasShown: boolean;
}

export interface CommunityMilestone {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  reward: string;
  isCompleted: boolean;
  completedAt?: string;
}

export interface ShareableCreation {
  id: string;
  questId: string;
  childId: string;
  title: string;
  description: string;
  type: 'story' | 'artwork' | 'research';
  content: string;
  thumbnail?: string;
  createdAt: string;
  isPublic: boolean;
}

export interface QuestTile {
  id: string;
  gameType: 'snap-trail' | '20q' | 'prompt-potion' | 'logic-dash' | 'heart-connect';
  theme: string;
  level: number;
  isUnlocked: boolean;
  isCompleted: boolean;
  shuffleCost: number;
  xpReward: number;
  description: string;
}

export interface ShuffleToken {
  count: number;
  earnedFrom: string[];
}

export interface FriendsLeague {
  id: string;
  name: string;
  type: 'neighborhood' | 'friends' | 'age_group' | 'school';
  members: LeaderboardEntry[];
  childId: string;
  ageRange?: string;
  location?: string;
}