import React, { useState, useEffect } from 'react';
import { X, Crown, Check, Star, Shield, TrendingUp, Users, Clock } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { mockProfiles } from '../data/mockProfiles';

interface ProUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: (plan: 'monthly' | 'yearly', childCount: number) => void;
}

const ProUpgradeModal: React.FC<ProUpgradeModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  const { activeProfile } = useApp();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);

  // Automatically detect number of child profiles
  const childProfiles = mockProfiles.filter(p => p.type === 'kid');
  const childCount = childProfiles.length;

  // Auto-select yearly plan if more than 1 child (better value)
  useEffect(() => {
    if (childCount > 1) {
      setSelectedPlan('yearly');
    }
  }, [childCount]);

  if (!isOpen) return null;

  const handleUpgrade = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      onUpgrade(selectedPlan, childCount);
      setIsProcessing(false);
      onClose();
    }, 2000);
  };

  const getChildPrice = (childCount: number, isYearly: boolean) => {
    const basePrice = isYearly ? 16.99 : 20.00; // Per child per month (yearly discount)
    return basePrice * childCount;
  };

  const getFamilyDiscount = (childCount: number) => {
    if (childCount >= 4) return 25; // 25% off for 4+ children
    if (childCount >= 3) return 20; // 20% off for 3+ children
    if (childCount >= 2) return 10; // 10% off for 2+ children
    return 0;
  };

  const calculateFinalPrice = (childCount: number, isYearly: boolean) => {
    const basePrice = getChildPrice(childCount, isYearly);
    const familyDiscount = getFamilyDiscount(childCount);
    const discountedPrice = basePrice * (1 - familyDiscount / 100);
    return isYearly ? discountedPrice * 12 : discountedPrice;
  };

  const getYearlySavings = (childCount: number) => {
    const monthlyTotal = calculateFinalPrice(childCount, false) * 12;
    const yearlyTotal = calculateFinalPrice(childCount, true);
    const savings = ((monthlyTotal - yearlyTotal) / monthlyTotal) * 100;
    return Math.round(savings);
  };

  const plans = [
    {
      id: 'monthly',
      name: 'Monthly',
      price: calculateFinalPrice(childCount, false),
      period: 'month',
      savings: getFamilyDiscount(childCount) > 0 ? `${getFamilyDiscount(childCount)}% family discount` : null,
      popular: false
    },
    {
      id: 'yearly',
      name: 'Yearly',
      price: calculateFinalPrice(childCount, true),
      period: 'year',
      savings: `Save ${getYearlySavings(childCount)}%`,
      popular: childCount > 1
    }
  ];

  const features = [
    {
      icon: Star,
      title: 'Unlimited Quest Packs',
      description: 'Access to all current and future quest content for all children',
      highlight: true
    },
    {
      icon: TrendingUp,
      title: 'Advanced Analytics Dashboard',
      description: 'Detailed insights into each child\'s learning progress and skill development',
      highlight: true
    },
    {
      icon: Shield,
      title: 'Enhanced Safety Monitoring',
      description: 'Real-time AI analysis and detailed safety reports for every interaction',
      highlight: true
    },
    {
      icon: Users,
      title: `All ${childCount} Children Covered`,
      description: `Individual tracking and analytics for ${childProfiles.map(p => p.name).join(', ')}`,
      highlight: false
    },
    {
      icon: Clock,
      title: 'Priority Support',
      description: '24/7 customer support with faster response times',
      highlight: false
    }
  ];

  const monthlyPerChild = calculateFinalPrice(childCount, false) / childCount;
  const yearlyPerChild = calculateFinalPrice(childCount, true) / 12 / childCount;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="w-full max-w-2xl bg-white rounded-card shadow-card max-h-[90vh] overflow-y-auto animate-slide-up">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-accent-yellow to-primary-green p-6 rounded-t-card">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
          >
            <X size={20} className="text-white" />
          </button>
          
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-white/20 rounded-full flex items-center justify-center">
              <Crown size={40} className="text-white" />
            </div>
            <h2 className="font-quicksand font-bold text-2xl text-white mb-2">
              Upgrade to Pro
            </h2>
            <p className="text-white/90">
              Premium features for all {childCount} {childCount === 1 ? 'child' : 'children'} in your family
            </p>
          </div>
        </div>

        <div className="p-6">
          {/* Children Overview */}
          <div className="mb-8">
            <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4 text-center">
              Your Family
            </h3>
            
            <div className="p-6 rounded-card border-2 border-primary-green/20 bg-primary-green/5">
              <div className="flex items-center justify-center mb-4">
                <div className="flex -space-x-2">
                  {childProfiles.map((child, index) => (
                    <img
                      key={child.id}
                      src={child.avatar}
                      alt={child.name}
                      className="w-12 h-12 rounded-full border-3 border-white shadow-soft"
                      style={{ zIndex: childProfiles.length - index }}
                    />
                  ))}
                </div>
              </div>
              
              <div className="text-center">
                <h4 className="font-semibold text-text-navy mb-2">
                  {childProfiles.map(p => p.name).join(', ')}
                </h4>
                <p className="text-sm text-text-gray">
                  {childCount} {childCount === 1 ? 'child' : 'children'} • All will get Pro access
                </p>
                
                {getFamilyDiscount(childCount) > 0 && (
                  <div className="mt-3 inline-flex items-center px-3 py-1 bg-success-green/20 text-success-green rounded-full text-sm font-medium">
                    🎉 Family Discount: {getFamilyDiscount(childCount)}% OFF
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Plan Selection */}
          <div className="mb-8">
            <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-4 text-center">
              Choose Your Plan
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {plans.map((plan) => (
                <button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id as 'monthly' | 'yearly')}
                  className={`relative p-6 rounded-card border-2 transition-all duration-200 transform active:scale-95 ${
                    selectedPlan === plan.id
                      ? 'border-primary-green bg-primary-green/5'
                      : 'border-border-gray hover:border-primary-green/50'
                  } ${plan.popular ? 'ring-2 ring-accent-yellow/50' : ''}`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="bg-accent-yellow text-text-navy px-3 py-1 rounded-full text-xs font-bold">
                        BEST VALUE
                      </span>
                    </div>
                  )}
                  
                  <div className="text-center">
                    <h4 className="font-quicksand font-semibold text-lg text-text-navy mb-2">
                      {plan.name}
                    </h4>
                    
                    <div className="mb-3">
                      <span className="text-3xl font-bold text-text-navy">
                        ${plan.price.toFixed(2)}
                      </span>
                      <span className="text-text-gray">/{plan.period}</span>
                    </div>
                    
                    <div className="text-sm text-text-gray mb-2">
                      ${(plan.id === 'monthly' ? monthlyPerChild : yearlyPerChild).toFixed(2)} per child per month
                    </div>
                    
                    {plan.savings && (
                      <div className="text-success-green font-medium text-sm mb-2">
                        {plan.savings}
                      </div>
                    )}
                    
                    <div className="text-xs text-text-gray">
                      {plan.id === 'yearly' 
                        ? `$${(plan.price / 12).toFixed(2)}/month billed annually` 
                        : 'Billed monthly'
                      }
                    </div>
                  </div>
                  
                  {selectedPlan === plan.id && (
                    <div className="absolute top-4 right-4">
                      <div className="w-6 h-6 bg-primary-green rounded-full flex items-center justify-center">
                        <Check size={14} className="text-white" />
                      </div>
                    </div>
                  )}
                </button>
              ))}
            </div>
            
            {/* Pricing Breakdown */}
            <div className="mt-4 p-4 bg-surface-gray rounded-card">
              <h4 className="font-medium text-text-navy mb-3 text-center">Pricing Breakdown</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-text-gray">Base price ({childCount} children)</span>
                  <span className="text-text-navy">
                    ${getChildPrice(childCount, selectedPlan === 'yearly').toFixed(2)}/month
                  </span>
                </div>
                
                {getFamilyDiscount(childCount) > 0 && (
                  <div className="flex justify-between text-success-green">
                    <span>Family discount ({getFamilyDiscount(childCount)}% off)</span>
                    <span>
                      -${(getChildPrice(childCount, selectedPlan === 'yearly') * getFamilyDiscount(childCount) / 100).toFixed(2)}/month
                    </span>
                  </div>
                )}
                
                {selectedPlan === 'yearly' && (
                  <div className="flex justify-between text-primary-blue">
                    <span>Annual billing discount</span>
                    <span>-${((getChildPrice(childCount, false) - getChildPrice(childCount, true)) * (1 - getFamilyDiscount(childCount) / 100)).toFixed(2)}/month</span>
                  </div>
                )}
                
                <div className="border-t border-border-gray pt-2 flex justify-between font-semibold">
                  <span className="text-text-navy">Final price</span>
                  <span className="text-primary-green">
                    ${(selectedPlan === 'monthly' ? calculateFinalPrice(childCount, false) : calculateFinalPrice(childCount, true) / 12).toFixed(2)}/month
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="mb-8">
            <h3 className="font-quicksand font-semibold text-lg text-text-navy mb-6 text-center">
              Everything You Get with Pro
            </h3>
            
            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className={`
                  flex items-start p-4 rounded-tile
                  ${feature.highlight ? 'bg-primary-green/5 border border-primary-green/20' : 'bg-surface-gray'}
                `}>
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center mr-4 flex-shrink-0
                    ${feature.highlight ? 'bg-primary-green text-white' : 'bg-white text-primary-green'}
                  `}>
                    <feature.icon size={20} />
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-medium text-text-navy mb-1">
                      {feature.title}
                      {feature.highlight && (
                        <span className="ml-2 text-xs bg-accent-yellow text-text-navy px-2 py-0.5 rounded-full font-bold">
                          NEW
                        </span>
                      )}
                    </h4>
                    <p className="text-sm text-text-gray">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Value Proposition */}
          <div className="mb-6 p-6 bg-gradient-to-r from-primary-green/10 to-primary-blue/10 rounded-card border border-primary-green/20">
            <div className="text-center">
              <h4 className="font-quicksand font-semibold text-lg text-text-navy mb-2">
                🎯 Perfect for Your Family
              </h4>
              <p className="text-text-gray mb-4">
                With {childCount} {childCount === 1 ? 'child' : 'children'}, you're getting premium learning tools 
                {getFamilyDiscount(childCount) > 0 && ` with a ${getFamilyDiscount(childCount)}% family discount`}
                {selectedPlan === 'yearly' && ` plus ${getYearlySavings(childCount)}% savings with annual billing`}.
              </p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary-green">
                    ${(selectedPlan === 'monthly' ? monthlyPerChild : yearlyPerChild).toFixed(2)}
                  </div>
                  <div className="text-text-gray">per child/month</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary-green">
                    {selectedPlan === 'yearly' ? getYearlySavings(childCount) : getFamilyDiscount(childCount)}%
                  </div>
                  <div className="text-text-gray">total savings</div>
                </div>
              </div>
            </div>
          </div>

          {/* Guarantee */}
          <div className="mb-6 p-4 bg-info-blue/10 rounded-tile border border-info-blue/20">
            <div className="flex items-center justify-center mb-2">
              <Shield size={20} className="text-info-blue mr-2" />
              <span className="font-medium text-text-navy">30-Day Money-Back Guarantee</span>
            </div>
            <p className="text-sm text-text-gray text-center">
              Try Pro risk-free for your entire family. Cancel anytime within 30 days for a full refund.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onClose}
              className="flex-1 py-3 px-6 rounded-card font-semibold text-text-gray border border-border-gray hover:bg-surface-gray transition-colors"
            >
              Maybe Later
            </button>
            
            <button
              onClick={handleUpgrade}
              disabled={isProcessing}
              className={`flex-1 py-3 px-6 rounded-card font-semibold transition-all duration-200 transform active:scale-95 ${
                isProcessing
                  ? 'bg-text-gray text-white cursor-not-allowed'
                  : 'bg-primary-green text-white hover:bg-dark-green shadow-duolingo active:shadow-duolingo-pressed active:translate-y-1'
              }`}
            >
              {isProcessing ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                  Processing...
                </div>
              ) : (
                `Start Pro - $${plans.find(p => p.id === selectedPlan)?.price.toFixed(2)}/${selectedPlan === 'monthly' ? 'mo' : 'yr'}`
              )}
            </button>
          </div>

          {/* Terms */}
          <p className="text-xs text-text-gray text-center mt-4">
            By upgrading, you agree to our{' '}
            <button className="text-primary-blue hover:underline">Terms of Service</button>
            {' '}and{' '}
            <button className="text-primary-blue hover:underline">Privacy Policy</button>.
            Subscription auto-renews unless cancelled. Covers all {childCount} children in your family.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProUpgradeModal;