import React, { useState, useEffect } from 'react';
import { ArrowLeft, Camera, Check, Sparkles, Zap, Clock, Eye, RotateCcw, TreePine } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';

interface PromptCard {
  id: string;
  prompt: string;
  found: boolean;
  photo?: string;
}

interface ThemeLevel {
  level: number;
  theme: string;
  prompts: string[];
}

const SnapTrail: React.FC = () => {
  const navigate = useNavigate();
  const { user, completeTile, shuffleTokens } = useApp();
  const [currentLevel, setCurrentLevel] = useState(1);
  const [currentTheme, setCurrentTheme] = useState('Day at the Park');
  const [basket, setBasket] = useState<PromptCard[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [xp, setXp] = useState(0);
  const [glowLeaves, setGlowLeaves] = useState(0);
  const [showLevelComplete, setShowLevelComplete] = useState(false);
  const [branchGrowth, setBranchGrowth] = useState(0);
  const [showIncorrectFeedback, setShowIncorrectFeedback] = useState<string | null>(null);

  // Theme series data
  const themeSeries = {
    'Day at the Park': {
      beginner: ['a pet animal', 'a tall tree', 'a flower', 'a bench'],
      intermediate: ['a squirrel', 'textured bark', 'a cloud shape', 'playground sign'],
      advanced: ['symmetry in nature', 'animal-shaped shadow', 'leaf bigger than hand', 'three colours in one shot']
    },
    'Day at the Mall': {
      beginner: ['shop logo', 'escalator', 'yellow item', 'sale sign'],
      intermediate: ['reflective surface', 'identical items', 'price ending 99', 'moving escalator'],
      advanced: ['three patterns together', 'triangle architecture', 'motion blur', 'geometric reflection']
    },
    'Back-Yard Safari': {
      beginner: ['insect', 'rough texture', 'rolling object', 'puddle'],
      intermediate: ['spider web', 'chipped paint', 'two greens', 'garden tool'],
      advanced: ['mushroom', 'natural spiral', 'dew-web', 'rock animal']
    },
    'City-Street Safari': {
      beginner: ['traffic light', 'red car', 'street sign "S"', 'store window'],
      intermediate: ['delivery-truck logo', '5-storey building', 'puddle reflection', 'perfect circle'],
      advanced: ['geometric façade pattern', '3 transport modes', 'long shadow', '1-2-3 number sequence']
    },
    'Kitchen Quest': {
      beginner: ['metal spoon', 'fruit', 'round shape', 'running tap'],
      intermediate: ['measuring-cup marks', 'nutrition label', 'texture contrast', 'reflection in lid'],
      advanced: ['tri-colour food', 'steam pattern', 'ingredient "P"', 'spiral pasta']
    },
    'Library Sleuth': {
      beginner: ['animal book cover', 'library sign', 'rainbow spines', 'shelf number'],
      intermediate: ['pre-2000 book', 'atlas/map', 'call-number "QA"', 'reading nook'],
      advanced: ['palindrome title', 'B/W illustration', '3-D shelf item', 'Dewey sign']
    }
  };

  useEffect(() => {
    initializeBasket();
  }, [currentLevel, currentTheme]);

  const initializeBasket = () => {
    const theme = themeSeries[currentTheme as keyof typeof themeSeries];
    let prompts: string[] = [];
    
    if (currentLevel <= 3) {
      prompts = theme.beginner;
    } else if (currentLevel <= 7) {
      prompts = theme.intermediate;
    } else {
      prompts = theme.advanced;
    }

    const cards: PromptCard[] = prompts.map((prompt, index) => ({
      id: `card-${index}`,
      prompt,
      found: false
    }));

    setBasket(cards);
  };

  const handleBack = () => {
    navigate('/');
  };

  const handleCameraCapture = (cardId: string) => {
    setSelectedCard(cardId);
    setIsCapturing(true);
    
    // Simulate camera capture and CV processing
    setTimeout(() => {
      // Simulate successful match (80% success rate for demo)
      const isMatch = Math.random() > 0.2;
      
      if (isMatch) {
        setBasket(prev => prev.map(card => 
          card.id === cardId 
            ? { ...card, found: true, photo: `https://images.pexels.com/photos/${Math.floor(Math.random() * 1000000)}/pexels-photo.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=2` }
            : card
        ));
        setXp(prev => prev + 25);
        
        // Check if basket is complete
        const updatedBasket = basket.map(card => 
          card.id === cardId ? { ...card, found: true } : card
        );
        
        if (updatedBasket.every(card => card.found)) {
          setTimeout(() => handleBasketComplete(), 1000);
        }
      } else {
        // Show feedback for incorrect match
        setShowIncorrectFeedback(cardId);
        setTimeout(() => {
          setShowIncorrectFeedback(null);
        }, 3000);
      }
      
      setIsCapturing(false);
      setSelectedCard(null);
    }, 2000);
  };

  const handleBasketComplete = () => {
    setGlowLeaves(prev => prev + 1);
    // Complete the tile and redirect to home
    completeTile('tile-1');
    navigate('/');
    setShowLevelComplete(true);
    
    setTimeout(() => {
      setCurrentLevel(prev => prev + 1);
      setShowLevelComplete(false);
      initializeBasket();
    }, 3000);
  };

  const handleCompleteQuest = () => {
    completeTile('tile-1');
    navigate('/');
  };

  const getDifficultyLevel = () => {
    if (currentLevel <= 3) return 'Beginner';
    if (currentLevel <= 7) return 'Intermediate';
    return 'Advanced';
  };

  const getCompletionPercentage = () => {
    const foundCards = basket.filter(card => card.found).length;
    return (foundCards / basket.length) * 100;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 via-emerald-50 to-teal-50 relative overflow-hidden">
      {/* Forest Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-4 text-6xl opacity-20 text-green-600">🌲</div>
        <div className="absolute top-32 right-8 text-5xl opacity-15 text-green-700">🌳</div>
        <div className="absolute top-64 left-12 text-4xl opacity-25 text-green-500">🌿</div>
        <div className="absolute bottom-32 left-8 text-5xl opacity-20 text-green-600">🌳</div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-1/3 text-2xl opacity-30 text-green-400 animate-bounce">🍃</div>
        <div className="absolute top-48 right-1/4 text-xl opacity-40 text-green-500 animate-pulse">🍂</div>
        <div className="absolute bottom-48 right-1/3 text-xl opacity-30 text-green-400 animate-pulse">🦋</div>
      </div>

      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-green-200 shadow-sm px-4 py-4 safe-area-pt">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-green-100 hover:bg-green-200 transition-colors mr-3"
            >
              <ArrowLeft size={20} className="text-green-600" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                <Camera size={20} className="text-green-600 mr-2" />
                <h1 className="font-bold text-green-800 text-lg truncate">
                  📸 Snap Trail
                </h1>
              </div>
              <div className="flex items-center text-sm text-green-600">
                <span>Level {currentLevel}</span>
                <span className="mx-2">•</span>
                <span>{getDifficultyLevel()}</span>
                <Zap size={14} className="ml-3 mr-1" />
                <span>{xp} XP</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center bg-yellow-100 rounded-full px-3 py-2 border border-yellow-200">
            <TreePine size={16} className="text-green-600 mr-2" />
            <span className="font-bold text-green-700">{glowLeaves}</span>
            <span className="text-green-600 ml-1 text-xs">Leaves</span>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-green-600 mb-2">
            <span>{currentTheme}</span>
            <span>{Math.round(getCompletionPercentage())}%</span>
          </div>
          <div className="h-2 bg-green-200 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-green-500 to-emerald-500"
              style={{ width: `${getCompletionPercentage()}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-6 pb-24">
        {/* Theme Header */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200 mb-6">
          <div className="text-center">
            <div className="text-4xl mb-3">📸</div>
            <h2 className="font-bold text-green-800 text-xl mb-2">
              {currentTheme}
            </h2>
            <p className="text-green-600 text-base mb-4">
              Find and snap photos of these items to grow your Curiosity Branch!
            </p>
            <div className="bg-green-50 rounded-xl border border-green-200 p-3">
              <p className="text-green-700 text-sm">
                🌿 Clear all {basket.length} cards to earn a Glow-Leaf and unlock the next level!
              </p>
            </div>
          </div>
        </div>

        {/* Photo Basket */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200">
          <h3 className="font-semibold text-green-800 text-lg mb-4 flex items-center">
            🧺 Your Photo Basket
            <span className="ml-2 text-sm bg-green-100 text-green-600 px-2 py-1 rounded-full">
              {basket.filter(card => card.found).length}/{basket.length}
            </span>
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            {basket.map((card) => (
              <div key={card.id} className={`relative rounded-xl border-2 transition-all duration-300 ${
                card.found 
                  ? 'border-green-500 bg-green-50' 
                  : 'border-green-200 bg-white hover:border-green-400'
              }`}>
                {card.found && card.photo ? (
                  <div className="relative">
                    <img
                      src={card.photo}
                      alt={card.prompt}
                      className="w-full h-32 object-cover rounded-t-xl"
                    />
                    <div className="absolute top-2 right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                      <Check size={16} className="text-white" />
                    </div>
                    <div className="p-3">
                      <p className="text-green-800 font-medium text-sm line-through opacity-60">
                        {card.prompt}
                      </p>
                      <p className="text-green-600 text-xs mt-1">✓ FOUND</p>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 text-center">
                    <div className="w-16 h-16 mx-auto mb-3 bg-green-100 rounded-full flex items-center justify-center">
                      <Camera size={24} className="text-green-600" />
                    </div>
                    <p className="text-green-800 font-medium text-sm mb-3 leading-tight">
                      {card.prompt}
                    </p>
                    <button
                      onClick={() => handleCameraCapture(card.id)}
                      disabled={isCapturing && selectedCard === card.id}
                      className={`w-full py-2 px-4 rounded-xl font-medium transition-all duration-200 transform active:scale-95 relative ${
                        isCapturing && selectedCard === card.id
                          ? 'bg-green-200 text-green-600 cursor-not-allowed'
                          : showIncorrectFeedback === card.id
                          ? 'bg-red-100 text-red-600 border border-red-300'
                          : 'bg-green-600 text-white hover:bg-green-700 shadow-md'
                      }`}
                    >
                      {isCapturing && selectedCard === card.id ? (
                        <div className="flex items-center justify-center">
                          <div className="w-4 h-4 border-2 border-green-600/30 border-t-green-600 rounded-full animate-spin mr-2"></div>
                          Checking...
                        </div>
                      ) : showIncorrectFeedback === card.id ? (
                        <div className="flex items-center justify-center">
                          <span className="mr-2">❌</span>
                          Try Again!
                        </div>
                      ) : (
                        <div className="flex items-center justify-center">
                          <Camera size={16} className="mr-2" />
                          Snap It!
                        </div>
                      )}
                    </button>
                    
                    {/* Incorrect Feedback Tooltip */}
                    {showIncorrectFeedback === card.id && (
                      <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-3 py-1 rounded-lg text-xs whitespace-nowrap z-10">
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-red-500"></div>
                        Photo doesn't match! Try again 📸
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Branch Growth Visualization */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-green-200 mt-6">
          <h3 className="font-semibold text-green-800 text-lg mb-4 flex items-center">
            🌿 Your Curiosity Branch
          </h3>
          
          <div className="relative">
            <div className="flex items-center justify-center mb-4">
              <div className="relative">
                {/* Branch visualization */}
                <div className="w-32 h-20 relative">
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-2 h-8 bg-amber-700 rounded-t-sm"></div>
                  <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-16 h-12 bg-gradient-to-t from-green-600 to-green-400 rounded-full">
                    {/* Glow leaves */}
                    {[...Array(glowLeaves)].map((_, i) => (
                      <div key={i} 
                           className="absolute text-yellow-400 animate-pulse text-sm"
                           style={{
                             left: `${20 + (i * 20) % 60}%`,
                             top: `${30 + (i * 15) % 40}%`,
                             animationDelay: `${i * 0.5}s`
                           }}>
                        ✨
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-green-600 text-sm mb-2">
                🍃 {glowLeaves} Glow-Leaves earned
              </p>
              <div className="bg-green-100 rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-green-500 to-yellow-400 transition-all duration-1000"
                  style={{ width: `${(branchGrowth % 100)}%` }}
                />
              </div>
              <p className="text-green-600 text-xs mt-1">
                Branch Growth: {branchGrowth}%
              </p>
            </div>
          </div>
        </div>

        {/* Complete Quest Button */}
        {glowLeaves >= 2 && (
          <div className="mt-6">
            <button
              onClick={handleCompleteQuest}
              className="w-full py-4 px-6 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-2xl font-bold text-lg hover:from-green-600 hover:to-emerald-700 transition-colors shadow-lg"
            >
              🎉 Complete Forest Adventure
            </button>
          </div>
        )}
      </div>

      {/* Level Complete Modal */}
      {showLevelComplete && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full mx-4 shadow-xl border border-green-200 text-center">
            <div className="text-6xl mb-4 animate-bounce">🌿</div>
            <h3 className="font-bold text-green-800 text-xl mb-2">
              Level Complete!
            </h3>
            <p className="text-green-600 text-base mb-4">
              You earned a Glow-Leaf! Your Curiosity Branch is growing stronger.
            </p>
            <div className="bg-green-50 rounded-xl border border-green-200 p-4">
              <p className="text-green-700 text-sm">
                🎯 Moving to Level {currentLevel + 1}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Incorrect Match Modal */}
      {showIncorrectFeedback && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4 pointer-events-none">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl border border-red-200 animate-bounce-in pointer-events-auto">
            <div className="text-center">
              <div className="text-4xl mb-3">📸❌</div>
              <h3 className="font-bold text-red-600 text-lg mb-2">
                Not quite right!
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                The photo doesn't match what we're looking for. Take another look around and try again!
              </p>
              <div className="bg-red-50 rounded-xl border border-red-200 p-3">
                <p className="text-red-700 text-xs">
                  💡 Tip: Make sure your photo clearly shows the item described in the prompt
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SnapTrail;