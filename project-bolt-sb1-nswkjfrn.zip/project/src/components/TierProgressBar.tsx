import React from 'react';
import { useApp } from '../contexts/AppContext';

interface TierProgressBarProps {
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const TierProgressBar: React.FC<TierProgressBarProps> = ({ 
  showLabel = true, 
  size = 'md' 
}) => {
  const { user, getUserTier, getProgressToNextTier } = useApp();
  
  const currentTier = getUserTier(user.xp);
  const progress = getProgressToNextTier(user.xp);
  
  const sizeClasses = {
    sm: 'h-2',
    md: 'h-3',
    lg: 'h-4'
  };

  const textSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  return (
    <div className="w-full">
      {showLabel && (
        <div className={`flex items-center justify-between mb-2 ${textSizes[size]}`}>
          <div className="flex items-center">
            <span className="mr-2 text-lg">{currentTier.icon}</span>
            <span className="font-semibold text-text-navy">{currentTier.name}</span>
          </div>
          {currentTier.nextTier && (
            <span className="text-text-gray">
              {user.xpToNextLevel} XP to {currentTier.nextTier}
            </span>
          )}
        </div>
      )}
      
      <div className={`w-full bg-surface-gray rounded-full overflow-hidden ${sizeClasses[size]}`}>
        <div 
          className={`${sizeClasses[size]} bg-gradient-to-r ${currentTier.color} transition-all duration-1000 ease-out rounded-full`}
          style={{ width: `${progress.percentage}%` }}
        />
      </div>
      
      {showLabel && currentTier.nextTier && (
        <div className={`flex justify-between mt-1 ${textSizes[size]} text-text-gray`}>
          <span>{currentTier.name}</span>
          <span>{currentTier.nextTier}</span>
        </div>
      )}
    </div>
  );
};

export default TierProgressBar;