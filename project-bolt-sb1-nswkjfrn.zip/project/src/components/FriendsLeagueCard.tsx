import React from 'react';
import { Trophy, Users, MapPin, Calendar, TrendingUp, TrendingDown, GraduationCap } from 'lucide-react';
import { FriendsLeague } from '../types';

interface FriendsLeagueCardProps {
  league: FriendsLeague;
  onViewDetails?: (league: FriendsLeague) => void;
}

const FriendsLeagueCard: React.FC<FriendsLeagueCardProps> = ({ league, onViewDetails }) => {
  const currentUser = league.members.find(member => member.id === league.childId);
  const topThree = league.members.slice(0, 3);

  const getLeagueIcon = (type: string) => {
    switch (type) {
      case 'neighborhood': return <MapPin size={16} className="text-primary-green" />;
      case 'friends': return <Users size={16} className="text-primary-blue" />;
      case 'age_group': return <Calendar size={16} className="text-accent-purple" />;
      default: return <Trophy size={16} className="text-accent-yellow" />;
    }
  };

  const getLeagueColor = (type: string) => {
    switch (type) {
      case 'neighborhood': return 'from-primary-green/10 to-success-green/10 border-primary-green/20';
      case 'friends': return 'from-primary-blue/10 to-info-blue/10 border-primary-blue/20';
      case 'age_group': return 'from-accent-purple/10 to-purple-500/10 border-accent-purple/20';
      default: return 'from-accent-yellow/10 to-orange-400/10 border-accent-yellow/20';
    }
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return rank.toString();
  };

  return (
    <div 
      className={`bg-gradient-to-br ${getLeagueColor(league.type)} border rounded-card p-4 shadow-card hover:shadow-lg transition-all duration-200 cursor-pointer`}
      onClick={() => onViewDetails?.(league)}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          {getLeagueIcon(league.type)}
          <h3 className="font-quicksand font-semibold text-base text-text-navy ml-2">
            {league.name}
          </h3>
        </div>
        
        <span className="text-xs text-text-gray">
          {league.members.length} members
        </span>
      </div>

      {/* League Info */}
      <div className="mb-4">
        {league.location && (
          <p className="text-xs text-text-gray mb-1">📍 {league.location}</p>
        )}
        {league.ageRange && (
          <p className="text-xs text-text-gray mb-1">👶 {league.ageRange}</p>
        )}
      </div>

      {/* Current User Rank */}
      {currentUser && (
        <div className="p-3 rounded-tile mb-4 bg-white/60 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-primary-green rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-bold text-sm">{currentUser.rank}</span>
              </div>
              <div>
                <p className="font-medium text-text-navy text-sm">Your Rank</p>
                <p className="text-xs text-text-gray">{currentUser.xp.toLocaleString()} XP</p>
              </div>
            </div>
            
            <div className="flex items-center">
              {currentUser.previousRank > currentUser.rank ? (
                <TrendingUp size={16} className="text-success-green" />
              ) : currentUser.previousRank < currentUser.rank ? (
                <TrendingDown size={16} className="text-error-red" />
              ) : null}
            </div>
          </div>
        </div>
      )}

      {/* Top 3 */}
      <div className="space-y-2">
        <h4 className="font-medium text-text-navy text-sm mb-2">Top Performers</h4>
        {topThree.map((member, index) => (
          <div key={member.id} className="flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-sm mr-2">{getRankIcon(member.rank)}</span>
              <div
                className="w-6 h-6 rounded-full border-3 border-white shadow-soft bg-white flex items-center justify-center mr-2"
              >
                <span className="text-2xl">{member.avatar}</span>
              </div>
              <span className={`text-sm ${member.id === league.childId ? 'font-semibold text-primary-green' : 'text-text-navy'}`}>
                {member.name}
              </span>
            </div>
            
            <span className="text-xs text-text-gray">
              {member.xp.toLocaleString()}
            </span>
          </div>
        ))}
      </div>

      {/* View More */}
      <button className="w-full mt-3 py-2 text-sm text-primary-blue font-medium hover:underline">
        View Full Leaderboard
      </button>
    </div>
  );
};

export default FriendsLeagueCard;