import React, { useState, useEffect } from 'react';
import { ArrowLeft, Volume2, VolumeX, Send, Bot, Zap, Clock, Heart, Settings, Lightbulb } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ChatMessage {
  type: 'user' | 'ai';
  content: string;
  timestamp: number;
}

interface RobotFeature {
  category: string;
  options: string[];
  selected?: string;
}

const RobotFriendDesigner: React.FC = () => {
  const navigate = useNavigate();
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [questProgress, setQuestProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(360); // 6 minutes
  const [xp, setXp] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [robotFeatures, setRobotFeatures] = useState<RobotFeature[]>([
    { category: 'Appearance', options: ['Teddy Bear', 'Humanoid', 'Animal-like', 'Geometric'], selected: '' },
    { category: 'Colors', options: ['Blue & Green', 'Rainbow', 'Silver & Gold', 'Pink & Purple'], selected: '' },
    { category: 'Special Abilities', options: ['Cooking', 'Homework Help', 'Games', 'Music'], selected: '' },
    { category: 'Personality', options: ['Friendly', 'Wise', 'Playful', 'Caring'], selected: '' }
  ]);

  useEffect(() => {
    setChatMessages([
      {
        type: 'ai',
        content: "Welcome to the Robot Friend Designer! 🤖 I'm here to help you create the perfect robot companion. Let's start by talking about what your robot friend should look like. What kind of appearance would you want your robot to have?",
        timestamp: Date.now()
      }
    ]);

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleQuestComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleBack = () => {
    navigate('/');
  };

  const handleTTSToggle = () => {
    setIsTTSEnabled(!isTTSEnabled);
  };

  const handleSendMessage = async () => {
    if (!currentInput.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      type: 'user',
      content: currentInput,
      timestamp: Date.now()
    };

    setChatMessages(prev => [...prev, userMessage]);
    setCurrentInput('');
    setIsGenerating(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        type: 'ai',
        content: generateAIResponse(currentInput),
        timestamp: Date.now()
      };
      
      setChatMessages(prev => [...prev, aiResponse]);
      setIsGenerating(false);
      setQuestProgress(prev => Math.min(prev + 20, 100));
      setXp(prev => prev + 30);
      
      if (questProgress >= 80) {
        setTimeout(() => handleQuestComplete(), 1000);
      }
    }, 2000);
  };

  const generateAIResponse = (input: string) => {
    const responses = [
      "That's a fantastic idea for your robot friend! I love how creative you are. What special abilities should your robot have?",
      "Amazing choice! Your robot sounds really special. How would you want your robot to help you and others?",
      "Wonderful! I can picture your robot friend already. What personality traits would make your robot the best companion?",
      "Perfect! Your robot design is coming together beautifully. What would you name your robot friend?",
      "Incredible! Your robot friend sounds like they would be amazing to have around. What adventures would you go on together?"
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleFeatureSelect = (categoryIndex: number, option: string) => {
    const newFeatures = [...robotFeatures];
    newFeatures[categoryIndex].selected = option;
    setRobotFeatures(newFeatures);
    setQuestProgress(prev => Math.min(prev + 10, 100));
    setXp(prev => prev + 20);
  };

  const handleQuestComplete = () => {
    setIsCompleted(true);
    setXp(prev => prev + 180);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const designPrompts = [
    "I want a robot that looks like a big teddy bear with cool lights!",
    "My robot should be able to help with homework and play games",
    "I'd like a robot that can cook pancakes and help other kids",
    "My robot friend should be really kind and always helpful"
  ];

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-pink-700 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-4">
                  <Bot className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Robot Friend Complete!</h1>
              <p className="text-xl text-gray-600">You've designed an amazing robot companion!</p>
              
              <div className="flex justify-center gap-6 mt-6">
                <div className="text-center">
                  <div className="bg-blue-100 rounded-full p-3 mb-2">
                    <Zap className="w-6 h-6 text-blue-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600">{xp}</div>
                  <div className="text-sm text-gray-600">XP Earned</div>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 rounded-full p-3 mb-2">
                    <Settings className="w-6 h-6 text-green-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-green-600">{robotFeatures.filter(f => f.selected).length}</div>
                  <div className="text-sm text-gray-600">Features Designed</div>
                </div>
                <div className="text-center">
                  <div className="bg-purple-100 rounded-full p-3 mb-2">
                    <Heart className="w-6 h-6 text-purple-600 mx-auto" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600">100%</div>
                  <div className="text-sm text-gray-600">Friendship Score</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Robot Friend Design</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-4">🤖 Robot Specifications</h3>
                <div className="space-y-3">
                  {robotFeatures.map((feature, index) => (
                    <div key={index} className="flex justify-between">
                      <span className="text-gray-600">{feature.category}:</span>
                      <span className="font-medium text-gray-800">{feature.selected || 'Custom'}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-pink-50 to-yellow-50 rounded-xl p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-4">💝 Special Features</h3>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-700">
                    <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                    Helps with homework and learning
                  </div>
                  <div className="flex items-center text-sm text-gray-700">
                    <span className="w-2 h-2 bg-blue-400 rounded-full mr-2"></span>
                    Plays games and tells stories
                  </div>
                  <div className="flex items-center text-sm text-gray-700">
                    <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                    Always kind and helpful
                  </div>
                  <div className="flex items-center text-sm text-gray-700">
                    <span className="w-2 h-2 bg-pink-400 rounded-full mr-2"></span>
                    Cares about others' feelings
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl p-6 mb-8">
              <h3 className="font-semibold text-lg text-gray-800 mb-3">🌟 Your Robot's Story</h3>
              <p className="text-gray-700 leading-relaxed">
                Meet your amazing robot friend! This special companion combines the best features you've designed - 
                a caring personality with incredible abilities to help, learn, and play. Your robot friend will always 
                be there to support you and others, making the world a little bit brighter every day.
              </p>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={() => navigate('/')}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg"
              >
                Back to Quests
              </button>
              <button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-blue-600 transition-all duration-200 shadow-lg">
                Design Another Robot
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 flex flex-col">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm sticky top-0 z-40 px-4 py-4 border-b border-white/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center flex-1">
            <button
              onClick={handleBack}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors mr-3"
            >
              <ArrowLeft size={20} className="text-white" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center mb-1">
                <Bot size={20} className="text-white mr-2" />
                <h1 className="font-quicksand font-semibold text-lg text-white truncate">
                  Robot Friend Designer
                </h1>
              </div>
              <div className="flex items-center text-sm text-white/70">
                <Clock size={14} className="mr-1" />
                <span>{formatTime(timeRemaining)}</span>
                <Zap size={14} className="ml-3 mr-1" />
                <span>{xp} XP</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={handleTTSToggle}
            className={`p-3 rounded-full transition-colors ml-2 ${
              isTTSEnabled 
                ? 'bg-green-500 text-white' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
          >
            {isTTSEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
        </div>
        
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between text-sm text-white/70 mb-2">
            <span>Design Progress</span>
            <span>{questProgress}%</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500 ease-out bg-gradient-to-r from-blue-400 to-purple-400"
              style={{ width: `${questProgress}%` }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] px-4 py-3 rounded-2xl ${
                  message.type === 'user'
                    ? 'bg-blue-500 text-white'
                    : 'bg-white/10 backdrop-blur-sm text-white border border-white/20'
                }`}>
                  {message.type === 'ai' && (
                    <div className="flex items-center mb-2">
                      <Bot size={16} className="mr-2" />
                      <span className="text-xs font-medium">Robot Designer AI</span>
                    </div>
                  )}
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
              </div>
            ))}
            
            {isGenerating && (
              <div className="flex justify-start">
                <div className="max-w-[85%] px-4 py-3 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Input Area */}
          <div className="bg-white/10 backdrop-blur-sm border-t border-white/20 p-4">
            <div className="mb-3">
              <div className="flex flex-wrap gap-2">
                <span className="text-white/70 text-sm">Quick ideas:</span>
                {designPrompts.slice(0, 2).map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentInput(prompt)}
                    className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white/80 text-xs transition-colors"
                  >
                    {prompt.slice(0, 25)}...
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-end space-x-3">
              <textarea
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Describe your robot friend..."
                className="flex-1 px-4 py-3 rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
                disabled={isGenerating}
                rows={2}
              />
              <button
                onClick={handleSendMessage}
                disabled={!currentInput.trim() || isGenerating}
                className={`p-3 rounded-full transition-all duration-200 transform active:scale-95 ${
                  !currentInput.trim() || isGenerating
                    ? 'bg-white/20 text-white/50 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600 shadow-lg'
                }`}
              >
                <Send size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Design Panel */}
        <div className="w-80 bg-white/10 backdrop-blur-sm border-l border-white/20 p-4 hidden lg:block">
          <h3 className="font-quicksand font-semibold text-lg text-white mb-4 flex items-center">
            <Lightbulb size={20} className="mr-2" />
            Robot Features
          </h3>
          
          <div className="space-y-4">
            {robotFeatures.map((feature, index) => (
              <div key={index} className="bg-white/10 rounded-xl p-4">
                <h4 className="font-medium text-white mb-3">{feature.category}</h4>
                <div className="grid grid-cols-2 gap-2">
                  {feature.options.map((option) => (
                    <button
                      key={option}
                      onClick={() => handleFeatureSelect(index, option)}
                      className={`p-2 rounded-lg text-xs transition-colors ${
                        feature.selected === option
                          ? 'bg-blue-500 text-white'
                          : 'bg-white/10 text-white/70 hover:bg-white/20'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RobotFriendDesigner;